<?php
/**
 * KwickFlix Style — Frontend Hook
 *
 * Single ClientAreaPage hook that exposes BOTH:
 *   - Smarty variables (header.tpl + footer.tpl read these to render
 *     the configurable bits: logos, second navbar, footer columns, etc.)
 *   - $kf_dynamic_css — a small inline <style> block with overrides
 *     (accent color, page background color). Rendered AFTER the
 *     template's static design system so overrides actually win the
 *     cascade.
 *
 * NOTE: We deliberately do NOT use ClientAreaHeadOutput, because that
 * hook injects into {$headoutput} which sits BEFORE the static <style>
 * block in header.tpl — meaning any override there would be overwritten
 * by the static defaults that come later in the document.
 *
 * NO custom.css is written or used. Everything is runtime-injected.
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/Renderer.php';

use KwickFlixStyle\Settings;
use KwickFlixStyle\Renderer;

/**
 * Resolve the template name WHMCS is *actually* rendering this request with.
 *
 * The authoritative source is $vars['template'] from ClientAreaPage — WHMCS
 * passes the resolved template name (after applying ?systpl=, the systpl
 * cookie, per-user overrides, etc.) into every page render. We capture it
 * once and reuse it from hooks that don't receive $vars (PrimaryNavbar).
 *
 * \WHMCS\Config\Setting::getValue('Template') is the system DEFAULT, not the
 * current request, and must NOT be trusted for runtime detection — it lies
 * whenever a non-default template is being rendered for the visitor.
 */
function kf_active_template($vars = null) {
    static $cached = null;
    if (is_array($vars) && isset($vars['template']) && $vars['template'] !== '') {
        $cached = (string) $vars['template'];
    }
    return $cached;
}

/**
 * Expose configurable values + dynamic CSS to Smarty.
 * Templates reference $kf_logo, $kf_nav2_items, ..., $kf_dynamic_css.
 * Defaults handled in template files (theme works if addon disabled).
 *
 * Assigned to a variable so the SAME handler can be registered for both
 * ClientAreaPage (every regular client area page) AND ClientAreaPageCart
 * (cart.php — view cart, checkout, etc.). WHMCS fires these as two separate
 * hook events; without explicit dual registration, none of the addon's
 * Smarty vars get exposed on cart/checkout, which previously caused nav2
 * to leak past its visibility gate on those pages (the gate logic never
 * ran because $kf_nav2_enabled was never set).
 */
$kfFrontendVars = function ($vars) {
    // Capture the authoritative template name once per request so the
    // other hooks (HeadOutput, PrimaryNavbar) can read it back without
    // re-doing detection or trusting the system default Setting.
    kf_active_template($vars);

    try {
        $s = Settings::all();
    } catch (\Exception $e) {
        return [];
    }

    $out = [];

    // URL sanitizer for tile / card / social click URLs. Used by every
    // block that exposes admin-entered URLs to Smarty. Defined up front so
    // any consumer below can reference it. When an admin enters a
    // `javascript:` URL like `javascript:foo();return false;` the trailing
    // `return false;` silently fails — `return` is only valid inside a
    // function body, and bare `javascript:` URLs are evaluated as a script,
    // not a function. Browsers SyntaxError on it and the whole expression
    // never runs (chat widget never opens, etc.). We rewrite the trailing
    // `return false|true|null|undefined;?` to `void 0;` which is the
    // correct way to suppress navigation from a javascript: URL. Existing
    // admin-saved URLs get auto-fixed at render time so they don't have
    // to re-save anything.
    $fixJsUrl = function ($url) {
        if (!is_string($url) || stripos($url, 'javascript:') !== 0) return $url;
        return preg_replace(
            '/;\s*return\s+(?:false|true|null|undefined)\s*;?\s*$/i',
            ';void 0;',
            $url
        );
    };

    // ─── Dynamic CSS (override block, rendered after static styles) ──
    $css = Renderer::dynamicCss($s);
    if ($css !== '') {
        $out['kf_dynamic_css'] = $css;
    }

    // ─── Header / Logo ─────────────────────────────────────
    // Toggle defaults to ON for fresh installs (no row in DB).
    // When OFF, the entire navbar-brand area is hidden — no image, no
    // text fallback. (Earlier the OFF state showed the company name
    // as styled text; admins found that ugly when paired with a Top
    // Centered Logo, so OFF now means "fully hidden".)
    $out['kf_logo_show'] = !isset($s['header_logo_show']) || $s['header_logo_show'] === '1';
    if (!empty($s['header_logo'])) {
        $out['kf_logo'] = $s['header_logo'];
    }
    if (!empty($s['header_top_logo'])) {
        $out['kf_top_logo'] = $s['header_top_logo'];
    }

    // ─── Favicon ───────────────────────────────────────────
    // Rendered as <link rel="icon"> in <head>. Type is auto-derived
    // from the file extension so SVG/PNG/ICO/JPEG all work.
    $out['kf_favicon_url']  = isset($s['favicon_url']) ? trim($s['favicon_url']) : '';
    $out['kf_favicon_type'] = '';
    if ($out['kf_favicon_url'] !== '') {
        $ext = strtolower(pathinfo(parse_url($out['kf_favicon_url'], PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        $map = ['ico'=>'image/x-icon','png'=>'image/png','svg'=>'image/svg+xml','jpg'=>'image/jpeg','jpeg'=>'image/jpeg','gif'=>'image/gif','webp'=>'image/webp'];
        $out['kf_favicon_type'] = $map[$ext] ?? 'image/x-icon';
    }

    // ─── SEO / Open Graph meta ─────────────────────────────
    // Empty strings → template skips emitting that particular <meta>
    // tag so we don't ship blank ones into the page <head>.
    $out['kf_og_title']       = isset($s['og_title'])       ? trim($s['og_title'])       : '';
    $out['kf_og_description'] = isset($s['og_description']) ? trim($s['og_description']) : '';
    $out['kf_og_image']       = isset($s['og_image'])       ? trim($s['og_image'])       : '';

    // ─── Sitewide Announcement Bar ─────────────────────────
    // Bar renders only when enabled AND there's a message to show.
    // Message HTML is intentionally NOT escaped here (admin-only) so
    // <a>, <strong>, etc. work — the template renders with nofilter.
    $annEnabled = !empty($s['announcement_enabled']) && trim($s['announcement_message'] ?? '') !== '';
    $out['kf_announcement_enabled']     = $annEnabled;
    $out['kf_announcement_message']     = isset($s['announcement_message']) ? (string) $s['announcement_message'] : '';
    $out['kf_announcement_bg']          = isset($s['announcement_bg'])   && $s['announcement_bg']   !== '' ? $s['announcement_bg']   : '#22a04a';
    $out['kf_announcement_text']        = isset($s['announcement_text']) && $s['announcement_text'] !== '' ? $s['announcement_text'] : '#ffffff';
    $out['kf_announcement_dismissable'] = !isset($s['announcement_dismissable']) || $s['announcement_dismissable'] === '1';
    // Cache-bust the localStorage dismiss key whenever message text
    // changes — visitors who dismissed an old promo automatically see
    // a new one. The key is just a short hash of the current message.
    $out['kf_announcement_key'] = substr(md5($out['kf_announcement_message']), 0, 8);

    // ─── Custom HEAD / FOOTER HTML injection ───────────────
    // RAW pass-through (admin-only). Used for GA/GTM tags, chat
    // widgets, structured data, etc. Templates emit with nofilter.
    $out['kf_custom_head_html']   = isset($s['custom_head_html'])   ? (string) $s['custom_head_html']   : '';
    $out['kf_custom_footer_html'] = isset($s['custom_footer_html']) ? (string) $s['custom_footer_html'] : '';

    // ─── Header / Background ───────────────────────────────
    $bgType = isset($s['header_bg_type']) ? $s['header_bg_type'] : 'none';
    $out['kf_bg_type'] = $bgType;
    if ($bgType === 'video' && !empty($s['header_bg_video'])) {
        $out['kf_bg_video'] = $s['header_bg_video'];
    }
    if ($bgType === 'image' && !empty($s['header_bg_image'])) {
        $out['kf_bg_image'] = $s['header_bg_image'];
    }

    // ─── Header / Second navbar ────────────────────────────
    $nav2Enabled = !empty($s['header_nav2_enabled']);
    // Visibility gate: 'always' = render for everyone, 'logged_in' = only
    // when the current visitor is an authenticated client.
    //
    // Use $_SESSION['uid'] — WHMCS's authoritative session key for client
    // login state — instead of $vars['loggedin']/$vars['clientsdetails'].
    // On cart and checkout, WHMCS populates clientsdetails with whatever
    // billing data the visitor has entered into the order form, even
    // BEFORE creating an account; the !empty() check then evaluates as
    // "logged in" and nav2 leaks past the gate. $_SESSION['uid'] is
    // only set after a real client login completes, so it correctly
    // distinguishes guest-mid-checkout from authenticated client.
    if ($nav2Enabled && ($s['nav2_visibility'] ?? 'always') === 'logged_in') {
        $loggedIn = !empty($_SESSION['uid']);
        if (!$loggedIn) {
            $nav2Enabled = false;
        }
    }
    $out['kf_nav2_enabled'] = $nav2Enabled;
    if ($nav2Enabled && isset($s['nav2_items']) && is_array($s['nav2_items'])) {
        $out['kf_nav2_items'] = $s['nav2_items'];
    } else {
        $out['kf_nav2_items'] = [];
    }

    // ─── Header / Primary Navbar (Row 1) per-item config ───
    if (isset($s['nav1_items']) && is_array($s['nav1_items'])) {
        $out['kf_nav1_items'] = $s['nav1_items'];
    }

    // ─── Header / Notifications pill (logged-in only) ──────
    // Default ON for fresh installs (no row in DB). The template
    // additionally gates on $loggedin so guests never see it.
    $out['kf_notif_enabled'] = !array_key_exists('nav1_notif_enabled', $s)
        || $s['nav1_notif_enabled'] !== '0';

    // ─── Homepage / Hero ──────────────────────────────────
    // Eyebrow
    $out['kf_hero_eyebrow_enabled']  = !empty($s['hero_eyebrow_enabled']);
    $out['kf_hero_eyebrow_text']     = isset($s['hero_eyebrow_text']) ? $s['hero_eyebrow_text'] : '';

    // Motto — split main text on newlines into an array of lines
    $out['kf_hero_motto_enabled']    = !empty($s['hero_motto_enabled']);
    $mainRaw = isset($s['hero_motto_main']) ? (string) $s['hero_motto_main'] : '';
    $mottoLines = [];
    if ($mainRaw !== '') {
        foreach (preg_split('/\r\n|\r|\n/', $mainRaw) as $line) {
            $line = trim($line);
            if ($line !== '') $mottoLines[] = $line;
        }
    }
    $out['kf_hero_motto_lines']        = $mottoLines;
    $out['kf_hero_motto_accent']       = isset($s['hero_motto_accent']) ? $s['hero_motto_accent'] : '';
    // Hero accent color — picked from a 1-10 color rotation. With count=1
    // the behavior is identical to the old static color setup; with count>1
    // a random color is selected on every page render so the motto accent
    // + stats grid border cycle through the configured palette.
    //
    // Resolution: read the JSON-decoded color array, slice it to the
    // configured count, then array_rand. If anything's missing or invalid,
    // fall back to the legacy single-color key, then to a sensible default.
    $rotCount = max(1, min(10, (int) ($s['hero_motto_accent_count'] ?? 1)));
    $rotColors = $s['hero_motto_accent_colors'] ?? null;
    if (is_string($rotColors)) {
        $decoded = json_decode($rotColors, true);
        $rotColors = is_array($decoded) ? $decoded : null;
    }
    if (!is_array($rotColors) || empty($rotColors)) {
        $rotColors = [!empty($s['hero_motto_accent_color']) ? $s['hero_motto_accent_color'] : '#f87171'];
    }
    $rotColors = array_slice($rotColors, 0, $rotCount);
    if (empty($rotColors)) $rotColors = ['#f87171'];
    $out['kf_hero_motto_accent_color'] = $rotColors[array_rand($rotColors)];

    // Description
    $out['kf_hero_description_enabled'] = !empty($s['hero_description_enabled']);
    $out['kf_hero_description_text']    = isset($s['hero_description_text']) ? $s['hero_description_text'] : '';

    // Stats grid
    $out['kf_hero_stats_enabled'] = !empty($s['hero_stats_enabled']);
    $out['kf_hero_stats']         = (isset($s['hero_stats']) && is_array($s['hero_stats'])) ? $s['hero_stats'] : [];

    // Social bar (mirrors stats grid visually, sits directly below it).
    // Same web-root prefixing pattern as homepage cards so server-relative
    // image paths like "/templates/kwickflix/img/social/discord.svg" render
    // correctly on non-root WHMCS installs. Hidden tiles (visible='0') are
    // dropped here so the template doesn't need to filter them — that also
    // means an all-hidden config correctly hides the whole bar (the
    // kf_show_hero gate checks the resulting array's truthiness).
    $out['kf_hero_social_enabled'] = !empty($s['hero_social_enabled']);
    $socialItems = (isset($s['hero_social']) && is_array($s['hero_social']))
        ? array_values(array_filter($s['hero_social'], function ($soc) {
            return !isset($soc['visible']) || $soc['visible'] !== '0';
        }))
        : [];
    $webRoot = isset($vars['WEB_ROOT']) ? rtrim((string) $vars['WEB_ROOT'], '/') : '';
    foreach ($socialItems as &$soc) {
        if ($webRoot !== '' && !empty($soc['image']) && substr($soc['image'], 0, 1) === '/' && substr($soc['image'], 0, 2) !== '//') {
            $soc['image'] = $webRoot . $soc['image'];
        }
        // Auto-fix javascript: URLs that end with the invalid "return false;"
        // suffix — same treatment as stat tiles and info cards. $fixJsUrl is
        // defined at the top of this hook so it's already in scope here.
        if (isset($soc['url'])) $soc['url'] = $fixJsUrl($soc['url']);

        // Mark as external (= safe to open in new tab) for anything that
        // isn't a javascript: URL. javascript: URLs MUST stay in the
        // current tab — opening them with target=_blank pops a new tab,
        // evaluates the JS in that tab's empty context (where things like
        // $crisp don't exist), and leaves the user staring at a blank
        // page. Anchors / mailto / tel are also kept in-tab; we only
        // promote real http(s) URLs to a new tab.
        $url = is_string($soc['url'] ?? null) ? trim($soc['url']) : '';
        $lower = strtolower($url);
        $soc['_external'] = ($url !== '')
            && stripos($lower, 'javascript:') !== 0
            && stripos($lower, 'mailto:')     !== 0
            && stripos($lower, 'tel:')        !== 0
            && substr($url, 0, 1)             !== '#';
    }
    unset($soc);
    $out['kf_hero_social'] = $socialItems;

    // Logo marquee
    $out['kf_hero_marquee_enabled']   = !empty($s['hero_marquee_enabled']);
    // Default greyscale ON: if key missing, treat as ON. Only OFF when explicitly '0'.
    $out['kf_hero_marquee_greyscale'] = !array_key_exists('hero_marquee_greyscale', $s)
        || $s['hero_marquee_greyscale'] !== '0';
    $out['kf_hero_marquee_speed']     = isset($s['hero_marquee_speed']) ? $s['hero_marquee_speed'] : '1';
    $out['kf_hero_marquee_items']     = (isset($s['hero_marquee']) && is_array($s['hero_marquee'])) ? $s['hero_marquee'] : [];

    // Cart / Checkout marquee — same shape as hero marquee, different
    // settings namespace. Hook is registered on BOTH ClientAreaPage and
    // ClientAreaPageCart so these values are in scope on cart.php too.
    // Greyscale default ON to match hero behavior.
    $out['kf_checkout_marquee_enabled']   = !empty($s['checkout_marquee_enabled']);
    $out['kf_checkout_marquee_greyscale'] = !array_key_exists('checkout_marquee_greyscale', $s)
        || $s['checkout_marquee_greyscale'] !== '0';
    $out['kf_checkout_marquee_speed']     = isset($s['checkout_marquee_speed']) ? $s['checkout_marquee_speed'] : '1';
    $out['kf_checkout_marquee_items']     = (isset($s['checkout_marquee']) && is_array($s['checkout_marquee'])) ? $s['checkout_marquee'] : [];

    // Cart / Checkout notice boxes — three fixed-position editable alerts
    // rendered by configureproduct.tpl (CP) and checkout.tpl (CO_TOP +
    // CO_BOT). Each has: enabled, severity, icon, title, html.
    //
    // Defaults apply ONLY when the key has never been saved at all
    // (array_key_exists check). Once the admin has saved the form even
    // once, their exact values stick — including empty strings. This is
    // intentional so clearing the icon field actually removes the icon,
    // clearing the title gives a body-only notice, etc.
    //
    // All HTML blobs flow through $fixJsUrl so embedded
    // `javascript:...;return false;` handlers auto-correct to `void 0;`.
    $defaultNoticeCpHtml    = 'Have Questions? Contact a staff member before proceeding! <a href="#" onclick="$crisp.push([\'do\', \'chat:open\']);void 0;" class="alert-link">Click here to start a chat.</a>';
    $defaultNoticeCoBotHtml = 'Your store login details will be the email and password you create during checkout.';

    $sanitizeNoticeHtml = function ($html) use ($fixJsUrl) {
        if (!is_string($html) || $html === '') return $html;
        // Decode HTML entities. Some WHMCS / browser combinations re-encode
        // <br> etc as &lt;br&gt; during POST processing or admin XSS filters;
        // we want raw HTML in the rendered notice so links and line breaks
        // work. Loop the decode in case of accumulated double-encoding.
        $prev = null;
        $iter = 0;
        while ($prev !== $html && $iter < 8) {
            $prev = $html;
            $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $iter++;
        }
        return preg_replace_callback(
            '/(["\'])(javascript:[^"\']*?)(\1)/i',
            function ($m) use ($fixJsUrl) { return $m[1] . $fixJsUrl($m[2]) . $m[3]; },
            $html
        );
    };

    // Configure-product notice (defaults ON, with stock-like content)
    $out['kf_cart_notice_cp_enabled']  = !array_key_exists('cart_notice_cp_enabled', $s) || $s['cart_notice_cp_enabled'] === '1';
    $out['kf_cart_notice_cp_severity'] = isset($s['cart_notice_cp_severity']) && in_array($s['cart_notice_cp_severity'], ['success','info','warning','danger'], true)
        ? $s['cart_notice_cp_severity'] : 'warning';
    $out['kf_cart_notice_cp_icon']  = array_key_exists('cart_notice_cp_icon',  $s) ? $s['cart_notice_cp_icon']  : 'fas fa-question-circle';
    $out['kf_cart_notice_cp_title'] = array_key_exists('cart_notice_cp_title', $s) ? $s['cart_notice_cp_title'] : '';
    $out['kf_cart_notice_cp_html']  = $sanitizeNoticeHtml(array_key_exists('cart_notice_cp_html', $s) ? $s['cart_notice_cp_html'] : $defaultNoticeCpHtml);

    // Checkout-top notice (defaults OFF — replaces the old hardcoded Amazon promo box)
    $out['kf_cart_notice_co_top_enabled']  = !empty($s['cart_notice_co_top_enabled']);
    $out['kf_cart_notice_co_top_severity'] = isset($s['cart_notice_co_top_severity']) && in_array($s['cart_notice_co_top_severity'], ['success','info','warning','danger'], true)
        ? $s['cart_notice_co_top_severity'] : 'info';
    $out['kf_cart_notice_co_top_icon']  = array_key_exists('cart_notice_co_top_icon',  $s) ? $s['cart_notice_co_top_icon']  : '';
    $out['kf_cart_notice_co_top_title'] = array_key_exists('cart_notice_co_top_title', $s) ? $s['cart_notice_co_top_title'] : '';
    $out['kf_cart_notice_co_top_html']  = $sanitizeNoticeHtml(array_key_exists('cart_notice_co_top_html', $s) ? $s['cart_notice_co_top_html'] : '');

    // Checkout-bottom notice (defaults ON, with stock-like content)
    $out['kf_cart_notice_co_bot_enabled']  = !array_key_exists('cart_notice_co_bot_enabled', $s) || $s['cart_notice_co_bot_enabled'] === '1';
    $out['kf_cart_notice_co_bot_severity'] = isset($s['cart_notice_co_bot_severity']) && in_array($s['cart_notice_co_bot_severity'], ['success','info','warning','danger'], true)
        ? $s['cart_notice_co_bot_severity'] : 'warning';
    $out['kf_cart_notice_co_bot_icon']  = array_key_exists('cart_notice_co_bot_icon',  $s) ? $s['cart_notice_co_bot_icon']  : '';
    $out['kf_cart_notice_co_bot_title'] = array_key_exists('cart_notice_co_bot_title', $s) ? $s['cart_notice_co_bot_title'] : '';
    $out['kf_cart_notice_co_bot_html']  = $sanitizeNoticeHtml(array_key_exists('cart_notice_co_bot_html', $s) ? $s['cart_notice_co_bot_html'] : $defaultNoticeCoBotHtml);

    // ─── Homepage / Latest & Member Reviews block ─────────
    $out['kf_reviews_enabled']              = !empty($s['reviews_enabled']);
    $out['kf_reviews_announcement_enabled'] = !array_key_exists('reviews_announcement_enabled', $s)
        || $s['reviews_announcement_enabled'] !== '0';
    $out['kf_reviews_title']    = !empty($s['reviews_title'])    ? $s['reviews_title']    : 'Member Reviews';
    $out['kf_reviews_subtitle'] = !empty($s['reviews_subtitle']) ? $s['reviews_subtitle'] : 'Real feedback from real subscribers';
    $out['kf_reviews_items']    = (isset($s['reviews_items']) && is_array($s['reviews_items'])) ? $s['reviews_items'] : [];
    $out['kf_social_buttons_enabled'] = !array_key_exists('social_buttons_enabled', $s)
        || $s['social_buttons_enabled'] !== '0';
    $out['kf_social_buttons']   = (isset($s['social_buttons']) && is_array($s['social_buttons'])) ? $s['social_buttons'] : [];

    // ─── Client Area (clientareahome.tpl) ─────────────────
    //
    // (URL sanitizer $fixJsUrl is defined at the top of this hook so all
    //  consumers — stat tiles, info cards, social bar — can share it.)

    $out['kf_stat_tiles_enabled'] = !array_key_exists('stat_tiles_enabled', $s) || $s['stat_tiles_enabled'] !== '0';
    $statTilesRaw = (isset($s['stat_tiles']) && is_array($s['stat_tiles']))
        ? array_values(array_filter($s['stat_tiles'], function($t){ return !isset($t['visible']) || $t['visible'] !== '0'; }))
        : Settings::defaultStatTiles();
    foreach ($statTilesRaw as &$t) {
        if (isset($t['url'])) $t['url'] = $fixJsUrl($t['url']);
    }
    unset($t);
    $out['kf_stat_tiles'] = $statTilesRaw;

    // ─── Client credit balance ────────────────────────────
    // WHMCS does NOT expose the client's credit balance as a Smarty
    // variable in standard client-area templates — it's only visible in
    // the topbar Notifications popover (which we removed). The credit
    // value lives in tblclients.credit and has to be fetched + formatted
    // by hand if we want to surface it as a stat tile.
    //
    // We fetch the logged-in client's credit + currency and format with
    // WHMCS's global formatCurrency() helper when available (preferred —
    // respects locale, decimal separators, etc.). Falls back to manual
    // currency prefix/suffix from tblcurrencies if formatCurrency isn't
    // in scope for some reason. The template branch reads $kf_client_credit
    // and shows "--" when this is empty (guests, errors, or $0 with
    // formatCurrency unavailable).
    $out['kf_client_credit'] = '';
    $sessionUid = isset($_SESSION['uid']) ? (int) $_SESSION['uid'] : 0;
    if ($sessionUid > 0) {
        try {
            $row = \WHMCS\Database\Capsule::table('tblclients')
                ->where('id', $sessionUid)
                ->first(['credit', 'currency']);
            if ($row && isset($row->credit)) {
                $credit = (float) $row->credit;
                if (function_exists('formatCurrency')) {
                    $out['kf_client_credit'] = formatCurrency($credit);
                } else {
                    $cur = \WHMCS\Database\Capsule::table('tblcurrencies')
                        ->where('id', (int) ($row->currency ?? 0))
                        ->first(['prefix', 'suffix']);
                    $prefix = $cur ? (string) $cur->prefix : '';
                    $suffix = $cur ? (string) $cur->suffix : '';
                    $out['kf_client_credit'] = $prefix . number_format($credit, 2) . $suffix;
                }
            }
        } catch (\Throwable $e) {
            // Silent — leave empty, template renders "--"
        }
    }

    $out['kf_info_cards_enabled'] = !empty($s['info_cards_enabled']);
    $infoCards = (isset($s['info_cards']) && is_array($s['info_cards']))
        ? array_values(array_filter($s['info_cards'], function($c){ return !isset($c['visible']) || $c['visible'] !== '0'; }))
        : [];
    foreach ($infoCards as &$c) {
        if (isset($c['btn_url'])) $c['btn_url'] = $fixJsUrl($c['btn_url']);
    }
    unset($c);

    // Filter info cards by product ownership when product_ids is set on a
    // card. The admin enters a comma-separated list (e.g. "3,5,87"); only
    // clients with at least one ACTIVE hosting record matching one of those
    // package IDs see the card. Suspended/Terminated/Cancelled/Fraud all
    // count as "not entitled" — a suspended customer shouldn't see a
    // product-specific tile pitching add-ons or membership perks they
    // can't currently use. Empty product_ids = no gate.
    //
    // We resolve the current client ID from $vars['client'] (Smarty `$client`
    // is populated by WHMCS on client-area pages). If the page is not a
    // client-area page or the user isn't logged in, treat product_ids cards
    // as hidden — they're meant for logged-in product owners anyway.
    if (!empty($infoCards)) {
        $clientId = 0;
        if (isset($vars['client']) && is_object($vars['client']) && isset($vars['client']->id)) {
            $clientId = (int) $vars['client']->id;
        } elseif (isset($vars['client']['id'])) {
            $clientId = (int) $vars['client']['id'];
        } elseif (isset($vars['clientsdetails']['userid'])) {
            $clientId = (int) $vars['clientsdetails']['userid'];
        }

        // Cache of "does this client own product X" to avoid duplicate queries
        // when multiple cards reference the same product IDs.
        static $ownsCache = [];
        $ownsAny = function (array $productIds) use ($clientId, &$ownsCache) {
            if (empty($productIds) || $clientId <= 0) return false;
            sort($productIds);
            $cacheKey = $clientId . '|' . implode(',', $productIds);
            if (isset($ownsCache[$cacheKey])) return $ownsCache[$cacheKey];
            try {
                $owns = \WHMCS\Database\Capsule::table('tblhosting')
                    ->where('userid', $clientId)
                    ->whereIn('packageid', $productIds)
                    ->where('domainstatus', 'Active')
                    ->exists();
            } catch (\Exception $e) {
                // DB unavailable / table missing — fail closed (hide the card)
                // so admin's gating intent is respected even on error.
                $owns = false;
            }
            $ownsCache[$cacheKey] = $owns;
            return $owns;
        };

        $infoCards = array_values(array_filter($infoCards, function ($c) use ($ownsAny) {
            $raw = isset($c['product_ids']) ? trim((string) $c['product_ids']) : '';
            if ($raw === '') return true; // no gate — visible to everyone
            $ids = array_filter(array_map('intval', explode(',', $raw)), function ($n) { return $n > 0; });
            if (empty($ids)) return true; // malformed gate — fail open
            return $ownsAny($ids);
        }));
    }

    $out['kf_info_cards'] = $infoCards;
    $out['kf_panel_recent_tickets_hidden'] = !empty($s['panel_recent_tickets_hidden']);

    // ─── Footer ────────────────────────────────────────────
    $out['kf_footer_logo_show'] = !isset($s['footer_logo_show']) || $s['footer_logo_show'] === '1';
    if (!empty($s['footer_logo'])) {
        $out['kf_footer_logo'] = $s['footer_logo'];
    }
    if (!empty($s['footer_description'])) {
        $out['kf_footer_description'] = $s['footer_description'];
    }
    if (!empty($s['footer_col1_title'])) {
        $out['kf_footer_col1_title'] = $s['footer_col1_title'];
    }
    if (!empty($s['footer_col1_icon'])) {
        $out['kf_footer_col1_icon'] = $s['footer_col1_icon'];
    }
    if (!empty($s['footer_col2_title'])) {
        $out['kf_footer_col2_title'] = $s['footer_col2_title'];
    }
    if (!empty($s['footer_col2_icon'])) {
        $out['kf_footer_col2_icon'] = $s['footer_col2_icon'];
    }
    if (!empty($s['footer_col3_title'])) {
        $out['kf_footer_col3_title'] = $s['footer_col3_title'];
    }
    if (!empty($s['footer_col3_icon'])) {
        $out['kf_footer_col3_icon'] = $s['footer_col3_icon'];
    }

    // Footer link columns — three per-link repeaters. Each item has
    // {label,url,icon,target,enabled}. Filter to enabled only here so the
    // template can just foreach without checking each entry.
    $kfFilterEnabledFooter = function ($items) {
        if (!is_array($items)) return [];
        return array_values(array_filter($items, function ($i) {
            return !isset($i['enabled']) || $i['enabled'] !== '0';
        }));
    };
    if (isset($s['footer_col1_items']) && is_array($s['footer_col1_items'])) {
        $c1 = $kfFilterEnabledFooter($s['footer_col1_items']);
        if (!empty($c1)) $out['kf_footer_col1_links'] = $c1;
    }
    if (isset($s['footer_col2_items']) && is_array($s['footer_col2_items'])) {
        $c2 = $kfFilterEnabledFooter($s['footer_col2_items']);
        if (!empty($c2)) $out['kf_footer_col2_links'] = $c2;
    }
    if (isset($s['footer_col3_items']) && is_array($s['footer_col3_items'])) {
        $c3 = $kfFilterEnabledFooter($s['footer_col3_items']);
        if (!empty($c3)) $out['kf_footer_col3_links'] = $c3;
    }

    // ─── Cart/Checkout Payment Gateways ────────────────────
    // Admin-controlled per-gateway display (title/subtext/icon/preferred
    // ribbon) and ordering. Exposed as $kf_payment_gateways — an array of
    // visible entries in the order the admin saved them. The template
    // (checkout.tpl) iterates this and looks up each entry's matching
    // $gateways row by sysname to keep all the WHMCS-specific data
    // attributes (payment_type, show_local_cards, uses_remote_inputs)
    // attached to the radio input. Hidden entries and entries whose
    // gateway sysname doesn't match an active WHMCS gateway are skipped.
    //
    // The `icon_html` field is pre-rendered HTML for the icon slot:
    // - Image path / URL (starts with /, http://, or https://) → <img>
    // - Anything else → output as-is (emoji or HTML the admin pasted)
    // Done in PHP rather than Smarty so the template stays a single
    // light foreach (no per-row string slicing, no fragile |substr).
    $kfRenderIconHtml = function ($icon, $title) {
        $icon = (string) $icon;
        if ($icon === '') return '';
        $lead = substr($icon, 0, 8);
        if ($icon[0] === '/' || stripos($lead, 'http://') === 0 || stripos($lead, 'https://') === 0) {
            return '<img src="' . htmlspecialchars($icon, ENT_QUOTES) . '" alt="' . htmlspecialchars($title, ENT_QUOTES) . '" style="width:20px;height:20px;object-fit:contain;display:block;">';
        }
        return $icon; // emoji or raw HTML (FA tags, SVG, etc) — admin's responsibility to keep safe
    };

    // Helper to derive an rgba() string at low alpha from a hex color
    // so the inset glow halo is subtle. Returns empty string for invalid
    // input so the template can fall back to its default var().
    $kfHexToGlowRgba = function ($hex, $alpha = 0.22) {
        if (!is_string($hex) || !preg_match('/^#([A-Fa-f0-9]{6})$/', $hex, $m)) return '';
        $h = $m[1];
        $r = hexdec(substr($h, 0, 2));
        $g = hexdec(substr($h, 2, 2));
        $b = hexdec(substr($h, 4, 2));
        return "rgba($r,$g,$b,$alpha)";
    };

    $out['kf_payment_gateways'] = [];
    $out['kf_preferred_gateway'] = ''; // sysname of first preferred entry, if any
    // Section-level color overrides — see addon UI for what each controls.
    // Empty string when toggle is off in the admin → template falls back
    // to its built-in defaults.
    $out['kf_payment_ribbon_color']    = isset($s['payment_ribbon_color'])    ? (string) $s['payment_ribbon_color']    : '';
    $out['kf_payment_preferred_color'] = isset($s['payment_preferred_color']) ? (string) $s['payment_preferred_color'] : '';
    $out['kf_payment_preferred_glow']  = $kfHexToGlowRgba($out['kf_payment_preferred_color'], 0.28);
    if (isset($s['payment_gateways']) && is_array($s['payment_gateways'])) {
        foreach ($s['payment_gateways'] as $row) {
            if (!is_array($row)) continue;
            // Skip hidden rows
            if (isset($row['visible']) && $row['visible'] === '0') continue;
            // Skip entries with no gateway picked
            $sys = (string) ($row['gateway'] ?? '');
            if ($sys === '') continue;
            $title = (string) ($row['title'] ?? '');
            $icon  = (string) ($row['icon']  ?? '');
            $isPref = ($row['preferred'] ?? '0') === '1';
            $out['kf_payment_gateways'][] = [
                'gateway'         => $sys,
                'title'           => $title,
                'subtext'         => (string) ($row['subtext'] ?? ''),
                'icon'            => $icon,
                'icon_html'       => $kfRenderIconHtml($icon, $title),
                'preferred'       => $isPref,
                'preferred_label' => (string) ($row['preferred_label'] ?? 'PREFERRED'),
                // Per-row Border/Glow color override (empty string = use master accent).
                'accent'          => (string) ($row['accent'] ?? ''),
                'accent_glow'     => $kfHexToGlowRgba((string) ($row['accent'] ?? ''), 0.22),
            ];
            // Capture the FIRST preferred gateway — that's the one
            // auto-selected when the checkout page loads. If admin marks
            // multiple preferred, only the topmost (per their drag-and-drop
            // order) wins the default selection. Customer can still pick
            // any other option after page load.
            if ($isPref && $out['kf_preferred_gateway'] === '') {
                $out['kf_preferred_gateway'] = $sys;
            }
        }
    }

    // ─── Homepage cards ────────────────────────────────────
    // If saved cards exist AND non-empty → use them.
    // Otherwise (never saved, OR admin emptied) → seed with default placeholder.
    if (array_key_exists('homepage_cards', $s) && is_array($s['homepage_cards']) && !empty($s['homepage_cards'])) {
        $cards = $s['homepage_cards'];
    } else {
        $cards = Settings::defaultCards();
    }
    // Prefix server-relative image paths (e.g. /templates/...) with WEB_ROOT
    // so non-root WHMCS installs render correctly.
    $webRoot = isset($vars['WEB_ROOT']) ? rtrim((string) $vars['WEB_ROOT'], '/') : '';
    if ($webRoot !== '') {
        foreach ($cards as &$c) {
            if (!empty($c['image']) && substr($c['image'], 0, 1) === '/' && substr($c['image'], 0, 2) !== '//') {
                $c['image'] = $webRoot . $c['image'];
            }
        }
        unset($c);
    }
    $out['kf_homepage_cards'] = $cards;

    return $out;
};

// Register the same handler for both events. ClientAreaPage covers regular
// client area pages; ClientAreaPageCart covers cart.php (view cart, config,
// checkout). Without the cart registration, none of the kf_* Smarty vars get
// set on cart pages — which previously caused the nav2 visibility gate to
// silently fail there (and a handful of other things to render with defaults
// instead of admin-configured values).
add_hook('ClientAreaPage',     1, $kfFrontendVars);
add_hook('ClientAreaPageCart', 1, $kfFrontendVars);

/**
 * CRITICAL CSS hook — emits cart/user/badge color overrides into <head>
 * so they're parsed BEFORE the browser does first paint. Without this,
 * the theme's hardcoded teal badge (and any other defaults) renders for
 * ~100-300ms before the dynamic CSS at the end of footer.tpl loads —
 * users see a brief FLASH of the default color before it switches to
 * the admin's chosen color.
 *
 * Specificity hack: prefixed with `body` selector to bump every rule's
 * specificity by +1 element. Theme rules like `#mainNavbar a.cart-btn`
 * are (1,2,1); ours become `body #mainNavbar a.cart-btn` (1,2,2) — one
 * specificity tier higher, so they win regardless of source order. This
 * is critical because ClientAreaHeadOutput injects BEFORE the theme's
 * static <style> block, so without higher specificity our rules would
 * lose to the theme.
 */
add_hook('ClientAreaHeadOutput', 1, function ($vars) {
    // Template gate — definitive-only bail, matching navbar hook logic.
    // See ClientAreaPrimaryNavbar for full reasoning.
    //
    // Also emits a hidden HTML diagnostic comment showing what each
    // detection source returned. View page source on a kwickflix page;
    // search for "kwickflixstyle-detect" to see exactly what the gate saw.
    // Useful for debugging when nav items / cart glow stop appearing.

    // Make sure the active template is captured even if ClientAreaPage
    // didn't run first for some reason (defensive — usually a no-op).
    kf_active_template($vars);

    $diagVars    = (string) (kf_active_template() ?? '');
    $diagSysTpl  = (string) ($_REQUEST['systpl']  ?? '');
    $diagCartTpl = (string) ($_REQUEST['carttpl'] ?? '');
    $diagApp = '';
    try {
        if (class_exists('\App') && method_exists('\App', 'getActiveTemplate')) {
            $diagApp = (string) \App::getActiveTemplate();
        }
    } catch (\Throwable $e) {}
    $diagSetting = '';
    try {
        if (class_exists('\WHMCS\Config\Setting')) {
            $diagSetting = (string) \WHMCS\Config\Setting::getValue('Template');
        }
    } catch (\Throwable $e) {}

    // Definitive-only bail logic. Sources walked in priority order:
    //   1. $vars['template'] — authoritative (what WHMCS is rendering NOW)
    //   2. ?systpl=          — explicit URL override
    //   3. ?carttpl=         — cart-specific URL override
    //   4. App::getActiveTemplate() — often empty in early hooks
    //   5. Setting('Template')      — system DEFAULT, last resort only
    //
    // Setting is intentionally LAST. It's the system-wide default template,
    // not the template currently being rendered, and lies whenever a non-
    // default template is being served (cookie, systpl, per-user override).
    $kwickflixDetected = function ($v) {
        if ($v === null) return null;
        $v = trim((string) $v, "/ \t\n\r\0\x0B");
        if ($v === '') return null;
        return strcasecmp($v, 'kwickflix') === 0;
    };
    $sources = [
        $diagVars    ?: null,
        $diagSysTpl  ?: null,
        $diagCartTpl ?: null,
        $diagApp     ?: null,
        $diagSetting ?: null,
    ];
    $bailed = false;
    foreach ($sources as $src) {
        $r = $kwickflixDetected($src);
        if ($r === true) break;
        if ($r === false) { $bailed = true; break; }
    }

    // Emit diagnostic comment ALWAYS (even when bailed) so debugging is
    // possible without code changes. Pure HTML comment, no perf impact.
    $diag = sprintf(
        "<!-- kwickflixstyle-detect | vars=%s | systpl=%s | carttpl=%s | App=%s | Setting=%s | bailed=%s -->\n",
        addslashes($diagVars),
        addslashes($diagSysTpl),
        addslashes($diagCartTpl),
        addslashes($diagApp),
        addslashes($diagSetting),
        $bailed ? 'YES' : 'no'
    );

    if ($bailed) return $diag;

    try {
        $s = Settings::all();
    } catch (\Exception $e) {
        return $diag;
    }

    $rules = '';
    $isHex = function ($v) {
        return (bool) preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $v);
    };
    $hexToRgb = function ($hex) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
    };

    $cartColor = isset($s['nav1_cart_color']) ? trim($s['nav1_cart_color']) : '';
    if ($cartColor !== '' && $isHex($cartColor)) {
        // Icon + text color, pinned across :hover so theme's color reset doesn't steal it
        $rules .= "body #mainNavbar a.cart-btn,body #mainNavbar a.cart-btn:hover,body #mainNavbar a.cart-btn i{color:{$cartColor} !important;}";
    }

    $cartBadge = isset($s['nav1_cart_badge_color']) ? trim($s['nav1_cart_badge_color']) : '';
    if ($cartBadge !== '' && $isHex($cartBadge)) {
        // Badge bubble — injected in head so user never sees the theme's
        // hardcoded teal flash before this override applies.
        $rules .= "body #mainNavbar a.cart-btn .badge,body #mainNavbar a.cart-btn .badge-info,body .navbar-nav.toolbar a.cart-btn .badge-info{background-color:{$cartBadge} !important;border-color:{$cartBadge} !important;color:#fff !important;}";
    }

    $cartGlow = isset($s['nav1_cart_glow_color']) ? trim($s['nav1_cart_glow_color']) : '';
    if ($cartGlow !== '' && $isHex($cartGlow)) {
        $rgb = $hexToRgb($cartGlow);
        // SPECIFICITY MATTERS HERE. The theme's combined hover rule at
        // header.tpl line 175 includes `#mainNavbar ul.navbar-nav.ml-auto
        // > li > a:hover` — specificity (1,3,3) — which matches the
        // desktop cart because it sits inside ul.navbar-nav.ml-auto. A
        // simpler `body #mainNavbar a.cart-btn:hover` selector is only
        // (1,2,2) and LOSES to the theme, leaving the default green
        // fallback glow in place.
        //
        // The selectors below match the full structural path so each one
        // outranks (1,3,3):
        //   Desktop: body+#mainNavbar+ul.navbar-nav.ml-auto+li+a.cart-btn = (1,4,4)
        //   Mobile : body+#header  +ul.navbar-nav.toolbar+li+a.cart-btn  = (1,3,4)
        // Plus a fallback `body #mainNavbar a.cart-btn` (1,2,2) for any
        // child template variants that don't fit either structure.
        $glow = "rgba({$rgb},.65)";
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li > a.cart-btn,";
        $rules .= "body #header ul.navbar-nav.toolbar > li > a.cart-btn,";
        $rules .= "body #mainNavbar a.cart-btn{--kf-glow:{$glow} !important;}";
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li > a.cart-btn:hover,";
        $rules .= "body #header ul.navbar-nav.toolbar > li > a.cart-btn:hover,";
        $rules .= "body #mainNavbar a.cart-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px {$glow} !important;}";
    }

    $userGlow = isset($s['nav1_user_glow_color']) ? trim($s['nav1_user_glow_color']) : '';
    if ($userGlow !== '' && $isHex($userGlow)) {
        $rgb = $hexToRgb($userGlow);
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li.dropdown > a.dropdown-toggle,body #mainNavbar ul.navbar-nav.ms-auto > li.dropdown > a.dropdown-toggle{--kf-glow:rgba({$rgb},.65) !important;}";
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li.dropdown > a.dropdown-toggle:hover,body #mainNavbar ul.navbar-nav.ms-auto > li.dropdown > a.dropdown-toggle:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px rgba({$rgb},.65) !important;}";
    }

    // Notification pill — same critical-CSS treatment as the cart so the
    // configured colors show on first paint instead of FOUC-flashing the
    // default. Selectors mirror the cart-btn pattern (desktop in
    // ul.navbar-nav.ml-auto, mobile in .navbar-nav.toolbar).
    $notifColor = isset($s['nav1_notif_color']) ? trim($s['nav1_notif_color']) : '';
    if ($notifColor !== '' && $isHex($notifColor)) {
        $rules .= "body #mainNavbar a.notif-btn,body #mainNavbar a.notif-btn:hover,body #mainNavbar a.notif-btn i,body .navbar-nav.toolbar a.notif-btn,body .navbar-nav.toolbar a.notif-btn i{color:{$notifColor} !important;}";
    }
    $notifBadge = isset($s['nav1_notif_badge_color']) ? trim($s['nav1_notif_badge_color']) : '';
    if ($notifBadge !== '' && $isHex($notifBadge)) {
        $rules .= "body #mainNavbar a.notif-btn .badge,body #mainNavbar a.notif-btn .badge-info,body .navbar-nav.toolbar a.notif-btn .badge-info{background-color:{$notifBadge} !important;border-color:{$notifBadge} !important;color:#fff !important;}";
    }
    $notifGlow = isset($s['nav1_notif_glow_color']) ? trim($s['nav1_notif_glow_color']) : '';
    if ($notifGlow !== '' && $isHex($notifGlow)) {
        $rgb = $hexToRgb($notifGlow);
        $glow = "rgba({$rgb},.65)";
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li > a.notif-btn,";
        $rules .= "body #header ul.navbar-nav.toolbar > li > a.notif-btn,";
        $rules .= "body #mainNavbar a.notif-btn{--kf-glow:{$glow} !important;}";
        $rules .= "body #mainNavbar ul.navbar-nav.ml-auto > li > a.notif-btn:hover,";
        $rules .= "body #header ul.navbar-nav.toolbar > li > a.notif-btn:hover,";
        $rules .= "body #mainNavbar a.notif-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px {$glow} !important;}";
    }

    // Background greyscale filter — emitted into <head> so the browser
    // applies the filter on FIRST paint of the <video>/<img> bg element.
    // Without this, the same rule was only present in $kf_dynamic_css at
    // the end of footer.tpl, meaning the background painted in full color
    // for ~100-300ms before the filter applied — visible flash of color
    // before turning grey. (Renderer.php still emits the same rule in the
    // footer block; harmless duplicate, but the head version is what wins
    // the first-paint race.)
    if (!empty($s['header_bg_greyscale'])) {
        $rules .= ".kf-bg-image,.kf-bg-video{filter:grayscale(100%) brightness(1.85) contrast(.35) !important;-webkit-filter:grayscale(100%) brightness(1.85) contrast(.35) !important;opacity:.6 !important;}";
    }

    if ($rules === '') return $diag;
    return $diag . "<style id=\"kf-critical-css\">{$rules}</style>\n";
});

/**
 * Primary Navbar hook — adds, removes, and reorders items in the top navbar
 * based on the admin's Primary Navbar configuration.
 *
 * Why this exists: WHMCS renders DIFFERENT primary navbar items depending on
 * auth state (logged out shows many items; logged in collapses several into
 * the Account dropdown). Pure CSS-based hide/show only works on items that
 * WHMCS is actually rendering. To get consistent behavior across auth states,
 * we manipulate the navbar tree directly here.
 *
 * Why label-based lookup: WHMCS's getChild() looks up by INTERNAL NAME, not
 * by displayed label. Many native items have an internal name like 'account'
 * but display 'Client Area' — so getChild('Client Area') misses them, and
 * without a fallback the hook would add a duplicate "Client Area" pill next
 * to the existing one. We iterate children and match either by name OR by
 * displayed label to find native items reliably.
 *
 * Order: we explicitly setOrder() on every visible item in the admin's order
 * so the navbar respects the order the admin set in the addon UI. Without
 * this, native items keep their default WHMCS order regardless of the
 * admin's drag-and-drop reordering, and only added items respect their
 * configured index.
 */
// Hook priority 9999 — runs AFTER every other addon/module that hooks into
// ClientAreaPrimaryNavbar. Priority 1 (where this started) ran FIRST, which
// meant third-party addons (Free Store Credit, referral plugins, custom
// hooks) could add their items LATER and bypass strict mode's cleanup.
// Running last guarantees that by the time we walk the navbar tree, every
// other contributor has already added its items — so strict mode's "remove
// anything not in my list" pass actually catches them.
add_hook('ClientAreaPrimaryNavbar', 9999, function ($primaryNavbar) {
    // Template gate — DEFINITIVE-ONLY BAIL.
    //
    // We bail ONLY when a detection source explicitly returns a non-empty
    // template name that isn't kwickflix. If all sources return empty or
    // null, we run — the alternative (silently bailing on missing data)
    // caused nav items to disappear on installs where the detection APIs
    // weren't returning what we expected.
    //
    // Priority of checks:
    //   1. $vars['template'] captured by ClientAreaPage — AUTHORITATIVE
    //   2. ?systpl=                — explicit URL override
    //   3. ?carttpl=               — cart-specific URL override
    //   4. \App::getActiveTemplate() — often empty in early hooks
    //   5. \WHMCS\Config\Setting::getValue('Template') — system DEFAULT,
    //                                last resort only (lies whenever a
    //                                non-default template is rendering).
    //
    // For each, if it returns a non-empty value AND it's not 'kwickflix'
    // (case-insensitive), we bail. If it returns empty/null, we skip to
    // the next check. If all return empty/null, we run.
    //
    // $vars is NOT passed to this hook; we read the value captured by
    // ClientAreaPage via the kf_active_template() helper.
    $kwickflixDetected = function ($v) {
        if ($v === null) return null;  // unknown
        $v = trim((string) $v, "/ \t\n\r\0\x0B");
        if ($v === '') return null;  // unknown
        return strcasecmp($v, 'kwickflix') === 0;
    };
    $sources = [];
    $sources[] = kf_active_template();              // 1. authoritative
    $sources[] = $_REQUEST['systpl']  ?? null;      // 2. URL override
    $sources[] = $_REQUEST['carttpl'] ?? null;      // 3. cart URL override
    try {
        if (class_exists('\App') && method_exists('\App', 'getActiveTemplate')) {
            $sources[] = \App::getActiveTemplate(); // 4. App layer
        }
    } catch (\Throwable $e) {}
    try {
        if (class_exists('\WHMCS\Config\Setting')) {
            $sources[] = \WHMCS\Config\Setting::getValue('Template'); // 5. last resort
        }
    } catch (\Throwable $e) {}
    // Walk sources in priority order. The FIRST source that returns a
    // definitive yes/no decides. Only when ALL sources return null do we
    // fall through to "run" — the alternative was silently bailing on
    // installs where detection APIs returned empty.
    foreach ($sources as $src) {
        $r = $kwickflixDetected($src);
        if ($r === true)  break;    // definitively kwickflix → run
        if ($r === false) return;   // definitively not kwickflix → bail
        // null = unknown, try next source
    }

    try {
        $s = Settings::all();
    } catch (\Exception $e) {
        return;
    }

    if (empty($s['nav1_items']) || !is_array($s['nav1_items'])) {
        return;
    }

    /**
     * Locate a navbar item by either its internal name (preferred) OR its
     * displayed label. Returns the matching MenuItem object or null.
     *
     * Without the label fallback, items whose internal name diverges from
     * their label (e.g. 'account' internally / 'Client Area' on screen)
     * would be missed and duplicates would be added.
     */
    $findChild = function ($primaryNavbar, $label) {
        // Cheapest path first — direct name match
        $hit = $primaryNavbar->getChild($label);
        if ($hit !== null) return $hit;

        // Fall back to label scan across all children
        try {
            $kids = $primaryNavbar->getChildren();
        } catch (\Exception $e) {
            return null;
        }
        if (!is_array($kids)) return null;
        foreach ($kids as $kid) {
            if (!is_object($kid)) continue;
            try {
                $kidLabel = method_exists($kid, 'getLabel') ? $kid->getLabel() : '';
            } catch (\Exception $e) {
                $kidLabel = '';
            }
            if ((string) $kidLabel === (string) $label) {
                return $kid;
            }
        }
        return null;
    };

    /**
     * Return the internal name of a child for removal/lookup. Falls back
     * to label when getName() isn't available on older WHMCS versions.
     */
    $childName = function ($child, $label) {
        if (!is_object($child)) return $label;
        try {
            $n = method_exists($child, 'getName') ? $child->getName() : '';
        } catch (\Exception $e) {
            $n = '';
        }
        return $n !== '' ? $n : $label;
    };

    // Pass 1 — remove disabled items and add missing ones.
    // Pass 2 — set order on every visible item in the admin's array order.
    // Two passes so order isn't fighting with structural changes mid-loop.
    $visibleItemsInOrder = [];

    foreach ($s['nav1_items'] as $idx => $item) {
        $label = isset($item['label']) ? trim($item['label']) : '';
        if ($label === '') continue;
        $visible = !isset($item['visible']) || $item['visible'] !== '0';
        $existing = $findChild($primaryNavbar, $label);

        if (!$visible) {
            // Admin hid this item — remove using its actual internal name
            // (not the label) so the removal works even when WHMCS uses a
            // different internal name for this menu item.
            if ($existing !== null) {
                try {
                    $primaryNavbar->removeChild($childName($existing, $label));
                } catch (\Exception $e) {
                    // Some WHMCS versions error if the child isn't directly
                    // a top-level child (e.g. it's inside a dropdown). Try
                    // setVisible(false) as a fallback if the method exists.
                    if (method_exists($existing, 'setVisible')) {
                        try { $existing->setVisible(false); } catch (\Exception $e2) {}
                    }
                }
            }
            continue;
        }

        // visible=1: add it if missing AND we have a URL to use
        if ($existing === null) {
            $url = isset($item['url']) ? trim($item['url']) : '';
            if ($url === '') {
                continue;
            }
            try {
                $primaryNavbar->addChild($label, [
                    'label' => $label,
                    'uri'   => $url,
                    'order' => 50 + $idx,
                ]);
                $existing = $findChild($primaryNavbar, $label);
            } catch (\Exception $e) {
                continue;
            }
        }

        if ($existing !== null) {
            // Track for the ordering pass below
            $visibleItemsInOrder[] = ['item' => $existing, 'idx' => $idx];
        }
    }

    // Pass 2 — explicit ordering. setOrder() with sequential values forces
    // WHMCS's sort step to honor the admin's order regardless of whatever
    // default order WHMCS handed each native item.
    //
    // Start at 100 (not 0) so any unmanaged native items with low default
    // order values still slot in front if they should — admins can take
    // explicit control over an item by adding it to nav1; otherwise it
    // keeps its native position.
    $orderCursor = 100;
    foreach ($visibleItemsInOrder as $pair) {
        $child = $pair['item'];
        if (is_object($child) && method_exists($child, 'setOrder')) {
            try {
                $child->setOrder($orderCursor);
            } catch (\Exception $e) {}
        }
        $orderCursor += 10; // step by 10 so future inserts can squeeze in
    }

    // Pass 3 — STRICT MODE (optional). When the admin turns this on, the
    // navbar gets locked down to ONLY the items configured here. Anything
    // else WHMCS or another addon contributed gets removed.
    //
    // Why this exists: WHMCS hooks for the primary navbar are open to
    // every active addon/module, so third-party plugins (e.g. a Free Store
    // Credit module, a referral plugin) can drop pills into the navbar
    // without the admin's awareness. Strict mode is the explicit opt-out:
    // I built the nav, nothing else is allowed in it.
    //
    // Implementation: build a set of labels and names from the admin's
    // visible nav1 entries, then walk all remaining navbar children and
    // remove anything not in that set.
    if (!empty($s['nav1_strict_mode']) && $s['nav1_strict_mode'] === '1') {
        $allowedLabels = [];
        foreach ($s['nav1_items'] as $item) {
            $label = isset($item['label']) ? trim($item['label']) : '';
            if ($label === '') continue;
            $visible = !isset($item['visible']) || $item['visible'] !== '0';
            if (!$visible) continue;
            // Match by both label AND the internal name an admin-added
            // item would use (which is the label, per addChild() above).
            $allowedLabels[$label] = true;
        }

        try {
            $allChildren = $primaryNavbar->getChildren();
        } catch (\Exception $e) {
            $allChildren = [];
        }
        if (is_array($allChildren)) {
            foreach ($allChildren as $child) {
                if (!is_object($child)) continue;

                // Skip dropdowns (items with submenus). The "Account" dropdown
                // is the canonical case: its displayed label changes from
                // "Account" (logged out) to "Hello, {Name}!" (logged in), so
                // strict-mode label matching breaks. Native dropdowns are
                // also where WHMCS collapses Services/Billing/Support submenu
                // items when authenticated, and yanking them strips the
                // entire authenticated client experience. Leave dropdowns
                // alone — admins can hide individual items via the Hidden
                // toggle if they want to suppress one.
                $hasChildren = false;
                try {
                    if (method_exists($child, 'getChildren')) {
                        $kids = $child->getChildren();
                        $hasChildren = is_array($kids) && !empty($kids);
                    }
                } catch (\Exception $e) {}
                if ($hasChildren) continue;

                // Look up both internal name and displayed label so we
                // don't accidentally nuke a native item the admin matched
                // via a label-only entry.
                $name = '';
                $label = '';
                try {
                    $name  = method_exists($child, 'getName')  ? (string) $child->getName()  : '';
                    $label = method_exists($child, 'getLabel') ? (string) $child->getLabel() : '';
                } catch (\Exception $e) {}

                // Skip items with no displayable label at all (e.g. the cart
                // icon — name='cart' but label is often empty or just a
                // badge number). These are non-removable navbar fixtures the
                // admin probably doesn't want stripped.
                if (trim($name) === '' && trim($label) === '') continue;

                $isAllowed = isset($allowedLabels[$name]) || isset($allowedLabels[$label]);
                if ($isAllowed) continue;

                // Remove. Prefer name (more reliable identifier) over label.
                $rmKey = $name !== '' ? $name : $label;
                if ($rmKey === '') continue;
                try {
                    $primaryNavbar->removeChild($rmKey);
                } catch (\Exception $e) {
                    if (method_exists($child, 'setVisible')) {
                        try { $child->setVisible(false); } catch (\Exception $e2) {}
                    }
                }
            }
        }
    }
});
