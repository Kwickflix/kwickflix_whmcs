<?php
/**
 * KwickFlix Style addon - Dynamic CSS renderer
 *
 * Builds the small inline <style> block that overrides the static design
 * system in header.tpl based on the user's saved settings.
 *
 * Important: this output is injected into <head> by the ClientAreaHeadOutput
 * hook. It is NEVER written to disk and NEVER touches custom.css.
 */

namespace KwickFlixStyle;

class Renderer
{
    /**
     * Build the dynamic <style> block.
     *
     * @param array $s settings (already decoded, from Settings::all())
     * @return string
     */
    public static function dynamicCss(array $s)
    {
        $css = '';

        // ─── DEFENSIVE: Bootstrap hide-by-default for dropdowns + modals ──
        // Browsers that fail to load Bootstrap's CSS (asset path issues, slow
        // CDN, cache misses) leave .dropdown-menu and .modal rendering as
        // visible blocks because nothing in the cascade says "hide me". This
        // restores the expected behavior independently — dropdowns and modals
        // stay closed until JS (or Bootstrap 4's `.show` class) opens them.
        // Runs on every page via the head hook, so it covers homepage,
        // checkout, client area — everywhere navbar/modal chrome exists.
        $css .= 'body .dropdown-menu:not(.show){display:none !important;}';
        $css .= 'body .modal:not(.show):not(.in){display:none !important;}';

        // ─── Accent color override + broad coverage ──────────
        // Drives buttons, links, focus rings, badges everywhere on the site
        // (homepage, login, register, knowledgebase, announcements, etc.).
        $accent = isset($s['accent_color']) ? trim($s['accent_color']) : '';
        if ($accent && self::isHex($accent)) {
            $rgb  = self::hexToRgb($accent);
            $dark = self::darken($accent, 0.18);
            $light = self::darken($accent, -0.08); // slightly lighter for hover
            $css .= ":root{--ca-accent:{$accent};--ca-accent-dark:{$dark};--ca-accent-bg:rgba({$rgb},.07);--ca-accent-border:rgba({$rgb},.18);--ca-shadow-green:0 6px 24px rgba({$rgb},.22),0 2px 8px rgba({$rgb},.10);}";
            // Bootstrap btn-primary used on register/login/forms throughout WHMCS
            $css .= ".btn-primary,.btn.btn-primary,.btn-success,.btn.btn-success{background-color:{$accent} !important;border-color:{$accent} !important;color:#fff !important;}";
            $css .= ".btn-primary:hover,.btn-primary:focus,.btn-primary:active,.btn.btn-primary:hover,.btn.btn-primary:focus,.btn-success:hover,.btn-success:focus,.btn-success:active,.btn.btn-success:hover,.btn.btn-success:focus{background-color:{$dark} !important;border-color:{$dark} !important;color:#fff !important;box-shadow:0 0 0 3px rgba({$rgb},.18) !important;}";
            // Standard text/link colors that WHMCS uses across pages
            // Exclude .btn anchors so colored buttons (.btn-danger, .btn-success,
            // etc.) keep their white text on hover instead of being recolored.
            $css .= "a:not(.btn),a:not(.btn):link{color:{$accent};}a:not(.btn):hover,a:not(.btn):focus{color:{$dark};}";
            // Buttons used as <a> tags should always have white text — never let
            // the global a:hover pull the text color away from white.
            // Buttons used as <a> tags should always have white text — never let
            // the global a:hover pull the text color away from white. Covers ALL
            // common Bootstrap/WHMCS module button colors and their descendants
            // (some modules nest text in <span>/<i> inside the button).
            $css .= ".btn-primary,.btn-primary *,.btn-primary:hover,.btn-primary:focus,.btn-primary:active,"
                  . ".btn-success,.btn-success *,.btn-success:hover,.btn-success:focus,.btn-success:active,"
                  . ".btn-danger,.btn-danger *,.btn-danger:hover,.btn-danger:focus,.btn-danger:active,"
                  . ".btn-warning,.btn-warning *,.btn-warning:hover,.btn-warning:focus,.btn-warning:active,"
                  . ".btn-info,.btn-info *,.btn-info:hover,.btn-info:focus,.btn-info:active,"
                  . ".btn-dark,.btn-dark *,.btn-dark:hover,.btn-dark:focus,.btn-dark:active"
                  . "{color:#fff !important;}";
            // Also force any anchor/button INSIDE a custom-module form/panel to
            // inherit its button's white text instead of getting recolored by
            // a wrapping element's color rule. Specifically forces .btn anchors
            // and their descendants to white regardless of context.
            $css .= "a.btn-primary,a.btn-success,a.btn-danger,a.btn-warning,a.btn-info,a.btn-dark,"
                  . "a.btn-primary:link,a.btn-success:link,a.btn-danger:link,a.btn-warning:link,a.btn-info:link,a.btn-dark:link,"
                  . "a.btn-primary:visited,a.btn-success:visited,a.btn-danger:visited,a.btn-warning:visited,a.btn-info:visited,a.btn-dark:visited"
                  . "{color:#fff !important;}";
            $css .= ".text-primary,.text-info{color:{$accent} !important;}";
            $css .= ".bg-primary{background-color:{$accent} !important;}";
            // Form input focus — register, login, KB search, ticket forms
            $css .= ".form-control:focus,input.form-control:focus,textarea.form-control:focus,select.form-control:focus{border-color:{$accent} !important;box-shadow:0 0 0 3px rgba({$rgb},.15) !important;outline:none;}";
            // Bootstrap panel headings (KB / announcements use these)
            $css .= ".panel-primary>.panel-heading,.panel.panel-primary>.panel-heading{background-color:{$accent} !important;border-color:{$accent} !important;}";
            // Pagination + active list-group items
            $css .= ".pagination>.active>a,.pagination>.active>span,.pagination>.active>a:hover,.pagination>.active>span:hover{background-color:{$accent} !important;border-color:{$accent} !important;}";
            $css .= ".list-group-item.active,.list-group-item.active:hover,.list-group-item.active:focus{background-color:{$accent} !important;border-color:{$accent} !important;color:#fff !important;}";
            // Breadcrumb/navlink-active variants used in client area
            $css .= ".nav-pills>li.active>a,.nav-pills>li.active>a:hover,.nav-pills>li.active>a:focus{background-color:{$accent} !important;color:#fff !important;}";
            // Badges that WHMCS stamps across order/billing pages
            $css .= ".badge-primary,.label-primary{background-color:{$accent} !important;color:#fff !important;}";
            // Progress bars (knowledgebase rating / signup wizards)
            $css .= ".progress-bar,.progress-bar-info,.progress-bar-success{background-color:{$accent} !important;}";
            // Knowledgebase article links + announcement post titles
            $css .= ".kb-article a:not(.btn),.announcement-title a:not(.btn),.client-home-shortcuts a:not(.btn):hover{color:{$accent} !important;}";
            // Register/login sidebar panel — "Already Registered?", "New Customer?" panels
            // Panel/sidebar links get the accent color BUT must NEVER recolor
            // buttons or text inside buttons. CSS comma-separated selectors are
            // independent — :not(.btn) only applies to the selector it sits on,
            // so repeat it on every selector to actually exclude buttons globally.
            $css .= ".panel-sidebar a:not(.btn),.client-home-panels a:not(.btn),.sidebar a:not(.btn){color:{$accent};}";
            $css .= ".panel-sidebar a:not(.btn):hover,.client-home-panels a:not(.btn):hover,.sidebar a:not(.btn):hover{color:{$dark};}";
            // List-group items in sidebars (KB Categories, register sidebar, profile nav)
            // :not(.active) so the active item keeps its white text from the .active rule
            // below without this hover rule pulling color back to the accent.
            $css .= ".list-group-item:not(.active):hover{background-color:rgba({$rgb},.06) !important;}";
            $css .= ".list-group a.list-group-item:not(.active):hover{color:{$accent} !important;}";

            // ─── Sidebar — entire surface flattened ──────────────────
            // User wants the WHOLE sidebar flat, not just the items inside
            // widgets. Flatten the widget card containers themselves (less
            // rounded), kill internal section radii, kill all item radii.
            // The net effect is the sidebar reads as one unified surface
            // rather than three floating pills stacked on top of each other.
            $css .= ".sidebar .card,.sidebar .panel,.sidebar .panel-sidebar,.sidebar .sidebar-card"
                  . "{border-radius:8px !important;box-shadow:none !important;overflow:hidden !important;}";
            // Internal sections (headers, footers, bodies) inside sidebar
            // widgets are flat — no rounded corners that would create
            // visible seams against the parent card.
            $css .= ".sidebar .card .card-header,.sidebar .card .card-body,.sidebar .card .card-footer,"
                  . ".sidebar .panel .panel-heading,.sidebar .panel .panel-body,.sidebar .panel .panel-footer,"
                  . ".sidebar .sidebar-card .card-header,.sidebar .sidebar-card .card-body"
                  . "{border-radius:0 !important;}";
            // Lists / navs / item containers — no rounded corners anywhere
            $css .= ".sidebar .list-group,.sidebar .nav,.sidebar ul"
                  . "{border-radius:0 !important;margin:0 !important;}";

            // ─── Sidebar widget flattening ───────────────────────────
            // WHMCS Six (and many of its descendants) bundle CSS that gives
            // .list-group-item and .nav-pills .nav-link rounded corners +
            // margins inside sidebar widgets, so they render as floating
            // pills inside a card instead of as a clean list. Flatten them
            // so each item spans the full width of its container with just
            // a thin separator between rows. Active items become full-width
            // colored stripes instead of disembodied pills.
            //
            // Explicit corner overrides because Bootstrap targets
            // :first-child / :last-child with individual corner radii that
            // a single border-radius:0 doesn't reliably defeat when source
            // order isn't on our side.
            $flatItem = "border-radius:0 !important;"
                      . "border-top-left-radius:0 !important;"
                      . "border-top-right-radius:0 !important;"
                      . "border-bottom-left-radius:0 !important;"
                      . "border-bottom-right-radius:0 !important;"
                      . "margin:0 !important;"
                      // Setting border-color:transparent left the 1px border
                      // WIDTH intact, creating 2px of empty gap between items
                      // that still read as visible 'thick lines'. Zero out
                      // every side's width so items butt up against each
                      // other with no inter-item space at all.
                      . "border:0 !important;"
                      . "border-top:0 !important;"
                      . "border-bottom:0 !important;"
                      . "border-left:0 !important;"
                      . "border-right:0 !important;"
                      . "border-width:0 !important;";
            $css .= ".panel-sidebar .list-group-item,"
                  . ".sidebar .list-group-item,"
                  . ".sidebar .card .list-group-item,"
                  . ".sidebar .panel .list-group-item,"
                  . ".sidebar-card .list-group-item,"
                  . ".sidebar-card-body .list-group-item,"
                  . ".list-group-flush > .list-group-item"
                  . "{{$flatItem}}";
            $css .= ".panel-sidebar .list-group:first-child > .list-group-item:first-child,"
                  . ".sidebar .card .list-group:first-child > .list-group-item:first-child,"
                  . ".sidebar .panel .list-group:first-child > .list-group-item:first-child,"
                  . ".sidebar-card .list-group:first-child > .list-group-item:first-child"
                  . "{border-top:0 !important;}";
            $css .= ".panel-sidebar .list-group:last-child > .list-group-item:last-child,"
                  . ".sidebar .card .list-group:last-child > .list-group-item:last-child,"
                  . ".sidebar .panel .list-group:last-child > .list-group-item:last-child,"
                  . ".sidebar-card .list-group:last-child > .list-group-item:last-child"
                  . "{border-bottom:0 !important;}";

            // Same treatment for nav-pills used in tabbed sidebars (e.g. the
            // "Information" item in the Overview widget on service-details pages)
            $css .= ".panel-sidebar .nav-pills .nav-link,"
                  . ".sidebar .nav-pills .nav-link,"
                  . ".sidebar .card .nav-pills .nav-link,"
                  . ".sidebar .panel .nav-pills .nav-link"
                  . "{border-radius:0 !important;margin:0 !important;}";
            // Force the active nav-pill into the accent color and full-width
            $css .= ".panel-sidebar .nav-pills .nav-link.active,"
                  . ".sidebar .nav-pills .nav-link.active,"
                  . ".sidebar .card .nav-pills .nav-link.active,"
                  . ".sidebar .panel .nav-pills .nav-link.active"
                  . "{background-color:{$accent} !important;color:#fff !important;border-radius:0 !important;}";

            // STACKED BUTTON ITEMS in sidebar widgets (e.g. WHMCS Six's
            // Shortcuts panel rendered as <a class="btn btn-block ..."> in
            // a card-body). When there are two or more siblings of .btn-block
            // we treat them as navigation rows, not standalone actions: strip
            // the border-radius and side borders so they read as a flat list.
            // Single .btn-block buttons (like a lone "Update" or "+ New
            // Contact" action) are left alone because they have no .btn-block
            // sibling to match the `.btn-block + .btn-block` selector.
            $css .= ".panel-sidebar .btn-block + .btn-block,"
                  . ".sidebar .card .btn-block + .btn-block,"
                  . ".sidebar .panel .btn-block + .btn-block,"
                  . ".sidebar-card-body .btn-block + .btn-block,"
                  . ".client-home-shortcuts .btn-block + .btn-block"
                  . "{border-radius:0 !important;border-left:0 !important;border-right:0 !important;border-top:0 !important;margin-top:0 !important;text-align:left !important;}";
            // Also strip the FIRST in such a stack — it has no preceding sibling
            // so the + selector won't catch it. Detect via :has() (modern browsers)
            // and fall back to :first-child for safety.
            $css .= ".panel-sidebar .card-body:has(.btn-block + .btn-block) > .btn-block:first-child,"
                  . ".sidebar .card-body:has(.btn-block + .btn-block) > .btn-block:first-child,"
                  . ".client-home-shortcuts:has(.btn-block + .btn-block) > .btn-block:first-child"
                  . "{border-radius:0 !important;border-left:0 !important;border-right:0 !important;text-align:left !important;}";
            // KB tag cloud + KB article meta
            $css .= ".tag-cloud a,.kb-tags a,.knowledgebase-article a{color:{$accent};}";
            $css .= ".tag-cloud a:hover,.kb-tags a:hover,.knowledgebase-article a:hover{color:{$dark};}";
            // Bootstrap btn-default hover (Generate Password / Lost Password Reset / cancel buttons)
            $css .= ".btn-default:hover,.btn-secondary:hover,.btn.btn-default:hover{border-color:{$accent} !important;color:{$accent} !important;background-color:rgba({$rgb},.04) !important;}";
            // Bootstrap btn-outline-primary
            $css .= ".btn-outline-primary{border-color:{$accent} !important;color:{$accent} !important;}";
            $css .= ".btn-outline-primary:hover,.btn-outline-primary:focus{background-color:{$accent} !important;border-color:{$accent} !important;color:#fff !important;}";
            // Dropdown menu items (account dropdown, store dropdown)
            $css .= ".dropdown-menu>.active>a,.dropdown-menu>.active>a:hover,.dropdown-menu>.active>a:focus,.dropdown-item.active,.dropdown-item:active{background-color:{$accent} !important;color:#fff !important;}";
            $css .= ".dropdown-menu .dropdown-item:hover,.dropdown-menu>li>a:hover{color:{$accent} !important;background-color:rgba({$rgb},.06) !important;}";
            // Panel/card heading active state for "Personal Information", "Account Security" etc.
            $css .= ".panel-default>.panel-heading[aria-expanded=\"true\"],.card-header[aria-expanded=\"true\"]{color:{$accent} !important;}";
            // Bootstrap alerts that use the primary/info color
            $css .= ".alert-info{border-left:3px solid {$accent};}";
            // Knowledgebase \"Most Popular Articles\" article-row icons
            $css .= ".article-icon,.kb-article-list .fa,.kb-article-list .fas{color:{$accent} !important;}";
            // Generic primary-colored borders/dividers/highlights
            $css .= ".border-primary{border-color:{$accent} !important;}";
            // Caret/chevron in collapsible panels (\"Already Registered?\" expand toggle)
            $css .= ".panel-heading[role=\"tab\"] .caret,.panel-heading.collapsible .caret,.panel-title[aria-expanded] .caret{color:{$accent};}";
        }

        // ─── Master glow color (default --ca-glow at :root level) ─
        // Per-item glows still override this for individual nav buttons.
        $glow = isset($s['accent_glow_color']) ? trim($s['accent_glow_color']) : '';
        if ($glow && self::isHex($glow)) {
            $glowRgb = self::hexToRgb($glow);
            // Set on :root so cascades reach any element using var(--ca-glow)
            $css .= ":root{--ca-glow:rgba({$glowRgb},.65);}";
            // Override the static default --kf-glow set on > li > a in header.tpl
            // for nav1, nav2, and account dropdown — but NOT cart-btn (special cyan).
            $css .= "#mainNavbar ul#nav > li > a,#mainNavbar ul.kf-nav-row2 > li > a,#mainNavbar ul.navbar-nav.ml-auto > li > a{--kf-glow:rgba({$glowRgb},.65) !important;}";
        }

        // ─── Site/page background color (when type === color) ───
        $bgType = isset($s['header_bg_type']) ? $s['header_bg_type'] : 'none';
        if ($bgType === 'color') {
            $bgColor = isset($s['header_bg_color']) ? trim($s['header_bg_color']) : '';
            if ($bgColor && self::isHex($bgColor)) {
                $css .= "body.primary-bg-color{background:{$bgColor} !important;}";
            }
        }

        // ─── Hide overlay if user wants raw image/video without dim ───
        if (!empty($s['header_bg_no_overlay'])) {
            $css .= ".kf-bg-overlay{display:none !important;}";
        }

        // ─── Greyscale image/video background (washed-out look) ───
        // Pushed hard to make the bg almost white — admins use this to mute
        // colorful imagery so foreground content stays readable.
        if (!empty($s['header_bg_greyscale'])) {
            $css .= ".kf-bg-image,.kf-bg-video{filter:grayscale(100%) brightness(1.85) contrast(.35) !important;-webkit-filter:grayscale(100%) brightness(1.85) contrast(.35) !important;opacity:.6 !important;}";
        }

        // ─── Marquee speed multiplier (overrides 60s baseline) ─
        if (!empty($s['hero_marquee_enabled'])) {
            $mult = isset($s['hero_marquee_speed']) ? floatval($s['hero_marquee_speed']) : 1.0;
            if ($mult > 0 && $mult !== 1.0) {
                $duration = round(60 / $mult, 1);
                $css .= ".kf-hp-logos-track{animation-duration:{$duration}s !important;}";
            }
        }

        // ─── Client Area: stat tile accent colors ────────────────────
        // Emits .kf-tilebar-N { background: <color> !important } rules where
        // N matches the index of each VISIBLE tile in the template foreach.
        // We filter and re-index here using array_values() so the indices
        // line up exactly with the template's key=kf_tile_idx in the foreach.
        //
        // This mirrors the bg-color-X pattern WHMCS Six bundles — direct
        // inline styles on .highlight don't reliably show because Six's
        // bundled CSS appears to defeat them in certain auth/page contexts.
        // The dynamic CSS lives at the end of footer.tpl so it wins source
        // order regardless of where other declarations sit.
        if (!empty($s['stat_tiles']) && is_array($s['stat_tiles'])) {
            $visibleTiles = array_values(array_filter($s['stat_tiles'], function ($t) {
                return !isset($t['visible']) || $t['visible'] !== '0';
            }));
            foreach ($visibleTiles as $idx => $t) {
                $color = !empty($t['color']) && self::isHex($t['color']) ? $t['color'] : '#22a04a';
                $css .= ".kf-tilebar-{$idx}{background:{$color} !important;}";
            }
        } else {
            // Fresh install — emit defaults so colors show out of the box
            $defaults = \KwickFlixStyle\Settings::defaultStatTiles();
            foreach ($defaults as $idx => $t) {
                $color = !empty($t['color']) && self::isHex($t['color']) ? $t['color'] : '#22a04a';
                $css .= ".kf-tilebar-{$idx}{background:{$color} !important;}";
            }
        }

        // ─── Client Area: custom info card top-border colors ─
        // Per-card color applied via inline style on the rendered .card,
        // but we also drop a fallback CSS rule using data-idx for safety.
        if (!empty($s['info_cards']) && is_array($s['info_cards'])) {
            $cardIdx = 0;
            foreach ($s['info_cards'] as $c) {
                if (isset($c['visible']) && $c['visible'] === '0') continue;
                $cardIdx++;
                if (!empty($c['color']) && self::isHex($c['color'])) {
                    $css .= ".kf-info-card[data-kf-info-idx=\"{$cardIdx}\"]{border-top:3px solid {$c['color']} !important;}";
                }
            }
        }

        // ─── Client Area: built-in WHMCS panel accents ──────
        // Targets the [menuItemName="..."] attribute set in clientareahome.tpl
        // for each panel iterated from $panels. Overrides the static
        // card-accent-{color} class assignments.
        $panelMap = [
            'panel_active_products' => 'Active Products/Services',
            'panel_recent_tickets'  => 'Recent Support Tickets',
            'panel_recent_news'     => 'Recent News',
            'panel_affiliate'       => 'Affiliate Program',
        ];
        foreach ($panelMap as $settingKey => $menuName) {
            if (!empty($s[$settingKey]) && self::isHex($s[$settingKey])) {
                $css .= ".client-home-cards .card[menuItemName=\"{$menuName}\"]{border-top:3px solid {$s[$settingKey]} !important;}";
            }
        }

        // Hide entire client-home-cards panels via admin toggles. WHMCS
        // sets a `menuItemName` attribute on each .card so we can target
        // them by friendly name — same pattern used above for the
        // panel-accent color overrides.
        if (!empty($s['panel_recent_news_hidden'])) {
            $css .= ".client-home-cards .card[menuItemName=\"Recent News\"]{display:none !important;}";
        }
        if (!empty($s['panel_affiliate_hidden'])) {
            $css .= ".client-home-cards .card[menuItemName=\"Affiliate Program\"]{display:none !important;}";
        }
        if (!empty($s['panel_recent_tickets_hidden'])) {
            $css .= ".client-home-cards .card[menuItemName=\"Recent Support Tickets\"]{display:none !important;}";
        }

        // ─── Hide left sidebar (admin toggle in General → Layout) ────
        // Hides both primary and secondary sidebars across every client
        // area page and expands the .primary-content column to 12 cols.
        // Target the sidebar's grid column so the gap collapses cleanly.
        if (!empty($s['sidebar_hidden'])) {
            $css .= "#main-body .col-lg-4.col-xl-3:has(> .sidebar),#main-body .col-lg-4.col-xl-3:has(> .d-none.d-lg-block.sidebar){display:none !important;}";
            // Fallback for browsers that don't support :has() — hide the
            // inner .sidebar directly and shrink-wrap the wrapper column.
            $css .= "#main-body .sidebar,#main-body .d-lg-none.sidebar-secondary{display:none !important;}";
            $css .= "#main-body > .container > .row > .col-lg-4.col-xl-3{display:none !important;}";
            // Expand the primary content column to full width
            $css .= "#main-body .col-lg-8.col-xl-9.primary-content{flex:0 0 100% !important;max-width:100% !important;}";
        }

        // ─── Reviews marquee speed (220s baseline — long because there are
        //     usually many cards and they need to be readable) ───────────
        if (!empty($s['reviews_enabled'])) {
            $mult = isset($s['reviews_marquee_speed']) ? floatval($s['reviews_marquee_speed']) : 1.0;
            if ($mult > 0 && $mult !== 1.0) {
                $duration = round(220 / $mult, 1);
                $css .= ".kf-hp-reviews-track{animation-duration:{$duration}s !important;}";
            }
        }

        // ─── Primary Navbar (Row 1) per-item colors + glow ───
        // Important: per-item rules MUST be more specific than the master-glow
        // override above (which has selector specificity (0,2,0,3) thanks to
        // #mainNavbar + ul#nav). Prefixing with the same ancestors gives us
        // (0,3,0,3) so per-item wins both the cascade AND the !important duel.
        if (!empty($s['nav1_items']) && is_array($s['nav1_items'])) {
            foreach ($s['nav1_items'] as $item) {
                if (empty($item['label'])) continue;
                // WHMCS replaces spaces with underscores in the rendered ID
                $id = '#Primary_Navbar-' . str_replace(' ', '_', $item['label']);

                // Visibility — admin can uncheck "Visible in navbar" to hide
                // an item without losing its other settings.
                if (array_key_exists('visible', $item) && $item['visible'] === '0') {
                    $css .= "{$id}{display:none !important;}";
                    // Skip color rules for hidden items — no point computing
                    continue;
                }

                if (!empty($item['icon_color']) && self::isHex($item['icon_color'])) {
                    $css .= "#mainNavbar ul#nav {$id} i{color:{$item['icon_color']} !important;}";
                }
                if (!empty($item['glow_color']) && self::isHex($item['glow_color'])) {
                    $rgb = self::hexToRgb($item['glow_color']);
                    $css .= "#mainNavbar ul#nav {$id} > a{--kf-glow:rgba({$rgb},.65) !important;}";
                }
            }
        }

        // ─── Secondary Navbar (Row 2) per-item colors + glow ───
        // Items are rendered in order, targeted via nth-child since they
        // don't have stable WHMCS IDs like Primary Navbar items do.
        if (!empty($s['nav2_items']) && is_array($s['nav2_items'])) {
            $i = 0;
            foreach ($s['nav2_items'] as $item) {
                $i++;
                if (!empty($item['glow_color']) && self::isHex($item['glow_color'])) {
                    $rgb = self::hexToRgb($item['glow_color']);
                    // Inline style on <li> can't beat the static rule on `> li > a`
                    // — must target the <a> directly with !important.
                    $css .= "#mainNavbar ul.kf-nav-row2 > li:nth-child({$i}) > a{--kf-glow:rgba({$rgb},.65) !important;}";
                }
                if (!empty($item['icon_color']) && self::isHex($item['icon_color'])) {
                    $css .= "#mainNavbar ul.kf-nav-row2 > li:nth-child({$i}) > a i{color:{$item['icon_color']} !important;}";
                }
            }
        }

        // ─── Locked nav fixtures — Cart + User dropdown ───────────────
        // The Cart pill and the User/Hello dropdown sit in fixed positions
        // (top-right of the navbar) regardless of the admin's nav1 ordering.
        //
        // Cart targets — the theme renders the cart as
        //   <a class="btn nav-link cart-btn" href=".../cart.php?a=view">
        //     <i class="fa-shopping-cart"></i>
        //     <span class="badge">{count}</span>
        //   </a>
        // We target .cart-btn directly because header.tpl already has a
        // rule `#mainNavbar a.cart-btn{--kf-glow:rgba(0,180,180,.65);}` —
        // matching that selector means equal specificity and source-order
        // (footer.tpl after header.tpl) reliably overrides it.
        $cartColor = isset($s['nav1_cart_color']) ? trim($s['nav1_cart_color']) : '';
        if ($cartColor !== '' && self::isHex($cartColor)) {
            // Tint icon + text. Pin across :hover too because the theme's
            // hover rule sets color:#13110e !important which would steal
            // our admin-set color back on hover.
            $css .= "#mainNavbar a.cart-btn,#mainNavbar a.cart-btn:hover,#mainNavbar a.cart-btn i{color:{$cartColor} !important;}";
        }

        $cartBadge = isset($s['nav1_cart_badge_color']) ? trim($s['nav1_cart_badge_color']) : '';
        if ($cartBadge !== '' && self::isHex($cartBadge)) {
            // The theme hardcodes background-color:#00b4b4 !important on
            // .badge inside .cart-btn — equal specificity (1 ID + 2 classes
            // each side), so source order wins, and footer.tpl comes after
            // header.tpl. Override background, border, AND keep text white.
            $css .= "#mainNavbar a.cart-btn .badge,#mainNavbar a.cart-btn .badge-info,.navbar-nav.toolbar a.cart-btn .badge-info{background-color:{$cartBadge} !important;border-color:{$cartBadge} !important;color:#fff !important;}";
        }

        $cartGlow = isset($s['nav1_cart_glow_color']) ? trim($s['nav1_cart_glow_color']) : '';
        if ($cartGlow !== '' && self::isHex($cartGlow)) {
            $rgb = self::hexToRgb($cartGlow);
            // Two-pronged glow:
            //   (1) Set --kf-glow so the theme's existing :hover rule
            //       picks it up (preserves the theme's own glow shape).
            //   (2) Emit an EXPLICIT :hover box-shadow rule that uses our
            //       color directly — defends against anything later
            //       resetting the variable, and ensures the glow renders
            //       even on browsers / setups where the var override is
            //       being beaten by source-order quirks.
            $css .= "#mainNavbar a.cart-btn{--kf-glow:rgba({$rgb},.65) !important;}";
            $css .= "#mainNavbar a.cart-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px rgba({$rgb},.65) !important;}";
        }

        // User/Hello dropdown — the rightmost dropdown in the navbar.
        $userGlow = isset($s['nav1_user_glow_color']) ? trim($s['nav1_user_glow_color']) : '';
        if ($userGlow !== '' && self::isHex($userGlow)) {
            $rgb = self::hexToRgb($userGlow);
            $css .= "#mainNavbar ul.navbar-nav.ml-auto > li.dropdown > a.dropdown-toggle,#mainNavbar ul.navbar-nav.ms-auto > li.dropdown > a.dropdown-toggle,#mainNavbar .kf-user-dropdown > a{--kf-glow:rgba({$rgb},.65) !important;}";
            // Explicit :hover box-shadow as a belt-and-suspenders measure,
            // matching the cart treatment above.
            $css .= "#mainNavbar ul.navbar-nav.ml-auto > li.dropdown > a.dropdown-toggle:hover,#mainNavbar ul.navbar-nav.ms-auto > li.dropdown > a.dropdown-toggle:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px rgba({$rgb},.65) !important;}";
        }

        // Notification pill — same treatment as the cart. The pill only
        // renders for logged-in clients (gated in header.tpl), but the CSS
        // is emitted unconditionally; it's a no-op when the element is
        // absent and keeps the rule set symmetrical with the cart's.
        $notifColor = isset($s['nav1_notif_color']) ? trim($s['nav1_notif_color']) : '';
        if ($notifColor !== '' && self::isHex($notifColor)) {
            $css .= "#mainNavbar a.notif-btn,#mainNavbar a.notif-btn:hover,#mainNavbar a.notif-btn i,.navbar-nav.toolbar a.notif-btn,.navbar-nav.toolbar a.notif-btn i{color:{$notifColor} !important;}";
        }
        $notifBadge = isset($s['nav1_notif_badge_color']) ? trim($s['nav1_notif_badge_color']) : '';
        if ($notifBadge !== '' && self::isHex($notifBadge)) {
            $css .= "#mainNavbar a.notif-btn .badge,#mainNavbar a.notif-btn .badge-info,.navbar-nav.toolbar a.notif-btn .badge-info{background-color:{$notifBadge} !important;border-color:{$notifBadge} !important;color:#fff !important;}";
        }
        $notifGlow = isset($s['nav1_notif_glow_color']) ? trim($s['nav1_notif_glow_color']) : '';
        if ($notifGlow !== '' && self::isHex($notifGlow)) {
            $rgb = self::hexToRgb($notifGlow);
            $css .= "#mainNavbar a.notif-btn{--kf-glow:rgba({$rgb},.65) !important;}";
            $css .= "#mainNavbar a.notif-btn:hover{box-shadow:0 4px 14px rgba(0,0,0,.12),0 0 18px rgba({$rgb},.65) !important;}";
        }

        if ($css === '') {
            return '';
        }

        $out = "<style id=\"kf-dynamic-css\">{$css}</style>\n";

        // ─── Client-side strict-mode enforcement ──────────────────────
        // The ClientAreaPrimaryNavbar hook runs server-side at priority
        // 9999, AFTER every other addon contributes. That catches static
        // server-rendered items.
        //
        // SOME addons inject navbar items via JavaScript AFTER the page
        // renders — those bypass the server-side hook entirely. To catch
        // them too, emit a small JS pass that walks the rendered nav on
        // load + on a MutationObserver, removing any pill whose label
        // isn't in the admin's allowed list.
        //
        // Only emitted when strict_mode is on and there are configured
        // items — otherwise the JS is dead code and we don't ship it.
        if (!empty($s['nav1_strict_mode']) && $s['nav1_strict_mode'] === '1'
            && !empty($s['nav1_items']) && is_array($s['nav1_items'])) {
            $allowed = [];
            foreach ($s['nav1_items'] as $item) {
                $label = isset($item['label']) ? trim($item['label']) : '';
                if ($label === '') continue;
                $visible = !isset($item['visible']) || $item['visible'] !== '0';
                if (!$visible) continue;
                $allowed[] = $label;
            }
            if (!empty($allowed)) {
                $allowedJson = json_encode($allowed, JSON_UNESCAPED_SLASHES);
                $js  = "(function(){";
                $js .= "var allowed=" . $allowedJson . ";";
                $js .= "var allowedSet=Object.create(null);allowed.forEach(function(l){allowedSet[l.toLowerCase()]=true;});";
                // Extract just the FIRST significant text run from an anchor,
                // ignoring icons, badges, and nested spans. We collect direct
                // child text nodes from <a>, plus the first text node found
                // inside a wrapper. This avoids matching against textContent
                // like "IPTV Channels 0" (badge) or "Hello, Test!" (logged-in
                // account dropdown), which would falsely remove legit items.
                $js .= "function labelOf(a){";
                $js .= "if(!a)return '';";
                // Try direct text children first
                $js .= "var direct='';for(var i=0;i<a.childNodes.length;i++){var n=a.childNodes[i];";
                $js .= "if(n.nodeType===3){direct+=n.nodeValue;}";
                // Also pull text from non-badge spans (so multi-span labels work)
                $js .= "else if(n.nodeType===1&&n.tagName!=='I'&&!(n.className||'').match(/badge|sr-only|caret/i)){direct+=(n.textContent||'');}";
                $js .= "}";
                $js .= "return direct.replace(/\\s+/g,' ').trim();";
                $js .= "}";
                $js .= "function sweep(){";
                $js .= "var bar=document.getElementById('mainNavbar');if(!bar)return;";
                $js .= "var items=bar.querySelectorAll('ul#nav > li, ul.navbar-nav > li');";
                $js .= "items.forEach(function(li){";
                // Skip dropdowns — they have a <ul.dropdown-menu> child and
                // their displayed label may differ from configured labels
                // (e.g. "Hello, {Name}!" when logged in). Server-side strict
                // mode already skips dropdowns; JS does the same.
                $js .= "if(li.querySelector('.dropdown-menu')||li.classList.contains('dropdown'))return;";
                $js .= "var a=li.querySelector('a,button');if(!a)return;";
                $js .= "var txt=labelOf(a);";
                // Empty label (icon-only items like cart) — leave alone
                $js .= "if(!txt||txt.length<2)return;";
                $js .= "if(!allowedSet[txt.toLowerCase()]){li.style.display='none';}";
                $js .= "});";
                $js .= "}";
                $js .= "if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',sweep);}else{sweep();}";
                $js .= "if(window.MutationObserver){var mo=new MutationObserver(sweep);";
                $js .= "var t=document.getElementById('mainNavbar');";
                $js .= "if(t){mo.observe(t,{childList:true,subtree:true});}";
                $js .= "setTimeout(function(){mo.disconnect();},8000);}";
                $js .= "})();";
                $out .= "<script id=\"kf-strict-nav\">" . $js . "</script>\n";
            }
        }

        return $out;
    }

    /**
     * Build a Smarty-safe array of nav row 2 items from raw saved value.
     *
     * @param mixed $raw stored value (either array or pipe-string)
     * @return array
     */
    public static function nav2Items($raw)
    {
        if (is_array($raw)) {
            return $raw;
        }
        if (is_string($raw)) {
            return Settings::parseLines($raw, ['title', 'link', 'color', 'icon', 'target']);
        }
        return [];
    }

    /**
     * Build footer column links from saved value.
     *
     * @param mixed $raw
     * @return array
     */
    public static function footerLinks($raw)
    {
        if (is_array($raw)) {
            return $raw;
        }
        if (is_string($raw)) {
            return Settings::parseLines($raw, ['label', 'url', 'target']);
        }
        return [];
    }

    // ─── helpers ──────────────────────────────────────────

    private static function isHex($v)
    {
        return (bool) preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $v);
    }

    private static function hexToRgb($hex)
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
    }

    private static function darken($hex, $ratio = 0.2)
    {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        }
        $r = max(0, min(255, (int) round(hexdec(substr($hex, 0, 2)) * (1 - $ratio))));
        $g = max(0, min(255, (int) round(hexdec(substr($hex, 2, 2)) * (1 - $ratio))));
        $b = max(0, min(255, (int) round(hexdec(substr($hex, 4, 2)) * (1 - $ratio))));
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
}
