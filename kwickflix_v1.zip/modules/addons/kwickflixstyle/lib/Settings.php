<?php
/**
 * KwickFlix Style addon - Settings storage helper
 *
 * Simple key/value wrapper around the mod_kwickflixstyle_settings table.
 * Complex values (arrays) are JSON-encoded automatically.
 *
 * Storage is intentionally NOT in custom.css. Settings are read at runtime
 * by the hooks and either:
 *   - injected as inline <style> via ClientAreaHeadOutput, or
 *   - exposed as Smarty variables via ClientAreaPage.
 */

namespace KwickFlixStyle;

use WHMCS\Database\Capsule;

class Settings
{
    const TABLE = 'mod_kwickflixstyle_settings';

    /**
     * Get a single setting (decodes JSON if applicable).
     *
     * @param string $key
     * @param mixed  $default
     * @return mixed
     */
    public static function get($key, $default = null)
    {
        try {
            $row = Capsule::table(self::TABLE)->where('setting_key', $key)->first();
        } catch (\Exception $e) {
            return $default;
        }
        if (!$row) {
            return $default;
        }
        $val = $row->setting_value;
        // Try JSON decode for complex values
        if ($val !== null && $val !== '' && (substr($val, 0, 1) === '[' || substr($val, 0, 1) === '{')) {
            $decoded = json_decode($val, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $decoded;
            }
        }
        return $val;
    }

    /**
     * Get all settings as an associative array.
     *
     * @return array
     */
    public static function all()
    {
        $out = [];
        try {
            $rows = Capsule::table(self::TABLE)->get();
        } catch (\Exception $e) {
            return $out;
        }
        foreach ($rows as $row) {
            $val = $row->setting_value;
            if ($val !== null && $val !== '' && (substr($val, 0, 1) === '[' || substr($val, 0, 1) === '{')) {
                $decoded = json_decode($val, true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $val = $decoded;
                }
            }
            $out[$row->setting_key] = $val;
        }
        return $out;
    }

    /**
     * Set a setting (encodes arrays as JSON).
     *
     * @param string $key
     * @param mixed  $value
     */
    public static function set($key, $value)
    {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value);
        }
        try {
            $exists = Capsule::table(self::TABLE)->where('setting_key', $key)->first();
            if ($exists) {
                Capsule::table(self::TABLE)
                    ->where('setting_key', $key)
                    ->update(['setting_value' => $value, 'updated_at' => date('Y-m-d H:i:s')]);
            } else {
                Capsule::table(self::TABLE)->insert([
                    'setting_key'   => $key,
                    'setting_value' => $value,
                    'created_at'    => date('Y-m-d H:i:s'),
                    'updated_at'    => date('Y-m-d H:i:s'),
                ]);
            }
        } catch (\Exception $e) {
            // swallow — addon should not crash the page
        }
    }

    /**
     * Bulk set: takes an array of key=>value pairs.
     *
     * @param array $values
     */
    public static function setMany(array $values)
    {
        foreach ($values as $k => $v) {
            self::set($k, $v);
        }
    }

    /**
     * Parse a pipe-separated nav/link list into an array of items.
     *
     * Format for nav items:   Title|URL|#hexcolor|fa-icon-class|target
     * Format for footer links: Label|URL|target
     *
     * Empty lines and lines starting with # are ignored.
     *
     * @param string $raw
     * @param array  $fields ordered field names
     * @return array
     */
    public static function parseLines($raw, array $fields)
    {
        $items = [];
        if (!$raw || !is_string($raw)) {
            return $items;
        }
        $lines = preg_split("/\r\n|\n|\r/", $raw);
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '#') === 0) {
                continue;
            }
            $parts = array_map('trim', explode('|', $line));
            $row = [];
            foreach ($fields as $i => $f) {
                $row[$f] = isset($parts[$i]) ? $parts[$i] : '';
            }
            // require at least the first two fields
            if (!empty($row[$fields[0]]) && !empty($row[$fields[1]])) {
                $items[] = $row;
            }
        }
        return $items;
    }

    /**
     * Reverse: convert an items array back to pipe-separated lines (for editing).
     *
     * @param array $items
     * @param array $fields ordered field names
     * @return string
     */
    public static function itemsToLines($items, array $fields)
    {
        if (!is_array($items) || empty($items)) {
            return '';
        }
        $lines = [];
        foreach ($items as $it) {
            $parts = [];
            foreach ($fields as $f) {
                $parts[] = isset($it[$f]) ? $it[$f] : '';
            }
            // trim trailing empty parts for cleaner output
            while (count($parts) > 0 && end($parts) === '') {
                array_pop($parts);
            }
            $lines[] = implode('|', $parts);
        }
        return implode("\n", $lines);
    }

    /**
     * Returns the default placeholder cards array used when nothing is saved.
     * Used by both the admin editor (initial state) and the front-end hook
     * (so the homepage shows something on a fresh install or after a delete-all).
     *
     * Image URL is server-relative; the hook prefixes WEB_ROOT on read so
     * non-root WHMCS installs work correctly.
     *
     * @return array
     */
    public static function defaultCards()
    {
        return [
            [
                'enabled'     => '1',
                'title'       => 'Placeholder',
                'subtitle'    => 'This is a placeholder',
                'description' => '',
                'link'        => '#',
                'bullet1'     => 'placeholder',
                'bullet2'     => 'placeholder',
                'bullet3'     => 'placeholder',
                'accent'      => '#5a5249',
                'image'       => '/templates/kwickflix/img/homepagecard-placeholder.jpg',
            ],
        ];
    }

    /**
     * Returns the default Primary Navbar (Row 1) items pre-populated in the
     * admin editor on a fresh install. Covers every item WHMCS renders by
     * default in the primary navbar — plus optional URL/icon so the addon's
     * ClientAreaPrimaryNavbar hook can ADD items that WHMCS isn't rendering
     * (e.g. when the user is logged in and many items collapse into menus).
     *
     * The hook ALSO uses these entries to authoritatively remove items where
     * visible=0, regardless of how WHMCS internally IDs them. That's why
     * hiding by label is more reliable than CSS — WHMCS internal item IDs
     * vary by auth state and config.
     *
     * @return array
     */
    public static function defaultNav1Items()
    {
        return [
            ['label' => 'Home',              'url' => 'index.php',                                'icon' => 'fas fa-home',            'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Store',             'url' => 'index.php?rp=/store',                      'icon' => 'fas fa-shopping-bag',    'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Announcements',     'url' => 'announcements.php',                        'icon' => 'fas fa-bullhorn',        'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Knowledgebase',     'url' => 'knowledgebase.php',                        'icon' => 'fas fa-book',            'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Network Status',    'url' => 'serverstatus.php',                         'icon' => 'fas fa-tower-broadcast', 'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Affiliates',        'url' => 'affiliates.php',                           'icon' => 'fas fa-chart-network',   'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Contact Us',        'url' => 'contact.php',                              'icon' => 'fas fa-id-card',         'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Account',           'url' => 'clientarea.php',                           'icon' => 'fas fa-user',            'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Services',          'url' => 'clientarea.php?action=services',           'icon' => 'fas fa-cube',            'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Billing',           'url' => 'clientarea.php?action=invoices',           'icon' => 'fas fa-credit-card',     'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Support',           'url' => 'supporttickets.php',                       'icon' => 'fas fa-life-ring',       'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
            ['label' => 'Open Ticket',       'url' => 'submitticket.php',                         'icon' => 'fas fa-ticket',          'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '1'],
        ];
    }

    /**
     * Returns the list of WHMCS-default item labels that should always be
     * present in the nav1 config (re-injected if missing). Centralized here
     * so both the UI render path and the POST save path agree on what
     * counts as "default".
     */
    public static function defaultNav1Labels()
    {
        $labels = [];
        foreach (self::defaultNav1Items() as $i) {
            $labels[] = $i['label'];
        }
        return $labels;
    }

    /**
     * Given a saved nav1 list, ensure every default label is present (re-add
     * any missing ones to the END with their default settings). Used on both
     * UI render and POST save so admins can never accidentally lose defaults.
     */
    public static function ensureNav1Defaults(array $items)
    {
        $present = [];
        foreach ($items as $i) {
            if (!empty($i['label'])) $present[] = $i['label'];
        }
        foreach (self::defaultNav1Items() as $default) {
            if (!in_array($default['label'], $present, true)) {
                $items[] = $default;
            }
        }
        // Force protected flag on any item whose label matches a default,
        // in case it was saved under an older version without the flag.
        $defaultLabels = self::defaultNav1Labels();
        foreach ($items as &$i) {
            if (!empty($i['label']) && in_array($i['label'], $defaultLabels, true)) {
                $i['protected'] = '1';
            } else {
                $i['protected'] = '0';
            }
        }
        unset($i);
        return $items;
    }

    /**
     * Default Client Area stat tiles (the row of 4 cards at the top of
     * clientareahome). Each tile's `stat` value chooses which $clientsstats
     * field to display. URLs can be relative paths or full URLs. The
     * "javascript:" scheme is also allowed for things like opening a chat
     * widget.
     *
     * Supported stat sources:
     *   services       → $clientsstats.productsnumactive
     *   domains        → $clientsstats.numactivedomains
     *   invoices       → $clientsstats.numunpaidinvoices
     *   tickets        → $clientsstats.numactivetickets
     *   affiliates     → $clientsstats.numaffiliatesignups
     *   quotes         → $clientsstats.numquotes
     *   credit         → $clientsstats.credit_balance (formatted currency string)
     *   dashes         → renders "--" (for non-stat tiles like Live Chat)
     */
    public static function defaultStatTiles()
    {
        return [
            ['title' => 'Services',    'icon' => 'fas fa-cube',        'color' => '#1a6fff', 'stat' => 'services', 'url' => 'clientarea.php?action=services', 'visible' => '1'],
            ['title' => 'Domains',     'icon' => 'fas fa-globe',       'color' => '#22a04a', 'stat' => 'domains',  'url' => 'clientarea.php?action=domains',  'visible' => '1'],
            ['title' => 'Invoices',    'icon' => 'fas fa-credit-card', 'color' => '#d97706', 'stat' => 'invoices', 'url' => 'clientarea.php?action=invoices', 'visible' => '1'],
            ['title' => 'Live Chat',   'icon' => 'fas fa-headset',     'color' => '#cc2828', 'stat' => 'dashes',   'url' => '#',                              'visible' => '1'],
        ];
    }

    /**
     * Default WHMCS panel accent colors. Each key is the menu item name as
     * WHMCS exposes it via $item->getName() in clientareahome.tpl. Renderer
     * emits CSS rules targeting [menuItemName="<name>"] to override the
     * built-in card-accent-{color} class assignments.
     */
    public static function defaultPanelAccents()
    {
        return [
            'active_products' => '#1a6fff',
            'recent_tickets'  => '#cc2828',
            'recent_news'     => '#d97706',
            'affiliate'       => '#22a04a',
        ];
    }
}
