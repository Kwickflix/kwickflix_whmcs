<?php
/**
 * KwickFlix Style — WHMCS Addon Module
 *
 * Configures the kwickflix template's customizable bits:
 *   - Header: custom logo, top centered logo, second-row navbar items (toggle + per-item title/link/glow color/icon),
 *             whole-page background (blank / color / image / video)
 *   - Homepage: (placeholder for future expansion)
 *   - Footer: logo, short description, 3 fully-configurable column titles + link lists
 *   - Client Area: accent color override
 *   - General: master accent color
 *
 * Settings are stored in mod_kwickflixstyle_settings (key/value, JSON for arrays).
 * NO custom.css is created — at runtime hooks.php injects a small <style> block
 * via ClientAreaHeadOutput and exposes Smarty vars via ClientAreaPage.
 */

if (!defined('WHMCS')) {
    die('This file cannot be accessed directly');
}

require_once __DIR__ . '/lib/Settings.php';
require_once __DIR__ . '/lib/Renderer.php';

use KwickFlixStyle\Settings;
use WHMCS\Database\Capsule;

/**
 * Module configuration / metadata.
 */
function kwickflixstyle_config()
{
    return [
        'name'        => 'KwickFlix Style',
        'description' => 'Configures the KwickFlix template — header (logo, second navbar, background), footer (columns, logo, description), and client area styling. No custom.css used.',
        'version'     => '1.0.0',
        'author'      => 'KwickFlix',
        // No native fields — all configuration happens in the rich tabbed UI in _output().
        'fields'      => [],
    ];
}

/**
 * Activate: create the settings table.
 */
function kwickflixstyle_activate()
{
    try {
        if (!Capsule::schema()->hasTable(Settings::TABLE)) {
            Capsule::schema()->create(Settings::TABLE, function ($table) {
                $table->increments('id');
                $table->string('setting_key', 191)->unique();
                $table->longText('setting_value')->nullable();
                $table->timestamp('created_at')->nullable();
                $table->timestamp('updated_at')->nullable();
            });
        }
        return [
            'status'      => 'success',
            'description' => 'KwickFlix Style activated. Configure it from the addon page.',
        ];
    } catch (\Exception $e) {
        return [
            'status'      => 'error',
            'description' => 'Activation failed: ' . $e->getMessage(),
        ];
    }
}

/**
 * Deactivate: keep the table (so settings persist across re-activations).
 * If you want a clean wipe, uncomment the drop below.
 */
function kwickflixstyle_deactivate()
{
    return [
        'status'      => 'success',
        'description' => 'KwickFlix Style deactivated. Settings preserved.',
    ];
    // Uncomment to fully remove on deactivate:
    // Capsule::schema()->dropIfExists(Settings::TABLE);
}

function kwickflixstyle_upgrade($vars)
{
    // Reserved for future schema upgrades.
}

/**
 * Render the tabbed admin UI.
 */
function kwickflixstyle_output($vars)
{
    $modulelink = $vars['modulelink'];
    $message    = '';

    // ─── Handle "Replace all settings with this JSON" (Settings Import) ──
    // Runs BEFORE the regular save so it doesn't conflict. The import button
    // submits the form with kf_import_action=import (instead of kf_save=1),
    // so this branch catches it exclusively.
    if (!empty($_POST['kf_import_action']) && $_POST['kf_import_action'] === 'import') {
        $raw = (string) ($_POST['import_json'] ?? '');
        $decoded = json_decode($raw, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            $message = '<div style="background:rgba(204,40,40,.08);border:1px solid rgba(204,40,40,.20);color:#7d1818;padding:10px 14px;border-radius:8px;margin-bottom:14px;"><strong>Import failed:</strong> the pasted text isn\'t valid JSON. (' . htmlspecialchars(json_last_error_msg()) . ')</div>';
        } else {
            // Write every key. Settings::save() handles array auto-encoding.
            $written = 0;
            foreach ($decoded as $k => $v) {
                if (!is_string($k) || $k === '') continue;
                Settings::save($k, $v);
                $written++;
            }
            $message = '<div style="background:rgba(34,160,74,.08);border:1px solid rgba(34,160,74,.20);color:#185a2c;padding:10px 14px;border-radius:8px;margin-bottom:14px;"><strong>Import complete:</strong> wrote ' . (int) $written . ' setting' . ($written === 1 ? '' : 's') . '. The page below has been refreshed with the imported values.</div>';
        }
    }

    // ─── Handle POST save ────────────────────────────────
    if (!empty($_POST['kf_save'])) {
        // Process Primary Navbar (Row 1) items into a clean array.
        $nav1Items = [];
        if (!empty($_POST['nav1']) && is_array($_POST['nav1'])) {
            foreach ($_POST['nav1'] as $row) {
                if (!is_array($row)) continue;
                $label = kfStyleCleanText($row['label'] ?? '');
                if ($label === '') continue;  // label is the only required field
                $nav1Items[] = [
                    'label'      => $label,
                    'url'        => kfStyleCleanText($row['url'] ?? ''),
                    'icon'       => kfStyleCleanText($row['icon'] ?? ''),
                    'icon_color' => kfStyleHexOrEmpty($row['icon_color'] ?? ''),
                    'glow_color' => kfStyleHexOrEmpty($row['glow_color'] ?? ''),
                    // Checkbox present-and-set = visible; absent = hidden. Empty string '0' = hidden.
                    'visible'    => (!empty($row['visible'])) ? '1' : '0',
                    // 'protected' is reset by ensureNav1Defaults() based on
                    // label match — admins can't promote/demote items.
                ];
            }
        }
        // Re-inject any missing WHMCS default items so admins can never
        // accidentally lose them. Also enforces the protected flag based on
        // canonical default labels.
        $nav1Items = \KwickFlixStyle\Settings::ensureNav1Defaults($nav1Items);

        // Process Second Navbar Row items into a clean array.
        $nav2Items = [];
        if (!empty($_POST['nav2']) && is_array($_POST['nav2'])) {
            foreach ($_POST['nav2'] as $row) {
                if (!is_array($row)) continue;
                $title = kfStyleCleanText($row['title'] ?? '');
                $url   = kfStyleCleanText($row['url']   ?? '');
                if ($title === '' || $url === '') continue; // both required
                $nav2Items[] = [
                    'title'      => $title,
                    'url'        => $url,
                    'icon'       => kfStyleCleanText($row['icon'] ?? ''),
                    'icon_color' => kfStyleHexOrEmpty($row['icon_color'] ?? ''),
                    'glow_color' => kfStyleHexOrEmpty($row['glow_color'] ?? ''),
                    'target'     => (($row['target'] ?? '') === '_blank') ? '_blank' : '',
                ];
            }
        }

        // Process Hero stats array.
        $heroStats = [];
        if (!empty($_POST['hero_stats']) && is_array($_POST['hero_stats'])) {
            foreach ($_POST['hero_stats'] as $row) {
                if (!is_array($row)) continue;
                $num   = kfStyleCleanText($row['number'] ?? '');
                $label = kfStyleCleanText($row['label']  ?? '');
                if ($num === '' && $label === '') continue;
                $heroStats[] = [
                    'number'    => $num,
                    'highlight' => kfStyleCleanText($row['highlight'] ?? ''),
                    'label'     => $label,
                ];
            }
        }

        // Process Hero social bar array. Each item: image (URL, optional),
        // icon (Font Awesome class, fallback when no image), icon_color
        // (optional hex override; when blank, icon inherits the master
        // accent via the hero --kf-hero-accent CSS var), label, url, and
        // a visible toggle so an admin can park a tile without deleting it.
        // Items with no url AND no label AND no image AND no icon are dropped
        // (nothing to show — empty noise).
        $heroSocial = [];
        if (!empty($_POST['hero_social']) && is_array($_POST['hero_social'])) {
            foreach ($_POST['hero_social'] as $row) {
                if (!is_array($row)) continue;
                $label = kfStyleCleanText($row['label'] ?? '');
                $url   = kfStyleCleanText($row['url']   ?? '');
                $image = kfStyleCleanText($row['image'] ?? '');
                $icon  = kfStyleCleanText($row['icon']  ?? '');
                if ($label === '' && $url === '' && $image === '' && $icon === '') continue;
                $heroSocial[] = [
                    'image'      => $image,
                    'icon'       => $icon,
                    'icon_color' => kfStyleHexOrEmpty($row['icon_color'] ?? ''),
                    'label'      => $label,
                    'url'        => $url,
                    'visible'    => !empty($row['visible']) ? '1' : '0',
                ];
            }
        }

        // Process Hero marquee items array.
        $heroMarquee = [];
        if (!empty($_POST['hero_marquee']) && is_array($_POST['hero_marquee'])) {
            foreach ($_POST['hero_marquee'] as $row) {
                if (!is_array($row)) continue;
                $url = kfStyleCleanText($row['url'] ?? '');
                if ($url === '') continue;
                $heroMarquee[] = [
                    'url' => $url,
                    'alt' => kfStyleCleanText($row['alt'] ?? ''),
                ];
            }
        }

        // Process Checkout (cart) marquee items array — same row shape as
        // hero_marquee, separate namespace so the cart can scroll a
        // different logo set (e.g. crypto icons, payment methods) than the
        // homepage hero.
        $checkoutMarquee = [];
        if (!empty($_POST['checkout_marquee']) && is_array($_POST['checkout_marquee'])) {
            foreach ($_POST['checkout_marquee'] as $row) {
                if (!is_array($row)) continue;
                $url = kfStyleCleanText($row['url'] ?? '');
                if ($url === '') continue;
                $checkoutMarquee[] = [
                    'url' => $url,
                    'alt' => kfStyleCleanText($row['alt'] ?? ''),
                ];
            }
        }

        // Process Member Reviews array.
        $reviewsItems = [];
        if (!empty($_POST['reviews']) && is_array($_POST['reviews'])) {
            foreach ($_POST['reviews'] as $row) {
                if (!is_array($row)) continue;
                $text   = kfStyleCleanText($row['text']   ?? '');
                $author = kfStyleCleanText($row['author'] ?? '');
                if ($text === '' && $author === '') continue;
                $stars = (int) ($row['stars'] ?? 5);
                if ($stars < 1) $stars = 1;
                if ($stars > 5) $stars = 5;
                $reviewsItems[] = [
                    'stars'  => (string) $stars,
                    'text'   => $text,
                    'author' => $author,
                    'link'   => kfStyleCleanText($row['link'] ?? ''),
                ];
            }
        }

        // Process Social Buttons array.
        $socialButtons = [];
        if (!empty($_POST['social']) && is_array($_POST['social'])) {
            foreach ($_POST['social'] as $row) {
                if (!is_array($row)) continue;
                $label = kfStyleCleanText($row['label'] ?? '');
                $url   = kfStyleCleanText($row['url']   ?? '');
                if ($label === '' || $url === '') continue;
                $socialButtons[] = [
                    'label'  => $label,
                    'url'    => $url,
                    'icon'   => kfStyleCleanText($row['icon']  ?? ''),
                    'color'  => kfStyleHexOrEmpty($row['color'] ?? ''),
                    'target' => (($row['target'] ?? '') === '_blank') ? '_blank' : '',
                ];
            }
        }

        // Process Cart/Checkout Payment Gateways array.
        // Each row binds an admin-controlled display (title, subtext,
        // icon, optional preferred ribbon) to a WHMCS gateway sysname.
        // Order is preserved (DOM order from the form = render order on
        // checkout.tpl). Rows with no gateway selected are skipped.
        $paymentGateways = [];
        if (!empty($_POST['payment_gateways']) && is_array($_POST['payment_gateways'])) {
            foreach ($_POST['payment_gateways'] as $row) {
                if (!is_array($row)) continue;
                $sys = kfStyleCleanText($row['gateway'] ?? '');
                if ($sys === '') continue; // no gateway picked = skip
                $paymentGateways[] = [
                    'gateway'         => $sys,
                    'title'           => kfStyleCleanText($row['title']           ?? ''),
                    'subtext'         => kfStyleCleanText($row['subtext']         ?? ''),
                    'icon'            => kfStyleCleanText($row['icon']            ?? ''),
                    'preferred'       => !empty($row['preferred']) ? '1' : '0',
                    'preferred_label' => kfStyleCleanText($row['preferred_label'] ?? 'PREFERRED'),
                    // Per-row Border/Glow color. Saved only when admin enabled
                    // the override toggle, so empty string means "fall back to
                    // master accent" at render time.
                    'accent'          => !empty($row['accent_enabled']) ? kfStyleHexOrEmpty($row['accent'] ?? '') : '',
                    'visible'         => !empty($row['visible'])   ? '1' : '0',
                ];
            }
        }

        // Process Client Area Stat Tiles array.
        // Allowed stat sources are validated against a fixed whitelist so a
        // POST can't inject a Smarty variable name we don't expose.
        $statSourceAllowed = ['services','domains','invoices','tickets','affiliates','quotes','credit','dashes'];
        $statTiles = [];
        if (!empty($_POST['stat_tiles']) && is_array($_POST['stat_tiles'])) {
            foreach ($_POST['stat_tiles'] as $row) {
                if (!is_array($row)) continue;
                $title = kfStyleCleanText($row['title'] ?? '');
                if ($title === '') continue;
                $stat = kfStyleCleanText($row['stat'] ?? 'dashes');
                if (!in_array($stat, $statSourceAllowed, true)) $stat = 'dashes';
                $statTiles[] = [
                    'title'   => $title,
                    'subtext' => kfStyleCleanText($row['subtext'] ?? ''),
                    'icon'    => kfStyleCleanText($row['icon']  ?? ''),
                    'color'   => kfStyleHexOrEmpty($row['color'] ?? '') ?: '#1a6fff',
                    'stat'    => $stat,
                    'url'     => kfStyleCleanText($row['url']   ?? '#'),
                    'visible' => !empty($row['visible']) ? '1' : '0',
                ];
            }
        }

        // Process Client Area Custom Info Cards array.
        $infoCards = [];
        if (!empty($_POST['info_cards']) && is_array($_POST['info_cards'])) {
            foreach ($_POST['info_cards'] as $row) {
                if (!is_array($row)) continue;
                $title = kfStyleCleanText($row['title'] ?? '');
                if ($title === '') continue;
                $infoCards[] = [
                    'title'       => $title,
                    'icon'        => kfStyleCleanText($row['icon']         ?? ''),
                    'description' => kfStyleCleanText($row['description']  ?? ''),
                    'btn_text'    => kfStyleCleanText($row['btn_text']     ?? ''),
                    'btn_url'     => kfStyleCleanText($row['btn_url']      ?? ''),
                    'color'       => kfStyleHexOrEmpty($row['color'] ?? '') ?: '#1a6fff',
                    'visible'     => !empty($row['visible']) ? '1' : '0',
                    // Comma/space separated product IDs. Normalize on save:
                    // strip whitespace, drop non-numeric, dedupe, join with ',' so
                    // the hook can do a simple explode without re-parsing.
                    'product_ids' => kfStyleNormalizeProductIds($row['product_ids'] ?? ''),
                ];
            }
        }

        // Process homepage cards into a clean array first.
        $homepageCards = [];
        if (!empty($_POST['cards']) && is_array($_POST['cards'])) {
            foreach ($_POST['cards'] as $row) {
                if (!is_array($row)) continue;
                // Skip rows where every text field is empty AND not enabled.
                $card = [
                    'enabled'     => !empty($row['enabled']) ? '1' : '0',
                    'title'       => kfStyleCleanText($row['title']       ?? ''),
                    'subtitle'    => kfStyleCleanText($row['subtitle']    ?? ''),
                    'description' => kfStyleCleanText($row['description'] ?? ''),
                    'link'        => kfStyleCleanText($row['link']        ?? ''),
                    'bullet1'     => kfStyleCleanText($row['bullet1']     ?? ''),
                    'bullet2'     => kfStyleCleanText($row['bullet2']     ?? ''),
                    'bullet3'     => kfStyleCleanText($row['bullet3']     ?? ''),
                    'accent'      => kfStyleHexOrEmpty($row['accent'] ?? '') ?: '#5a5249',
                    'image'       => kfStyleCleanText($row['image']       ?? ''),
                ];
                // Drop completely empty rows so the admin can blank-and-save to delete.
                $hasContent = $card['title'] !== ''
                    || $card['subtitle'] !== ''
                    || $card['description'] !== ''
                    || $card['link'] !== ''
                    || $card['bullet1'] !== ''
                    || $card['bullet2'] !== ''
                    || $card['bullet3'] !== ''
                    || $card['image'] !== '';
                if (!$hasContent && $card['enabled'] === '0') continue;
                $homepageCards[] = $card;
            }
        }
        // Guarantee there's always at least one card. If admin deleted everything,
        // fall back to the default placeholder so the homepage is never blank.
        if (empty($homepageCards)) {
            $homepageCards = Settings::defaultCards();
        }

        $save = [
            // General
            'accent_color'           => kfStyleHexOrEmpty($_POST['accent_color'] ?? ''),
            'accent_glow_color'      => kfStyleHexOrEmpty($_POST['accent_glow_color'] ?? ''),

            // SEO / Social Sharing (Open Graph)
            'og_title'               => kfStyleCleanText($_POST['og_title']       ?? ''),
            'og_description'         => kfStyleCleanText($_POST['og_description'] ?? ''),
            'og_image'               => trim($_POST['og_image'] ?? ''),

            // Sitewide Announcement Bar
            'announcement_enabled'     => !empty($_POST['announcement_enabled'])     ? '1' : '0',
            'announcement_dismissable' => !empty($_POST['announcement_dismissable']) ? '1' : '0',
            'announcement_message'     => trim($_POST['announcement_message'] ?? ''),
            'announcement_bg'          => kfStyleHexOrEmpty($_POST['announcement_bg']   ?? ''),
            'announcement_text'        => kfStyleHexOrEmpty($_POST['announcement_text'] ?? ''),

            // Custom Code Injection — RAW. Trusted because admin-only.
            // We save the textareas verbatim so admins can paste <script>,
            // <link>, schema JSON-LD blocks, etc. without any escaping.
            'custom_head_html'       => (string) ($_POST['custom_head_html']   ?? ''),
            'custom_footer_html'     => (string) ($_POST['custom_footer_html'] ?? ''),

            // Header — logos
            'header_logo_show'       => !empty($_POST['header_logo_show']) ? '1' : '0',
            'header_logo'            => trim($_POST['header_logo'] ?? ''),
            'header_top_logo'        => trim($_POST['header_top_logo'] ?? ''),
            'favicon_url'            => trim($_POST['favicon_url'] ?? ''),

            // Header — second navbar
            'header_nav2_enabled'    => !empty($_POST['header_nav2_enabled']) ? '1' : '0',
            'nav2_visibility'        => ($_POST['nav2_visibility'] ?? '') === 'logged_in' ? 'logged_in' : 'always',
            'nav2_items'             => $nav2Items,

            // Header — background
            'header_bg_type'         => (function(){ $t = $_POST['header_bg_type'] ?? 'none'; return in_array($t, ['none','color','image','video'], true) ? $t : 'none'; })(),
            'header_bg_color'        => kfStyleHexOrEmpty($_POST['header_bg_color'] ?? ''),
            'header_bg_image'        => trim($_POST['header_bg_image'] ?? ''),
            'header_bg_video'        => trim($_POST['header_bg_video'] ?? ''),
            'header_bg_no_overlay'   => !empty($_POST['header_bg_no_overlay']) ? '1' : '0',
            'sidebar_hidden'         => !empty($_POST['sidebar_hidden']) ? '1' : '0',
            'header_bg_greyscale'    => !empty($_POST['header_bg_greyscale']) ? '1' : '0',

            // Footer
            'footer_logo_show'       => !empty($_POST['footer_logo_show']) ? '1' : '0',
            'footer_logo'            => trim($_POST['footer_logo'] ?? ''),
            'footer_description'     => trim($_POST['footer_description'] ?? ''),
            'footer_col1_title'      => trim($_POST['footer_col1_title'] ?? ''),
            'footer_col1_icon'       => trim($_POST['footer_col1_icon']  ?? ''),
            'footer_col1_items'      => kfStyleParseFooterItems($_POST['footer_col1_items'] ?? []),
            'footer_col2_title'      => trim($_POST['footer_col2_title'] ?? ''),
            'footer_col2_icon'       => trim($_POST['footer_col2_icon']  ?? ''),
            'footer_col2_items'      => kfStyleParseFooterItems($_POST['footer_col2_items'] ?? []),
            'footer_col3_title'      => trim($_POST['footer_col3_title'] ?? ''),
            'footer_col3_icon'       => trim($_POST['footer_col3_icon']  ?? ''),
            'footer_col3_items'      => kfStyleParseFooterItems($_POST['footer_col3_items'] ?? []),

            // Homepage
            'homepage_cards'         => $homepageCards,

            // Homepage — Hero
            'hero_eyebrow_enabled'      => !empty($_POST['hero_eyebrow_enabled']) ? '1' : '0',
            'hero_eyebrow_text'         => trim($_POST['hero_eyebrow_text'] ?? ''),
            'hero_motto_enabled'        => !empty($_POST['hero_motto_enabled']) ? '1' : '0',
            'hero_motto_main'           => trim($_POST['hero_motto_main'] ?? ''),
            'hero_motto_accent'         => trim($_POST['hero_motto_accent'] ?? ''),
            // Accent color rotation
            'hero_motto_accent_count'   => (function () {
                $n = (int) ($_POST['hero_motto_accent_count'] ?? 1);
                if ($n < 1) $n = 1;
                if ($n > 10) $n = 10;
                return (string) $n;
            })(),
            'hero_motto_accent_colors'  => (function () {
                // Build a sanitized array of up to 10 hex colors. Invalid
                // entries are dropped; if everything is invalid we fall
                // back to a single default so the rotation always has
                // something to pick from.
                $raw = $_POST['hero_motto_accent_colors'] ?? [];
                if (!is_array($raw)) return ['#f87171'];
                $clean = [];
                foreach ($raw as $hex) {
                    $hex = trim((string) $hex);
                    if (preg_match('/^#[0-9A-Fa-f]{6}$/', $hex) || preg_match('/^#[0-9A-Fa-f]{3}$/', $hex)) {
                        $clean[] = $hex;
                    }
                    if (count($clean) >= 10) break;
                }
                if (empty($clean)) $clean = ['#f87171'];
                return $clean;
            })(),
            // Legacy single-color key — kept in sync with first color in
            // the array so any code still reading the old key gets a
            // sensible value.
            'hero_motto_accent_color'   => (function () {
                $raw = $_POST['hero_motto_accent_colors'] ?? [];
                if (is_array($raw) && !empty($raw[0])) {
                    $first = trim((string) $raw[0]);
                    if (preg_match('/^#[0-9A-Fa-f]{6}$/', $first) || preg_match('/^#[0-9A-Fa-f]{3}$/', $first)) {
                        return $first;
                    }
                }
                return '#f87171';
            })(),
            'hero_description_enabled'  => !empty($_POST['hero_description_enabled']) ? '1' : '0',
            'hero_description_text'     => trim($_POST['hero_description_text'] ?? ''),
            'hero_stats_enabled'        => !empty($_POST['hero_stats_enabled']) ? '1' : '0',
            'hero_stats'                => $heroStats,
            'hero_social_enabled'       => !empty($_POST['hero_social_enabled']) ? '1' : '0',
            'hero_social'               => $heroSocial,
            'hero_marquee_enabled'      => !empty($_POST['hero_marquee_enabled']) ? '1' : '0',
            'hero_marquee_greyscale'    => !empty($_POST['hero_marquee_greyscale']) ? '1' : '0',
            'hero_marquee_speed'        => kfStyleMarqueeSpeed($_POST['hero_marquee_speed'] ?? '1'),
            'hero_marquee'              => $heroMarquee,

            // Cart / Checkout — Marquee (cart.php viewcart + checkout pages)
            'checkout_marquee_enabled'   => !empty($_POST['checkout_marquee_enabled']) ? '1' : '0',
            'checkout_marquee_greyscale' => !empty($_POST['checkout_marquee_greyscale']) ? '1' : '0',
            'checkout_marquee_speed'     => kfStyleMarqueeSpeed($_POST['checkout_marquee_speed'] ?? '1'),
            'checkout_marquee'           => $checkoutMarquee,

            // Cart / Checkout — Three fixed-position editable notice boxes.
            // CP   = configure-product page (the per-product config step)
            // COT  = checkout page, top (in place of the old hardcoded
            //        "Amazon is now a payment option" gold box, between
            //        credit-balance options and the payment gateway list)
            // COB  = checkout page, bottom (right above Terms of Service)
            // Each fully independent: enable/disable, optional centered
            // title (icons flank when set), body HTML, severity color,
            // optional Font Awesome icon class.
            'cart_notice_cp_enabled'      => !empty($_POST['cart_notice_cp_enabled']) ? '1' : '0',
            'cart_notice_cp_severity'     => kfStyleNoticeSeverity($_POST['cart_notice_cp_severity'] ?? 'warning'),
            'cart_notice_cp_icon'         => kfStyleCleanText($_POST['cart_notice_cp_icon'] ?? ''),
            'cart_notice_cp_title'        => kfStyleCleanText($_POST['cart_notice_cp_title'] ?? ''),
            'cart_notice_cp_html'         => kfStyleCleanText($_POST['cart_notice_cp_html'] ?? ''),
            'cart_notice_co_top_enabled'  => !empty($_POST['cart_notice_co_top_enabled']) ? '1' : '0',
            'cart_notice_co_top_severity' => kfStyleNoticeSeverity($_POST['cart_notice_co_top_severity'] ?? 'info'),
            'cart_notice_co_top_icon'     => kfStyleCleanText($_POST['cart_notice_co_top_icon'] ?? ''),
            'cart_notice_co_top_title'    => kfStyleCleanText($_POST['cart_notice_co_top_title'] ?? ''),
            'cart_notice_co_top_html'     => kfStyleCleanText($_POST['cart_notice_co_top_html'] ?? ''),
            'cart_notice_co_bot_enabled'  => !empty($_POST['cart_notice_co_bot_enabled']) ? '1' : '0',
            'cart_notice_co_bot_severity' => kfStyleNoticeSeverity($_POST['cart_notice_co_bot_severity'] ?? 'warning'),
            'cart_notice_co_bot_icon'     => kfStyleCleanText($_POST['cart_notice_co_bot_icon'] ?? ''),
            'cart_notice_co_bot_title'    => kfStyleCleanText($_POST['cart_notice_co_bot_title'] ?? ''),
            'cart_notice_co_bot_html'     => kfStyleCleanText($_POST['cart_notice_co_bot_html'] ?? ''),
            'payment_gateways'            => $paymentGateways,
            // Section-level color overrides for payment gateway cards.
            // Toggles control whether the picked color is used at all —
            // unchecked → save empty string so the template falls back to
            // the built-in default (gold ribbon / gold preferred glow).
            // Note: the non-preferred selected color is configured PER-ROW
            // (see $paymentGateways above), not at section level.
            'payment_ribbon_color'        => !empty($_POST['payment_ribbon_color_enabled'])    ? kfStyleHexOrEmpty($_POST['payment_ribbon_color']    ?? '') : '',
            'payment_preferred_color'     => !empty($_POST['payment_preferred_color_enabled']) ? kfStyleHexOrEmpty($_POST['payment_preferred_color'] ?? '') : '',

            // Homepage — Latest & Member Reviews block
            'reviews_enabled'              => !empty($_POST['reviews_enabled']) ? '1' : '0',
            'reviews_announcement_enabled' => !empty($_POST['reviews_announcement_enabled']) ? '1' : '0',
            'reviews_title'                => trim($_POST['reviews_title'] ?? ''),
            'reviews_subtitle'             => trim($_POST['reviews_subtitle'] ?? ''),
            'reviews_marquee_speed'        => kfStyleMarqueeSpeed($_POST['reviews_marquee_speed'] ?? '1'),
            'reviews_items'                => $reviewsItems,
            'social_buttons_enabled'       => !empty($_POST['social_buttons_enabled']) ? '1' : '0',
            'social_buttons'               => $socialButtons,

            // Client Area — stat tiles + custom info cards + panel accents
            'stat_tiles_enabled'       => !empty($_POST['stat_tiles_enabled']) ? '1' : '0',
            'stat_tiles'               => $statTiles,
            'info_cards_enabled'       => !empty($_POST['info_cards_enabled']) ? '1' : '0',
            'info_cards'               => $infoCards,
            'panel_active_products'    => kfStyleHexOrEmpty($_POST['panel_active_products'] ?? ''),
            'panel_recent_tickets'     => kfStyleHexOrEmpty($_POST['panel_recent_tickets']  ?? ''),
            'panel_recent_news'        => kfStyleHexOrEmpty($_POST['panel_recent_news']     ?? ''),
            'panel_affiliate'          => kfStyleHexOrEmpty($_POST['panel_affiliate']       ?? ''),
            'panel_recent_news_hidden'     => !empty($_POST['panel_recent_news_hidden']) ? '1' : '0',
            'panel_affiliate_hidden'       => !empty($_POST['panel_affiliate_hidden']) ? '1' : '0',
            'panel_recent_tickets_hidden'  => !empty($_POST['panel_recent_tickets_hidden']) ? '1' : '0',

            // Primary Navbar (Row 1) per-item config
            'nav1_items'             => $nav1Items,
            'nav1_strict_mode'       => !empty($_POST['nav1_strict_mode']) ? '1' : '0',
            'nav1_cart_color'        => kfStyleHexOrEmpty($_POST['nav1_cart_color']        ?? ''),
            'nav1_cart_badge_color'  => kfStyleHexOrEmpty($_POST['nav1_cart_badge_color']  ?? ''),
            'nav1_cart_glow_color'   => kfStyleHexOrEmpty($_POST['nav1_cart_glow_color']   ?? ''),
            'nav1_user_glow_color'   => kfStyleHexOrEmpty($_POST['nav1_user_glow_color']  ?? ''),
            // Notification pill (logged-in only). Toggle default is ON;
            // a missing checkbox in POST means OFF.
            'nav1_notif_enabled'     => !empty($_POST['nav1_notif_enabled']) ? '1' : '0',
            'nav1_notif_color'       => kfStyleHexOrEmpty($_POST['nav1_notif_color']       ?? ''),
            'nav1_notif_badge_color' => kfStyleHexOrEmpty($_POST['nav1_notif_badge_color'] ?? ''),
            'nav1_notif_glow_color'  => kfStyleHexOrEmpty($_POST['nav1_notif_glow_color']  ?? ''),
        ];
        Settings::setMany($save);
        $message = 'Settings saved.';
    }

    // ─── Load current values ─────────────────────────────
    $s = Settings::all();
    $v = function ($k, $default = '') use ($s) {
        if (!isset($s[$k])) return $default;
        $val = $s[$k];
        if (is_array($val)) return ''; // arrays handled separately
        return (string) $val;
    };

    // Active tab — persists across POST so Save stays on the current tab
    $tabSource = '';
    if (isset($_POST['kf_active_tab'])) {
        $tabSource = $_POST['kf_active_tab'];
    } elseif (isset($_GET['tab'])) {
        $tabSource = $_GET['tab'];
    }
    $activeTab = in_array($tabSource, ['general','header','homepage','footer','cart','clientarea','help'], true)
        ? $tabSource
        : 'general';

    ob_start();
    ?>
    <style>
    /* Scoped admin UI styles — only render inside the addon page */
    .kf-admin-wrap{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;color:#222;}
    .kf-admin-wrap .kf-tabs{display:flex;flex-wrap:wrap;gap:4px;border-bottom:2px solid #d8d3cc;margin:0 0 18px;padding:0;list-style:none;}
    .kf-admin-wrap .kf-tab{padding:10px 18px;background:#f7f5f0;border:1px solid #d8d3cc;border-bottom:none;border-radius:8px 8px 0 0;text-decoration:none;color:#5a5249;font-weight:600;font-size:14px;cursor:pointer;display:inline-block;}
    .kf-admin-wrap .kf-tab:hover{background:#fff;color:#13110e;text-decoration:none;}
    .kf-admin-wrap .kf-tab.active{background:#fff;color:#13110e;border-color:#bfb8ae;border-bottom:2px solid #fff;margin-bottom:-2px;position:relative;z-index:2;}
    .kf-admin-wrap .kf-pane{display:none;background:#fff;border:1px solid #d8d3cc;border-radius:0 8px 8px 8px;padding:24px;}
    .kf-admin-wrap .kf-pane.active{display:block;}
    .kf-admin-wrap .kf-section-title{font-size:18px;font-weight:700;margin:0 0 4px;color:#13110e;}

    /* ── Collapsible section boxes ─────────────────── */
    .kf-admin-wrap .kf-section{
        background:#fff;
        border:1px solid #d8d3cc;
        border-radius:10px;
        margin-bottom:14px;
        box-shadow:0 1px 3px rgba(19,17,14,.04);
        overflow:hidden;
        transition:box-shadow .15s ease;
    }
    .kf-admin-wrap .kf-section[open]{
        box-shadow:0 2px 10px rgba(19,17,14,.06);
    }
    .kf-admin-wrap .kf-section-head{
        display:flex;
        align-items:center;
        gap:12px;
        padding:14px 18px;
        cursor:pointer;
        list-style:none;
        user-select:none;
        background:#fafaf7;
        border-bottom:1px solid transparent;
        transition:background .12s ease;
    }
    .kf-admin-wrap .kf-section-head:hover{background:#f5f3ee;}
    .kf-admin-wrap .kf-section[open] .kf-section-head{
        background:#f7f5f0;
        border-bottom-color:#d8d3cc;
    }
    .kf-admin-wrap .kf-section-head::-webkit-details-marker{display:none;}
    .kf-admin-wrap .kf-section-head::marker{display:none;}
    .kf-admin-wrap .kf-section-chev{
        color:#7a7268;
        font-size:14px;
        line-height:1;
        transition:transform .15s ease;
        flex:0 0 auto;
        width:14px;
    }
    .kf-admin-wrap .kf-section[open] .kf-section-chev{transform:rotate(0deg);}
    .kf-admin-wrap .kf-section:not([open]) .kf-section-chev{transform:rotate(-90deg);}
    .kf-admin-wrap .kf-section-head h3{
        margin:0;
        font-size:16px;
        font-weight:700;
        color:#13110e;
        flex:1;
        line-height:1.2;
    }
    .kf-admin-wrap .kf-section-body{
        padding:18px 20px 6px;
        background:#fff;
    }
    .kf-admin-wrap .kf-section-desc{
        font-size:12.5px;
        color:#5a5249;
        margin:0 0 14px;
        line-height:1.55;
    }
    .kf-admin-wrap .kf-section-foot{
        margin:14px -20px 0;
        padding:14px 20px;
        background:#fafaf7;
        border-top:1px solid #ede9e2;
        display:flex;
        justify-content:flex-end;
    }
    .kf-admin-wrap .kf-section-foot .kf-btn-primary{
        font-size:12.5px;
        padding:7px 18px;
    }
    .kf-admin-wrap .kf-section-sub{font-size:13px;color:#7a7268;margin:0 0 18px;}
    .kf-admin-wrap .kf-row{display:flex;flex-wrap:wrap;gap:18px;margin-bottom:14px;}
    .kf-admin-wrap .kf-field{flex:1 1 320px;min-width:0;}
    .kf-admin-wrap .kf-field label{display:block;font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#5a5249;margin-bottom:6px;}
    .kf-admin-wrap .kf-field input[type=text],
    .kf-admin-wrap .kf-field input[type=url],
    .kf-admin-wrap .kf-field input[type=color],
    .kf-admin-wrap .kf-field textarea,
    .kf-admin-wrap .kf-field select{width:100%;padding:9px 12px;border:1.5px solid #d8d3cc;border-radius:6px;font-size:13px;font-family:inherit;background:#fff;color:#13110e;box-sizing:border-box;}
    .kf-admin-wrap .kf-field input[type=color]{height:42px;padding:4px;cursor:pointer;}
    /* ─── Color picker + hex text combo (JS auto-wraps every color input) ─── */
    .kf-admin-wrap .kf-color-combo{display:flex;gap:8px;align-items:stretch;}
    .kf-admin-wrap .kf-color-combo input[type=color]{flex:0 0 64px;width:64px;}
    .kf-admin-wrap .kf-color-hex{flex:1;min-width:0;padding:9px 12px;border:1.5px solid #d8d3cc;border-radius:6px;font-size:13px;font-family:'SF Mono',Menlo,Consolas,monospace;letter-spacing:.5px;background:#fff;color:#13110e;text-transform:uppercase;box-sizing:border-box;}
    .kf-admin-wrap .kf-color-hex:focus{border-color:#22a04a;outline:none;box-shadow:0 0 0 3px rgba(34,160,74,.12);}
    .kf-admin-wrap .kf-color-hex.kf-color-hex-invalid{border-color:#cc2828;background:#fef2f2;color:#cc2828;}
    .kf-admin-wrap .kf-color-hex.kf-color-hex-invalid:focus{box-shadow:0 0 0 3px rgba(204,40,40,.12);}
    .kf-admin-wrap .kf-field textarea{font-family:'SF Mono',Menlo,Consolas,monospace;font-size:12px;line-height:1.6;min-height:140px;resize:vertical;}
    .kf-admin-wrap .kf-field input:focus,
    .kf-admin-wrap .kf-field textarea:focus,
    .kf-admin-wrap .kf-field select:focus{border-color:#22a04a;outline:none;box-shadow:0 0 0 3px rgba(34,160,74,.12);}
    .kf-admin-wrap .kf-help{font-size:12px;color:#7a7268;margin:6px 0 0;line-height:1.5;}
    .kf-admin-wrap .kf-help code{background:#f7f5f0;padding:2px 5px;border-radius:3px;font-size:11px;color:#5a5249;}
    .kf-admin-wrap .kf-toggle{display:inline-flex;align-items:center;gap:8px;cursor:pointer;font-weight:600;color:#13110e;}
    .kf-admin-wrap .kf-toggle input{margin:0;width:16px;height:16px;}
    .kf-admin-wrap .kf-divider{height:1px;background:#ede9e2;margin:24px 0;border:none;}
    .kf-admin-wrap .kf-radios{display:flex;flex-wrap:wrap;gap:14px;margin-top:6px;}
    .kf-admin-wrap .kf-radios label{display:inline-flex;align-items:center;gap:6px;font-weight:600;color:#13110e;cursor:pointer;font-size:13px;text-transform:none;letter-spacing:0;margin:0;}
    .kf-admin-wrap .kf-radios input{margin:0;}
    .kf-admin-wrap .kf-actions{display:flex;justify-content:flex-end;gap:10px;padding:16px 0 0;border-top:1px solid #ede9e2;margin-top:24px;}
    .kf-admin-wrap .kf-btn{padding:10px 22px;border-radius:6px;font-weight:700;font-size:13px;border:none;cursor:pointer;text-decoration:none;display:inline-block;}
    .kf-admin-wrap .kf-btn-primary{background:#22a04a;color:#fff;}
    .kf-admin-wrap .kf-btn-primary:hover{background:#167a36;color:#fff;text-decoration:none;}
    .kf-admin-wrap .kf-banner{padding:12px 18px;border-radius:8px;background:rgba(34,160,74,.08);border:1px solid rgba(34,160,74,.30);color:#167a36;font-weight:600;margin-bottom:18px;}
    .kf-admin-wrap .kf-info-box{padding:14px 18px;border-radius:8px;background:#f7f5f0;border:1px solid #d8d3cc;margin-bottom:18px;font-size:13px;color:#5a5249;}
    .kf-admin-wrap .kf-info-box strong{color:#13110e;}
    .kf-admin-wrap .kf-format{background:#13110e;color:#a4e8b9;padding:10px 14px;border-radius:6px;font-family:'SF Mono',Menlo,Consolas,monospace;font-size:11px;line-height:1.6;margin:6px 0;display:block;white-space:pre;overflow-x:auto;}

    /* ── Homepage card repeater ──────────────────────── */
    .kf-admin-wrap .kf-card-row{
        background:#fff;
        border:1px solid #d8d3cc;
        border-radius:8px;
        margin-bottom:10px;
        overflow:hidden;
    }
    .kf-admin-wrap .kf-card-row[open]{border-color:#bfb8ae;box-shadow:0 2px 8px rgba(19,17,14,.06);}
    .kf-admin-wrap .kf-card-row-header{
        display:flex;
        align-items:center;
        gap:12px;
        padding:10px 14px;
        background:#f7f5f0;
        border-bottom:1px solid transparent;
        cursor:pointer;
        list-style:none;
        user-select:none;
    }
    .kf-admin-wrap .kf-card-row-header::-webkit-details-marker{display:none;}
    .kf-admin-wrap .kf-card-row-header::marker{display:none;}
    .kf-admin-wrap .kf-card-row[open] .kf-card-row-header{border-bottom-color:#d8d3cc;}
    .kf-admin-wrap .kf-card-row-header::after{
        content:'▾';
        margin-left:auto;
        color:#7a7268;
        font-size:12px;
        transition:transform .15s ease;
    }
    .kf-admin-wrap .kf-card-row[open] .kf-card-row-header::after{transform:rotate(180deg);}
    .kf-admin-wrap .kf-card-row-grip{
        color:#bfb8ae;
        font-size:14px;
        letter-spacing:-2px;
        cursor:grab;
        padding:0 4px;
        user-select:none;
    }
    .kf-admin-wrap .kf-card-row-grip:hover{color:#7a7268;}
    /* Row being dragged — faded to make it obvious which one is moving */
    .kf-admin-wrap .kf-card-row.kf-dragging{opacity:.4;}
    /* Drop indicator — a green line above or below the row the cursor
       is hovering, showing where the dragged row will land on release.
       box-shadow is used (not border) so the indicator doesn't shift
       layout. Transition keeps the line crisp when moving between rows. */
    .kf-admin-wrap .kf-card-row{transition:box-shadow .08s ease;}
    .kf-admin-wrap .kf-card-row.kf-drop-before{
        box-shadow:0 -3px 0 0 #22a04a, 0 0 0 1px rgba(34,160,74,.18);
    }
    .kf-admin-wrap .kf-card-row.kf-drop-after{
        box-shadow:0 3px 0 0 #22a04a, 0 0 0 1px rgba(34,160,74,.18);
    }
    .kf-admin-wrap .kf-card-row-toggle{display:inline-flex;align-items:center;}
    .kf-admin-wrap .kf-card-row-toggle input{margin:0;width:16px;height:16px;}
    .kf-admin-wrap .kf-card-row-title{
        flex:1;
        font-weight:700;
        font-size:14px;
        color:#13110e;
        overflow:hidden;
        text-overflow:ellipsis;
        white-space:nowrap;
    }
    .kf-admin-wrap .kf-card-row-actions{display:inline-flex;gap:4px;}
    .kf-admin-wrap .kf-card-mini-btn{
        background:#fff;
        border:1px solid #d8d3cc;
        border-radius:5px;
        padding:4px 9px;
        font-size:13px;
        font-weight:700;
        color:#5a5249;
        cursor:pointer;
        line-height:1;
        transition:.12s ease;
    }
    .kf-admin-wrap .kf-card-mini-btn:hover{background:#f7f5f0;border-color:#bfb8ae;color:#13110e;}
    .kf-admin-wrap .kf-card-mini-btn-delete:hover{background:#fdecec;border-color:#cc2828;color:#cc2828;}
    .kf-admin-wrap .kf-card-row-body{padding:18px 16px 14px;background:#fff;}
    .kf-admin-wrap .kf-btn-add{
        background:#fff;
        border:1.5px dashed #bfb8ae;
        color:#5a5249;
        font-weight:700;
        cursor:pointer;
        font-size:13px;
        padding:12px 22px;
        border-radius:8px;
        transition:.15s ease;
    }
    .kf-admin-wrap .kf-btn-add:hover{
        border-color:#22a04a;
        color:#22a04a;
        border-style:solid;
        background:rgba(34,160,74,.04);
    }
    </style>

    <div class="kf-admin-wrap">

        <?php if ($message) : ?>
            <div class="kf-banner">✓ <?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <div class="kf-info-box">
            <strong>How this works.</strong> Settings here drive the
            <code>kwickflix</code> template via a runtime hook — nothing is written
            to disk and <strong>no custom.css is created</strong>. Make sure the
            template is set to <code>kwickflix</code> in
            <em>Setup → General Settings → General → Template</em>. To preview
            without switching the active template, visit
            <code>/index.php?systpl=kwickflix</code> (this exact URL — the
            <code>?systpl=</code> parameter only works on <code>/index.php</code>).
        </div>

        <ul class="kf-tabs">
            <li><a class="kf-tab" data-tab="general">General</a></li>
            <li><a class="kf-tab" data-tab="header">Header</a></li>
            <li><a class="kf-tab" data-tab="homepage">Homepage</a></li>
            <li><a class="kf-tab" data-tab="footer">Footer</a></li>
            <li><a class="kf-tab" data-tab="cart">Cart/Checkout</a></li>
            <li><a class="kf-tab" data-tab="clientarea">Client Area</a></li>
            <li><a class="kf-tab" data-tab="help">Help</a></li>
        </ul>

        <form method="post" action="<?php echo htmlspecialchars($modulelink); ?>">
            <input type="hidden" name="kf_save" value="1">
            <input type="hidden" name="kf_active_tab" id="kf_active_tab" value="<?php echo htmlspecialchars($activeTab, ENT_QUOTES); ?>">

            <!-- ════════════ GENERAL ════════════ -->
            <div class="kf-pane" data-pane="general">
                <?php kfSectionOpen('general_accent', 'Master Accent Color', 'The accent color used across cards, buttons, badges, links, and the default hover-glow on navbar pills. Default is green (#22a04a).'); ?>
                    <div class="kf-row">
                        <div class="kf-field" style="flex:0 0 240px;">
                            <label for="accent_color">Accent Color</label>
                            <input type="color" id="accent_color" name="accent_color" value="<?php echo htmlspecialchars($v('accent_color', '#22a04a') ?: '#22a04a'); ?>">
                            <p class="kf-help">Buttons, links, focus rings, badges, card accents.</p>
                        </div>
                        <div class="kf-field" style="flex:0 0 240px;">
                            <label for="accent_glow_color">Master Glow Color</label>
                            <input type="color" id="accent_glow_color" name="accent_glow_color" value="<?php echo htmlspecialchars($v('accent_glow_color', '#22a04a') ?: '#22a04a'); ?>">
                            <p class="kf-help">Default hover-glow halo around navbar pills. Per-item glow colors in Primary/Secondary Navbar still override this for individual items.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_bg', 'Whole-Site Background', 'Sets a background for the entire site. Defaults to "blank" (uses the theme cream surface).'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label>Background Type</label>
                            <div class="kf-radios">
                                <?php $bg = $v('header_bg_type', 'none') ?: 'none'; ?>
                                <label><input type="radio" name="header_bg_type" value="none" <?php echo $bg === 'none' ? 'checked' : ''; ?>> Blank (default)</label>
                                <label><input type="radio" name="header_bg_type" value="color" <?php echo $bg === 'color' ? 'checked' : ''; ?>> Color</label>
                                <label><input type="radio" name="header_bg_type" value="image" <?php echo $bg === 'image' ? 'checked' : ''; ?>> Image</label>
                                <label><input type="radio" name="header_bg_type" value="video" <?php echo $bg === 'video' ? 'checked' : ''; ?>> Video</label>
                            </div>
                        </div>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="header_bg_color">Background Color (when type = Color)</label>
                            <input type="color" id="header_bg_color" name="header_bg_color" value="<?php echo htmlspecialchars($v('header_bg_color', '#fefdfb') ?: '#fefdfb'); ?>">
                        </div>
                        <div class="kf-field">
                            <label for="header_bg_image">Background Image URL (when type = Image)</label>
                            <input type="text" id="header_bg_image" name="header_bg_image" value="<?php echo htmlspecialchars($v('header_bg_image')); ?>" placeholder="/templates/kwickflix/img/staticbg/my-background.jpg">
                            <p class="kf-help">Upload images to <code>/templates/kwickflix/img/staticbg/</code> and reference them as <code>/templates/kwickflix/img/staticbg/filename.jpg</code>, or paste a full external URL.</p>
                        </div>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="header_bg_video">Background Video URL (when type = Video)</label>
                            <input type="text" id="header_bg_video" name="header_bg_video" value="<?php echo htmlspecialchars($v('header_bg_video')); ?>" placeholder="/templates/kwickflix/img/videobg/my-background.mp4">
                            <p class="kf-help">MP4 only. Auto-plays muted, looped. Upload to <code>/templates/kwickflix/img/videobg/</code> and reference as <code>/templates/kwickflix/img/videobg/filename.mp4</code> for best performance, or paste a full external URL.</p>
                        </div>
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="header_bg_greyscale" value="1" <?php echo $v('header_bg_greyscale') === '1' ? 'checked' : ''; ?>>
                                Make background greyscale
                            </label>
                            <p class="kf-help">Desaturates the image or video so colored content doesn't fight with the foreground. Has no effect on solid color or blank backgrounds.</p>

                            <label class="kf-toggle" style="margin-top:14px;">
                                <input type="checkbox" name="header_bg_no_overlay" value="1" <?php echo $v('header_bg_no_overlay') === '1' ? 'checked' : ''; ?>>
                                Hide light overlay (image/video only)
                            </label>
                            <p class="kf-help">By default, a soft cream overlay sits on top of image/video to keep content readable. Toggle off if you want raw media.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_layout', 'Layout', 'Coarse layout toggles that affect every client area page.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $sidebarHidden = ($s['sidebar_hidden'] ?? '0') === '1'; ?>
                                <input type="checkbox" name="sidebar_hidden" value="1" <?php echo $sidebarHidden ? 'checked' : ''; ?>>
                                Hide left sidebar across all client area pages
                            </label>
                            <p class="kf-help">When ON, the left-hand navigation sidebar (primary + secondary) is hidden via CSS and the main content area expands to full width. Useful if you prefer relying entirely on the top navbar. Affects every client area page, not just the home.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_social', 'SEO / Social Sharing', 'Open Graph meta tags. When someone shares a link to your site on Twitter/X, Discord, Slack, Facebook, etc., these values control what shows in the preview. Leave any field blank to fall back to the page\'s own title or your WHMCS company name.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="og_title">OG Title <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— shown as the headline of the preview card</span></label>
                            <input type="text" id="og_title" name="og_title" value="<?php echo htmlspecialchars($v('og_title')); ?>" placeholder="Premium Streaming Services — KwickFlix">
                            <p class="kf-help">~60 characters max before social platforms truncate. Falls back to the active page's <code>&lt;title&gt;</code> when empty.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="og_description">OG Description <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— short summary under the title</span></label>
                            <textarea id="og_description" name="og_description" rows="2" placeholder="IPTV, Jellyfin, Plex, Audiobookshelf — all in one place. Premium streaming, built for people who care about quality."><?php echo htmlspecialchars($v('og_description')); ?></textarea>
                            <p class="kf-help">~155 characters max. Falls back to your WHMCS site description when empty.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="og_image">OG Image URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— big preview image</span></label>
                            <input type="text" id="og_image" name="og_image" value="<?php echo htmlspecialchars($v('og_image')); ?>" placeholder="/templates/kwickflix/img/og-image.jpg">
                            <p class="kf-help">1200×630 JPG or PNG works best on every platform. Upload to <code>/templates/kwickflix/img/</code> and reference as <code>/templates/kwickflix/img/og-image.jpg</code>, or paste any full external URL. When empty, no <code>og:image</code> tag is emitted (platform shows a generic preview).</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_announcement', 'Sitewide Announcement Bar', 'A thin promo strip rendered at the very top of every page (above the navbar). Perfect for "10% off this month" notices, maintenance windows, or new-product launches. Toggle off when not in use.'); ?>
                    <?php
                    $annEnabled = ($s['announcement_enabled'] ?? '0') === '1';
                    $annDismiss = ($s['announcement_dismissable'] ?? '1') === '1';
                    ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="announcement_enabled" value="1" <?php echo $annEnabled ? 'checked' : ''; ?>>
                                Show announcement bar
                            </label>
                            <p class="kf-help">When ON, the bar renders at the top of every page. When OFF, no bar HTML is emitted at all.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="announcement_message">Message <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— HTML allowed</span></label>
                            <textarea id="announcement_message" name="announcement_message" rows="2" placeholder="🎉 Holiday Sale — 25% off all plans with code XMAS25 — <a href='/cart.php'>Order now</a>"><?php echo htmlspecialchars($v('announcement_message')); ?></textarea>
                            <p class="kf-help">Inline HTML works: <code>&lt;a&gt;</code>, <code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>, emojis. Keep it to one short line — the bar is thin.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field" style="flex:0 0 220px;">
                            <label for="announcement_bg">Background Color</label>
                            <input type="color" id="announcement_bg" name="announcement_bg" value="<?php echo htmlspecialchars($v('announcement_bg', '#22a04a') ?: '#22a04a'); ?>">
                        </div>
                        <div class="kf-field" style="flex:0 0 220px;">
                            <label for="announcement_text">Text Color</label>
                            <input type="color" id="announcement_text" name="announcement_text" value="<?php echo htmlspecialchars($v('announcement_text', '#ffffff') ?: '#ffffff'); ?>">
                        </div>
                        <div class="kf-field" style="flex:1 1 auto;">
                            <label class="kf-toggle">
                                <input type="checkbox" name="announcement_dismissable" value="1" <?php echo $annDismiss ? 'checked' : ''; ?>>
                                Allow visitors to dismiss the bar
                            </label>
                            <p class="kf-help">When ON, an × button appears on the right. Dismissal is remembered in the visitor's browser (localStorage). Toggle the bar off and back on in the admin to "reset" — visitors who dismissed it will see it again with a fresh message.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_custom_code', 'Custom Code Injection', 'For Google Analytics, GTM, Meta pixel, chat widgets (Crisp/Intercom/Tawk), schema markup, and any other third-party snippets. The HEAD block lands inside <code>&lt;head&gt;</code>; the FOOTER block lands just before <code>&lt;/body&gt;</code>. <strong>Both render exactly as-is, with no escaping</strong> — you can paste raw <code>&lt;script&gt;</code>, <code>&lt;link&gt;</code>, <code>&lt;noscript&gt;</code>, etc.'); ?>
                    <div class="kf-info-box" style="background:rgba(217,119,6,.06);border-color:rgba(217,119,6,.20);">
                        <strong>Heads up:</strong> what you paste here runs on every page for every visitor. Bad HTML or broken JS will affect your whole site. Test on a staging environment first if you're not sure.
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="custom_head_html">Custom HEAD HTML <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— rendered before &lt;/head&gt;</span></label>
                            <textarea id="custom_head_html" name="custom_head_html" rows="8" spellcheck="false" placeholder="<!-- Google Analytics, GTM, Meta pixel, etc -->
&lt;script async src='https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX'&gt;&lt;/script&gt;
&lt;script&gt;
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
&lt;/script&gt;" style="font-family:'JetBrains Mono','Fira Code',Consolas,monospace;font-size:12px;"><?php echo htmlspecialchars($v('custom_head_html')); ?></textarea>
                            <p class="kf-help">Best for: analytics tags (GA4, GTM, Plausible, Fathom), pre-load hints, <code>&lt;meta&gt;</code> tags, structured-data <code>&lt;script type="application/ld+json"&gt;</code> blocks.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="custom_footer_html">Custom FOOTER HTML <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— rendered before &lt;/body&gt;</span></label>
                            <textarea id="custom_footer_html" name="custom_footer_html" rows="8" spellcheck="false" placeholder="<!-- Crisp chat widget -->
&lt;script type='text/javascript'&gt;
  window.$crisp=[];window.CRISP_WEBSITE_ID='YOUR-WEBSITE-ID';
  (function(){d=document;s=d.createElement('script');
  s.src='https://client.crisp.chat/l.js';s.async=1;
  d.getElementsByTagName('head')[0].appendChild(s);})();
&lt;/script&gt;" style="font-family:'JetBrains Mono','Fira Code',Consolas,monospace;font-size:12px;"><?php echo htmlspecialchars($v('custom_footer_html')); ?></textarea>
                            <p class="kf-help">Best for: chat widgets, deferred analytics, social-proof popups, anything that should load late and not block first paint.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('general_export', 'Settings Export / Import', 'Backup, restore, or migrate the entire addon configuration as a single JSON blob. Use this when copying staging → production, or before making big changes.'); ?>
                    <?php
                    // Build the JSON snapshot of every saved setting. Complex
                    // values (arrays) are already JSON-encoded in the table by
                    // Settings::save(), but Settings::all() decodes them back
                    // to arrays — so this is a clean, re-importable structure.
                    $allSettings = $s; // already decoded by Settings::all()
                    $exportJson  = json_encode($allSettings, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
                    if ($exportJson === false) { $exportJson = '{}'; }
                    ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label>Export current settings</label>
                            <textarea id="kf-export-json" readonly rows="6" spellcheck="false" style="font-family:'JetBrains Mono','Fira Code',Consolas,monospace;font-size:12px;background:#f7f5f0;"><?php echo htmlspecialchars($exportJson); ?></textarea>
                            <div style="display:flex;gap:10px;margin-top:8px;">
                                <button type="button" class="kf-btn" id="kf-export-copy">📋 Copy to clipboard</button>
                                <button type="button" class="kf-btn" id="kf-export-download">⬇ Download as JSON</button>
                            </div>
                            <p class="kf-help">A snapshot of every saved setting (logos, nav rows, marquees, notices, payment gateways, etc.). Stash this somewhere safe before making big config changes.</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="kf-import-json">Import settings <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— paste a previously-exported JSON blob</span></label>
                            <textarea id="kf-import-json" name="import_json" rows="6" spellcheck="false" style="font-family:'JetBrains Mono','Fira Code',Consolas,monospace;font-size:12px;" placeholder='Paste an exported JSON blob here, then click "Replace all settings with this JSON" below.'></textarea>
                            <div style="display:flex;gap:10px;margin-top:8px;">
                                <button type="submit" name="kf_import_action" value="import" class="kf-btn kf-btn-danger" onclick="return confirm('This will REPLACE every saved setting with what\\'s in the textarea above. Your current configuration will be overwritten. Continue?');">⚠ Replace all settings with this JSON</button>
                            </div>
                            <p class="kf-help">Only the keys present in the pasted JSON are written — keys you don't include keep their current values. To do a "factory reset" first, drop the <code>mod_kwickflixstyle_settings</code> table manually before importing.</p>
                        </div>
                    </div>
                <?php kfSectionClose(false); /* read-only buttons inside — no main Save button for this section */ ?>
            </div>

            <!-- ════════════ HEADER ════════════ -->
            <div class="kf-pane" data-pane="header">

                <?php kfSectionOpen('header_logos', 'Logos', 'Two independent logo slots. Both are optional. Use one, the other, both, or neither.'); ?>
                    <div class="kf-info-box" style="font-size:12px;line-height:1.7;">
                        <strong>Where each logo renders:</strong>
                        <pre style="margin:8px 0 0;font-family:'SF Mono',Menlo,Consolas,monospace;font-size:11px;color:#5a5249;background:#fff;padding:10px 14px;border-radius:6px;border:1px solid #d8d3cc;overflow-x:auto;">┌──────────────────────────────────────────────┐
│              [ TOP CENTERED LOGO ]           │  ← only if "Top Centered Logo URL" is set
├──────────────────────────────────────────────┤
│  [HEADER LOGO]   nav  nav  nav   acct  cart  │  ← only if "Show navbar logo" is ON
└──────────────────────────────────────────────┘</pre>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <?php $headerLogoShow = ($s['header_logo_show'] ?? '1') === '1'; ?>
                            <label class="kf-toggle">
                                <input type="checkbox" name="header_logo_show" value="1" <?php echo $headerLogoShow ? 'checked' : ''; ?>>
                                Show navbar logo
                            </label>
                            <p class="kf-help">When OFF, the entire navbar brand area is hidden — no logo image and no company name text. Use this when the Top Centered Logo above is your full brand and the navbar slot would just duplicate it.</p>
                        </div>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="header_logo">Header Logo URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— inside the navbar</span></label>
                            <input type="text" id="header_logo" name="header_logo" value="<?php echo htmlspecialchars($v('header_logo')); ?>" placeholder="/templates/kwickflix/img/logo/navbar-logo.png">
                            <p class="kf-help">The standard logo that sits inside the navbar bar (where WHMCS normally puts your logo). Upload logos to <code>/templates/kwickflix/img/logo/</code> and reference as <code>/templates/kwickflix/img/logo/filename.png</code>, or paste any full external URL. If left blank, falls back to your WHMCS-configured logo. Transparent PNG/SVG ~58px tall fits best.</p>
                        </div>
                        <div class="kf-field">
                            <label for="header_top_logo">Top Centered Logo URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— big hero logo above the navbar</span></label>
                            <input type="text" id="header_top_logo" name="header_top_logo" value="<?php echo htmlspecialchars($v('header_top_logo')); ?>" placeholder="/templates/kwickflix/img/logo/hero-logo.png">
                            <p class="kf-help">An OPTIONAL extra logo that renders <em>above</em> the navbar, centered, like a hero banner. Bigger (up to 120px tall). Same folder applies — upload to <code>/templates/kwickflix/img/logo/</code> for local hosting. Leave blank to hide entirely (no toggle needed — empty = off).</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="favicon_url">Favicon URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— browser tab icon</span></label>
                            <input type="text" id="favicon_url" name="favicon_url" value="<?php echo htmlspecialchars($v('favicon_url')); ?>" placeholder="/templates/kwickflix/img/favicon.ico">
                            <p class="kf-help">The little icon shown in browser tabs and bookmarks. Standard formats: <code>.ico</code>, <code>.png</code>, <code>.svg</code> (32×32 or 16×16 works well). Upload to <code>/templates/kwickflix/img/</code> and reference as <code>/templates/kwickflix/img/filename.ico</code>, or paste any full external URL. Leave blank to use whatever your browser falls back to (usually the WHMCS default or nothing).</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('header_nav1', 'Primary Navbar (1st Row)', 'The default WHMCS navbar items render with no icons by default. Add Font Awesome icons, icon colors, and per-item hover glow colors. Add custom items by name to style menu items added by other plugins.'); ?>
                    <div class="kf-info-box" style="font-size:12px;">
                        <strong>Label</strong> must match the WHMCS menu item exactly (case-sensitive). <strong>Icon</strong> is a Font Awesome class like <code>fas fa-home</code> — leave blank for no icon. <strong>Icon Color</strong> tints just the icon. <strong>Glow Color</strong> sets the hover-glow halo for that pill. The Add button at the bottom lets you add items for any custom WHMCS menu entry.
                    </div>

                    <div class="kf-row" style="margin-top:14px;">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="nav1_strict_mode" value="1" <?php echo $v('nav1_strict_mode') === '1' ? 'checked' : ''; ?>>
                                Strict mode — only show items configured here
                            </label>
                            <p class="kf-help">
                                When ON, any navbar item added by WHMCS or by another addon/module is <strong>removed</strong> unless it appears in this list with visibility on. Use this to keep third-party plugins (e.g. a Free Store Credit addon, custom hooks) from sneaking pills into your navbar. Leave OFF to let other plugins coexist alongside your configured items.
                            </p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('nav1_items', $s) && is_array($s['nav1_items'])) {
                        $savedNav1 = $s['nav1_items'];
                    } else {
                        $savedNav1 = Settings::defaultNav1Items();
                    }
                    // Defensive: re-inject any missing WHMCS defaults so the
                    // admin always sees them. The ensureNav1Defaults helper
                    // also (re-)sets the protected flag based on label match,
                    // so old saves missing the flag still render correctly.
                    $savedNav1 = Settings::ensureNav1Defaults($savedNav1);
                    ?>

                    <?php
                    // Locked nav fixtures — Cart and User/Hello button.
                    // These are rendered by WHMCS in fixed positions on the
                    // RIGHT side of the navbar (independent of nav1 ordering).
                    // The admin can't move/delete them, but they should be
                    // able to style them with accent + glow colors so they
                    // visually match the rest of the navbar.
                    $cartColor       = $v('nav1_cart_color');
                    $cartBadgeColor  = $v('nav1_cart_badge_color');
                    $cartGlowColor   = $v('nav1_cart_glow_color');
                    $userGlowColor   = $v('nav1_user_glow_color');
                    // Notification pill: default ON. A missing row is treated
                    // as enabled so fresh installs get the pill out of the box.
                    $notifEnabled    = !array_key_exists('nav1_notif_enabled', $s) || $s['nav1_notif_enabled'] !== '0';
                    $notifColor      = $v('nav1_notif_color');
                    $notifBadgeColor = $v('nav1_notif_badge_color');
                    $notifGlowColor  = $v('nav1_notif_glow_color');
                    ?>
                    <div style="border:1px solid var(--kf-border);border-radius:8px;padding:14px 18px;margin:6px 0 18px;background:#faf8f4;">
                        <div style="font-weight:700;font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:#5a5249;margin-bottom:10px;">
                            Locked Navbar Fixtures
                            <span style="background:#e8f0fe;color:#1959c5;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Always shown</span>
                        </div>
                        <p class="kf-help" style="margin-top:0;margin-bottom:14px;">
                            The Cart button, Notifications pill, and User dropdown (the "Hello, {name}!" button) are rendered by WHMCS in fixed positions on the right side of the navbar. They can't be reordered, but you can toggle the Notifications pill and match their colors to your accent system below.
                        </p>

                        <div style="margin-bottom:14px;">
                            <label style="font-weight:600;color:#1f1a14;display:block;margin-bottom:4px;">
                                <i class="fas fa-shopping-cart" style="margin-right:6px;color:#7a7268;"></i> Cart button
                            </label>
                            <p class="kf-help" style="margin-top:0;margin-bottom:10px;">Icon, badge bubble, and glow color for the cart pill. Leave blank to use the default theme color.</p>
                            <div class="kf-row" style="align-items:flex-end;">
                                <div class="kf-field">
                                    <label for="nav1_cart_color">Icon color</label>
                                    <input type="color" id="nav1_cart_color" name="nav1_cart_color" value="<?php echo htmlspecialchars($cartColor !== '' ? $cartColor : '#1f1a14'); ?>">
                                </div>
                                <div class="kf-field">
                                    <label for="nav1_cart_badge_color">Badge bubble</label>
                                    <input type="color" id="nav1_cart_badge_color" name="nav1_cart_badge_color" value="<?php echo htmlspecialchars($cartBadgeColor !== '' ? $cartBadgeColor : '#00b4b4'); ?>">
                                </div>
                                <div class="kf-field">
                                    <label for="nav1_cart_glow_color">Hover glow</label>
                                    <input type="color" id="nav1_cart_glow_color" name="nav1_cart_glow_color" value="<?php echo htmlspecialchars($cartGlowColor !== '' ? $cartGlowColor : '#00b4b4'); ?>">
                                </div>
                            </div>
                        </div>

                        <div style="margin-bottom:14px;">
                            <label style="font-weight:600;color:#1f1a14;display:block;margin-bottom:4px;">
                                <i class="fas fa-flag" style="margin-right:6px;color:#7a7268;"></i> Notifications pill
                                <span style="background:#fff5e1;color:#8a5a00;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Logged-in only</span>
                            </label>
                            <p class="kf-help" style="margin-top:0;margin-bottom:10px;">Shows client alerts (overdue invoices, expiring services, etc.). Only renders for logged-in clients. Sits to the left of the cart button.</p>
                            <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px;">
                                <input type="checkbox" id="nav1_notif_enabled" name="nav1_notif_enabled" value="1" <?php echo $notifEnabled ? 'checked' : ''; ?>>
                                <label for="nav1_notif_enabled" style="margin:0;font-weight:600;color:#1f1a14;cursor:pointer;">Show notifications pill in navbar</label>
                            </div>
                            <div class="kf-row" style="align-items:flex-end;">
                                <div class="kf-field">
                                    <label for="nav1_notif_color">Icon color</label>
                                    <input type="color" id="nav1_notif_color" name="nav1_notif_color" value="<?php echo htmlspecialchars($notifColor !== '' ? $notifColor : '#1f1a14'); ?>">
                                </div>
                                <div class="kf-field">
                                    <label for="nav1_notif_badge_color">Badge bubble</label>
                                    <input type="color" id="nav1_notif_badge_color" name="nav1_notif_badge_color" value="<?php echo htmlspecialchars($notifBadgeColor !== '' ? $notifBadgeColor : '#e96a0b'); ?>">
                                </div>
                                <div class="kf-field">
                                    <label for="nav1_notif_glow_color">Hover glow</label>
                                    <input type="color" id="nav1_notif_glow_color" name="nav1_notif_glow_color" value="<?php echo htmlspecialchars($notifGlowColor !== '' ? $notifGlowColor : '#e96a0b'); ?>">
                                </div>
                            </div>
                        </div>

                        <div>
                            <label style="font-weight:600;color:#1f1a14;display:block;margin-bottom:4px;">
                                <i class="fas fa-user-circle" style="margin-right:6px;color:#7a7268;"></i> User / Hello button
                            </label>
                            <p class="kf-help" style="margin-top:0;margin-bottom:10px;">Hover glow color for the dropdown that shows "Hello, {Name}!" when a client is logged in. The icon color follows your master accent color.</p>
                            <div class="kf-row" style="align-items:flex-end;">
                                <div class="kf-field">
                                    <label for="nav1_user_glow_color">Hover glow</label>
                                    <input type="color" id="nav1_user_glow_color" name="nav1_user_glow_color" value="<?php echo htmlspecialchars($userGlowColor !== '' ? $userGlowColor : '#22a04a'); ?>">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="kf-nav1-list">
                        <?php foreach ($savedNav1 as $idx => $item): ?>
                            <?php echo kfRenderNav1Row($idx, $item); ?>
                        <?php endforeach; ?>
                    </div>

                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-nav1">+ Add Nav Item</button>
                    </div>

                    <template id="kf-nav1-template">
                        <?php echo kfRenderNav1Row('__INDEX__', ['label' => '', 'url' => '', 'icon' => '', 'icon_color' => '', 'glow_color' => '', 'visible' => '1', 'protected' => '0']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('header_nav2', 'Secondary Navbar (2nd Row)', 'An optional second row of buttons under the main navbar. Use it for service-specific links (channel guides, FAQs, Discord, etc.). Each button gets its own icon color and hover-glow color.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="header_nav2_enabled" value="1" <?php echo $v('header_nav2_enabled') === '1' ? 'checked' : ''; ?>>
                                Enable second navbar row
                            </label>
                            <p class="kf-help">When OFF, no second row is rendered regardless of the items below.</p>
                        </div>
                        <div class="kf-field" style="flex:0 0 280px;">
                            <label for="nav2_visibility">Show to</label>
                            <select id="nav2_visibility" name="nav2_visibility">
                                <option value="always"    <?php echo $v('nav2_visibility') !== 'logged_in' ? 'selected' : ''; ?>>Everyone (always visible)</option>
                                <option value="logged_in" <?php echo $v('nav2_visibility') === 'logged_in' ? 'selected' : ''; ?>>Logged-in clients only</option>
                            </select>
                            <p class="kf-help">"Logged-in only" hides this row from guests on the public-facing pages (homepage, login, etc.).</p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('nav2_items', $s) && is_array($s['nav2_items'])) {
                        $savedNav2 = $s['nav2_items'];
                    } else {
                        $savedNav2 = []; // start empty — opt-in feature
                    }
                    ?>

                    <div id="kf-nav2-list">
                        <?php foreach ($savedNav2 as $idx => $item): ?>
                            <?php echo kfRenderNav2Row($idx, $item); ?>
                        <?php endforeach; ?>
                    </div>

                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-nav2">+ Add Nav Item</button>
                    </div>

                    <template id="kf-nav2-template">
                        <?php echo kfRenderNav2Row('__INDEX__', ['title' => '', 'url' => '', 'icon' => '', 'icon_color' => '', 'glow_color' => '', 'target' => '']); ?>
                    </template>
                <?php kfSectionClose(); ?>
            </div>

            <!-- ════════════ HOMEPAGE ════════════ -->
            <div class="kf-pane" data-pane="homepage">

                <?php kfSectionOpen('hero_eyebrow', 'Hero — Site Phrase (Eyebrow)', 'Small uppercase tag at the top of the hero, with horizontal lines on either side. Renders above the motto.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_eyebrow_enabled" value="1" <?php echo (($s['hero_eyebrow_enabled'] ?? '1') === '1') ? 'checked' : ''; ?>>
                                Show site phrase (eyebrow)
                            </label>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="hero_eyebrow_text">Eyebrow Text</label>
                            <input type="text" id="hero_eyebrow_text" name="hero_eyebrow_text" value="<?php echo htmlspecialchars($v('hero_eyebrow_text')); ?>" placeholder="Your tagline (e.g. 'Brand — Premium Service')">
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('hero_motto', 'Hero — Motto / Big Headline', 'The huge multi-line headline. Last accent line renders in the highlight color.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_motto_enabled" value="1" <?php echo (($s['hero_motto_enabled'] ?? '1') === '1') ? 'checked' : ''; ?>>
                                Show motto (big headline)
                            </label>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="hero_motto_main">Main Lines <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— one line each, line-broken in display</span></label>
                            <textarea id="hero_motto_main" name="hero_motto_main" style="min-height:80px;font-family:inherit;font-size:14px;" placeholder="First line of your motto&#10;Second line"><?php echo htmlspecialchars($v('hero_motto_main')); ?></textarea>
                            <p class="kf-help">Each line of text becomes a separate display line. Renders in dark text.</p>
                        </div>
                        <div class="kf-field">
                            <label for="hero_motto_accent">Accent Line <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional, last line in highlight color</span></label>
                            <input type="text" id="hero_motto_accent" name="hero_motto_accent" value="<?php echo htmlspecialchars($v('hero_motto_accent')); ?>" placeholder="Final accent line">
                        </div>
                    </div>

                    <?php
                    // Hero accent color rotation: 1-10 colors. If 1, behaves
                    // like the old single-color setup (static). If >1, the
                    // page hook picks one at random on every render so the
                    // accent line + stats grid borders cycle between the
                    // configured colors on each page refresh.
                    //
                    // Storage: stored as JSON array hero_motto_accent_colors.
                    // Back-compat: a legacy single hero_motto_accent_color
                    // value is treated as the first color in the array when
                    // the array is empty.
                    $rotCount = max(1, min(10, (int) ($s['hero_motto_accent_count'] ?? 1)));
                    $rotColors = $s['hero_motto_accent_colors'] ?? [];
                    if (!is_array($rotColors)) {
                        $decoded = json_decode((string) $rotColors, true);
                        $rotColors = is_array($decoded) ? $decoded : [];
                    }
                    if (empty($rotColors)) {
                        // Legacy single-value fallback so existing installs
                        // don't lose their configured color on first render.
                        $legacy = (string) ($s['hero_motto_accent_color'] ?? '#f87171');
                        $rotColors = [$legacy];
                    }
                    // Pad to 10 slots so every picker has a value to render.
                    while (count($rotColors) < 10) {
                        $rotColors[] = '#f87171';
                    }
                    ?>

                    <div class="kf-row" style="margin-top:8px;">
                        <div class="kf-field" style="flex:0 0 240px;">
                            <label for="hero_motto_accent_count">Accent Color Rotation</label>
                            <select id="hero_motto_accent_count" name="hero_motto_accent_count" data-kf-accent-count>
                                <?php for ($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo $i; ?>" <?php echo $rotCount === $i ? 'selected' : ''; ?>>
                                        <?php echo $i === 1 ? '1 color (static)' : ($i . ' colors (random each refresh)'); ?>
                                    </option>
                                <?php endfor; ?>
                            </select>
                            <p class="kf-help">
                                Pick <strong>1</strong> for a single static accent color (current behavior). Pick <strong>2–10</strong> to rotate randomly — a different one is chosen every page refresh. Affects the motto accent line AND the stats grid border.
                            </p>
                        </div>
                        <div class="kf-field">
                            <label>Accent Colors</label>
                            <div data-kf-accent-color-grid style="display:flex;flex-wrap:wrap;gap:10px;">
                                <?php for ($i = 0; $i < 10; $i++): ?>
                                    <?php $colorVal = isset($rotColors[$i]) && preg_match('/^#[0-9A-Fa-f]{6}$/', $rotColors[$i]) ? $rotColors[$i] : '#f87171'; ?>
                                    <div data-kf-accent-color-slot data-slot-idx="<?php echo $i; ?>" style="display:<?php echo $i < $rotCount ? 'flex' : 'none'; ?>;flex-direction:column;align-items:center;gap:4px;">
                                        <span style="font-size:10px;color:#7a7268;font-weight:600;">#<?php echo $i + 1; ?></span>
                                        <input type="color" name="hero_motto_accent_colors[]" value="<?php echo htmlspecialchars($colorVal); ?>" style="width:46px;height:36px;padding:0;cursor:pointer;border:1px solid #d8d3cc;border-radius:6px;">
                                    </div>
                                <?php endfor; ?>
                            </div>
                            <p class="kf-help">Each color in the rotation. Slots beyond your count selection are hidden but their values are preserved if you bump the count up later.</p>
                        </div>
                    </div>

                    <script>
                    // Show/hide the right number of color picker slots when
                    // the count select changes. Hidden slots still POST their
                    // values so the admin can dial the count up later without
                    // losing colors they'd configured.
                    (function () {
                        var sel = document.querySelector('[data-kf-accent-count]');
                        if (!sel) return;
                        var grid = document.querySelector('[data-kf-accent-color-grid]');
                        if (!grid) return;
                        sel.addEventListener('change', function () {
                            var n = parseInt(sel.value, 10) || 1;
                            grid.querySelectorAll('[data-kf-accent-color-slot]').forEach(function (slot) {
                                var idx = parseInt(slot.getAttribute('data-slot-idx'), 10);
                                slot.style.display = idx < n ? 'flex' : 'none';
                            });
                        });
                    })();
                    </script>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('hero_description', 'Hero — Description', 'A short paragraph below the motto.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_description_enabled" value="1" <?php echo (($s['hero_description_enabled'] ?? '1') === '1') ? 'checked' : ''; ?>>
                                Show description
                            </label>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="hero_description_text">Description Text</label>
                            <textarea id="hero_description_text" name="hero_description_text" style="min-height:70px;font-family:inherit;font-size:14px;" placeholder="A short description of what you offer."><?php echo htmlspecialchars($v('hero_description_text')); ?></textarea>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('hero_stats', 'Hero — Stats Grid', 'A bordered card showing one or more stats. Each stat: a number, an optional accent highlight (like + or ★) shown in the accent color, and a small label underneath. Add as many as you like — they wrap to a new row as needed.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_stats_enabled" value="1" <?php echo $v('hero_stats_enabled') === '1' ? 'checked' : ''; ?>>
                                Show stats grid
                            </label>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('hero_stats', $s) && is_array($s['hero_stats'])) {
                        $savedStats = $s['hero_stats'];
                    } else {
                        $savedStats = []; // opt-in
                    }
                    ?>

                    <div id="kf-stats-list">
                        <?php foreach ($savedStats as $idx => $stat): ?>
                            <?php echo kfRenderStatRow($idx, $stat); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-stat">+ Add Stat</button>
                    </div>
                    <template id="kf-stat-template">
                        <?php echo kfRenderStatRow('__INDEX__', ['number' => '', 'highlight' => '', 'label' => '']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('hero_social', 'Hero — Social Bar', 'A row of clickable tiles directly under the stats grid, styled to match it. Each tile: an image OR a Font Awesome icon, plus a label and a link. Every link always opens in a new tab. Use this for things like Discord / Telegram / Twitter / Status Page / Reviews — anything you want one-click accessible from the homepage.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_social_enabled" value="1" <?php echo $v('hero_social_enabled') === '1' ? 'checked' : ''; ?>>
                                Show social bar
                            </label>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('hero_social', $s) && is_array($s['hero_social'])) {
                        $savedSocial = $s['hero_social'];
                    } else {
                        $savedSocial = []; // opt-in
                    }
                    ?>

                    <div id="kf-hero-social-list">
                        <?php foreach ($savedSocial as $idx => $soc): ?>
                            <?php echo kfRenderSocialRow($idx, $soc); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-hero-social">+ Add Social Tile</button>
                    </div>
                    <template id="kf-hero-social-template">
                        <?php echo kfRenderSocialRow('__INDEX__', ['image' => '', 'icon' => '', 'icon_color' => '', 'label' => '', 'url' => '', 'visible' => '1']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('hero_marquee', 'Hero — Logo Marquee', 'A horizontally scrolling row of brand logos at the bottom of the hero. Add SVG/PNG image URLs below.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="hero_marquee_enabled" value="1" <?php echo $v('hero_marquee_enabled') === '1' ? 'checked' : ''; ?>>
                                Show logo marquee
                            </label>

                            <label class="kf-toggle" style="margin-top:14px;">
                                <input type="checkbox" name="hero_marquee_greyscale" value="1" <?php echo (!isset($s['hero_marquee_greyscale']) || $s['hero_marquee_greyscale'] === '1') ? 'checked' : ''; ?>>
                                Show logos in greyscale
                            </label>
                            <p class="kf-help">When ON (default), all logos are desaturated and slightly faded. Hover over each to see it briefly in color.</p>
                        </div>
                        <div class="kf-field" style="flex:0 0 220px;">
                            <label for="hero_marquee_speed">Scroll Speed</label>
                            <?php $mqSpeed = isset($s['hero_marquee_speed']) ? $s['hero_marquee_speed'] : '1'; ?>
                            <select id="hero_marquee_speed" name="hero_marquee_speed">
                                <option value="0.5"  <?php echo $mqSpeed === '0.5'  ? 'selected' : ''; ?>>0.5× (very slow)</option>
                                <option value="0.75" <?php echo $mqSpeed === '0.75' ? 'selected' : ''; ?>>0.75× (slow)</option>
                                <option value="1"    <?php echo $mqSpeed === '1'    ? 'selected' : ''; ?>>1× (default)</option>
                                <option value="1.5"  <?php echo $mqSpeed === '1.5'  ? 'selected' : ''; ?>>1.5×</option>
                                <option value="2"    <?php echo $mqSpeed === '2'    ? 'selected' : ''; ?>>2×</option>
                                <option value="2.5"  <?php echo $mqSpeed === '2.5'  ? 'selected' : ''; ?>>2.5×</option>
                                <option value="3"    <?php echo $mqSpeed === '3'    ? 'selected' : ''; ?>>3×</option>
                                <option value="4"    <?php echo $mqSpeed === '4'    ? 'selected' : ''; ?>>4×</option>
                                <option value="5"    <?php echo $mqSpeed === '5'    ? 'selected' : ''; ?>>5× (fast)</option>
                                <option value="7"    <?php echo $mqSpeed === '7'    ? 'selected' : ''; ?>>7× (very fast)</option>
                                <option value="10"   <?php echo $mqSpeed === '10'   ? 'selected' : ''; ?>>10× (extreme)</option>
                            </select>
                            <p class="kf-help">Higher = faster horizontal scroll. The loop is seamless regardless of speed.</p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('hero_marquee', $s) && is_array($s['hero_marquee'])) {
                        $savedMarquee = $s['hero_marquee'];
                    } else {
                        $savedMarquee = [];
                    }
                    ?>

                    <div id="kf-marquee-list">
                        <?php foreach ($savedMarquee as $idx => $item): ?>
                            <?php echo kfRenderMarqueeRow($idx, $item); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-marquee">+ Add Logo</button>
                    </div>
                    <template id="kf-marquee-template">
                        <?php echo kfRenderMarqueeRow('__INDEX__', ['url' => '', 'alt' => '']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('reviews_block', 'Latest & Member Reviews', 'A box that combines the latest WHMCS announcement with a horizontally scrolling marquee of customer reviews, plus a row of social buttons (Discord, Telegram, etc.) underneath.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="reviews_enabled" value="1" <?php echo $v('reviews_enabled') === '1' ? 'checked' : ''; ?>>
                                Show "Latest & Member Reviews" block
                            </label>
                            <p class="kf-help">When OFF, nothing in this section renders on the homepage regardless of items below.</p>
                        </div>
                    </div>

                    <hr class="kf-divider">

                    <h4 style="margin:6px 0 4px;font-size:14px;font-weight:700;color:#13110e;">Announcement panel (left side)</h4>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $annoEnabled = ($s['reviews_announcement_enabled'] ?? '1') === '1'; ?>
                                <input type="checkbox" name="reviews_announcement_enabled" value="1" <?php echo $annoEnabled ? 'checked' : ''; ?>>
                                Show announcement panel
                            </label>
                            <p class="kf-help">Auto-pulls the most recent WHMCS announcement and links to it. Falls back to a "No Current Announcements" placeholder if none exist.</p>
                        </div>
                    </div>

                    <hr class="kf-divider">

                    <h4 style="margin:6px 0 4px;font-size:14px;font-weight:700;color:#13110e;">Reviews panel (right side)</h4>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="reviews_title">Reviews Title</label>
                            <input type="text" id="reviews_title" name="reviews_title" value="<?php echo htmlspecialchars($v('reviews_title', 'Member Reviews') ?: 'Member Reviews'); ?>" placeholder="Member Reviews">
                        </div>
                        <div class="kf-field">
                            <label for="reviews_subtitle">Reviews Subtitle</label>
                            <input type="text" id="reviews_subtitle" name="reviews_subtitle" value="<?php echo htmlspecialchars($v('reviews_subtitle', 'Real feedback from real subscribers') ?: 'Real feedback from real subscribers'); ?>" placeholder="Real feedback from real subscribers">
                        </div>
                        <div class="kf-field" style="flex:0 0 220px;">
                            <label for="reviews_marquee_speed">Marquee Speed</label>
                            <?php $rvSpeed = isset($s['reviews_marquee_speed']) ? $s['reviews_marquee_speed'] : '1'; ?>
                            <select id="reviews_marquee_speed" name="reviews_marquee_speed">
                                <option value="0.5"  <?php echo $rvSpeed === '0.5'  ? 'selected' : ''; ?>>0.5× (very slow)</option>
                                <option value="0.75" <?php echo $rvSpeed === '0.75' ? 'selected' : ''; ?>>0.75× (slow)</option>
                                <option value="1"    <?php echo $rvSpeed === '1'    ? 'selected' : ''; ?>>1× (default)</option>
                                <option value="1.5"  <?php echo $rvSpeed === '1.5'  ? 'selected' : ''; ?>>1.5×</option>
                                <option value="2"    <?php echo $rvSpeed === '2'    ? 'selected' : ''; ?>>2×</option>
                                <option value="2.5"  <?php echo $rvSpeed === '2.5'  ? 'selected' : ''; ?>>2.5×</option>
                                <option value="3"    <?php echo $rvSpeed === '3'    ? 'selected' : ''; ?>>3×</option>
                                <option value="4"    <?php echo $rvSpeed === '4'    ? 'selected' : ''; ?>>4×</option>
                                <option value="5"    <?php echo $rvSpeed === '5'    ? 'selected' : ''; ?>>5× (fast)</option>
                                <option value="7"    <?php echo $rvSpeed === '7'    ? 'selected' : ''; ?>>7× (very fast)</option>
                                <option value="10"   <?php echo $rvSpeed === '10'   ? 'selected' : ''; ?>>10× (extreme)</option>
                            </select>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('reviews_items', $s) && is_array($s['reviews_items'])) {
                        $savedReviews = $s['reviews_items'];
                    } else {
                        $savedReviews = [];
                    }
                    ?>

                    <div id="kf-reviews-list">
                        <?php foreach ($savedReviews as $idx => $rv): ?>
                            <?php echo kfRenderReviewRow($idx, $rv); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-review">+ Add Review</button>
                    </div>
                    <template id="kf-review-template">
                        <?php echo kfRenderReviewRow('__INDEX__', ['stars' => '5', 'text' => '', 'author' => '', 'link' => '']); ?>
                    </template>

                    <hr class="kf-divider">

                    <h4 style="margin:6px 0 4px;font-size:14px;font-weight:700;color:#13110e;">Social buttons (bottom row)</h4>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="social_buttons_enabled" value="1" <?php echo (!array_key_exists('social_buttons_enabled', $s) || $s['social_buttons_enabled'] === '1') ? 'checked' : ''; ?>>
                                Show social button row
                            </label>
                            <p class="kf-help">A centered row of branded buttons under the announcement + reviews panels. Each button gets its own brand color (icon + border tint).</p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('social_buttons', $s) && is_array($s['social_buttons'])) {
                        $savedSocial = $s['social_buttons'];
                    } else {
                        $savedSocial = [];
                    }
                    ?>

                    <div id="kf-social-list">
                        <?php foreach ($savedSocial as $idx => $b): ?>
                            <?php echo kfRenderSocialBtnRow($idx, $b); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-social">+ Add Social Button</button>
                    </div>
                    <template id="kf-social-template">
                        <?php echo kfRenderSocialBtnRow('__INDEX__', ['label' => '', 'url' => '', 'icon' => '', 'color' => '#5561EA', 'target' => '_blank']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('homepage_cards', 'Homepage Cards', 'The default WHMCS homepage cards have been removed. Replace them with as many custom service cards as you want — add, remove, and reorder freely. A single placeholder card is shown by default; edit it, delete it, or click "+ Add Card" to add more.'); ?>
                    <div class="kf-info-box" style="font-size:12px;">
                        <strong>Each card has:</strong> a toggle, title, subtitle, optional description, button link, 3 bullet points, accent color (drives bullets + button), and an image URL. Cards render in the order shown here. Empty cards (no title, no fields) are auto-removed on save.
                    </div>

                    <?php
                    if (array_key_exists('homepage_cards', $s) && is_array($s['homepage_cards']) && !empty($s['homepage_cards'])) {
                        $savedCards = $s['homepage_cards'];
                    } else {
                        $savedCards = Settings::defaultCards();
                    }
                    ?>

                    <div id="kf-cards-list">
                        <?php foreach ($savedCards as $idx => $card): ?>
                            <?php echo kfRenderCardRow($idx, $card); ?>
                        <?php endforeach; ?>
                    </div>

                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-card">+ Add Card</button>
                    </div>

                    <template id="kf-card-template">
                        <?php echo kfRenderCardRow('__INDEX__', [
                            'enabled' => '1','title' => '','subtitle' => '','description' => '','link' => '',
                            'bullet1' => '','bullet2' => '','bullet3' => '','accent' => '#22a04a','image' => '',
                        ]); ?>
                    </template>
                <?php kfSectionClose(); ?>
            </div>

            <!-- ════════════ FOOTER ════════════ -->
            <div class="kf-pane" data-pane="footer">

                <?php kfSectionOpen('footer_brand', 'Brand Block', 'The left side of the footer — your logo + a short description.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <?php $footerLogoShow = ($s['footer_logo_show'] ?? '1') === '1'; ?>
                            <label class="kf-toggle">
                                <input type="checkbox" name="footer_logo_show" value="1" <?php echo $footerLogoShow ? 'checked' : ''; ?>>
                                Show footer logo
                            </label>
                            <p class="kf-help">When OFF, no logo image is rendered in the footer — the brand block falls back to a text-only company name. The URL field below is ignored.</p>
                        </div>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="footer_logo">Footer Logo URL</label>
                            <input type="text" id="footer_logo" name="footer_logo" value="<?php echo htmlspecialchars($v('footer_logo')); ?>" placeholder="https://example.com/footer-logo.png">
                            <p class="kf-help">Optional. Falls back to your WHMCS logo if blank (and the toggle above is on). Display height is 34px.</p>
                        </div>
                    </div>

                    <div class="kf-row">
                        <div class="kf-field">
                            <label for="footer_description">Short Description</label>
                            <textarea id="footer_description" name="footer_description" style="min-height:90px;font-family:inherit;font-size:13px;" placeholder="A short tagline or company description (2–3 sentences)..."><?php echo htmlspecialchars($v('footer_description')); ?></textarea>
                            <p class="kf-help">2–3 short sentences. Plain text — line breaks render normally.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('footer_columns', 'Three Link Columns', 'Each column has a title and a list of links. Per-link: label, URL, optional Font Awesome icon, open in new tab, and enable/disable toggle. Disabled links keep their settings but don\'t render.'); ?>
                    <?php
                    // Render all three columns in a grid. Each column is an
                    // independent repeater with its own Add button + clone
                    // template scoped by data-kf-col so the JS doesn't get
                    // confused across columns.
                    for ($_col = 1; $_col <= 3; $_col++):
                        $titleKey = "footer_col{$_col}_title";
                        $iconKey  = "footer_col{$_col}_icon";
                        $itemsKey = "footer_col{$_col}_items";
                        $defaultColTitles = [1 => 'Quick Links', 2 => 'Support', 3 => 'Resources'];
                        $items = (isset($s[$itemsKey]) && is_array($s[$itemsKey])) ? $s[$itemsKey] : [];
                    ?>
                    <div style="border:1px solid var(--kf-border);border-radius:8px;padding:18px;margin-bottom:14px;background:var(--kf-surface2);">
                        <div class="kf-row" style="margin-bottom:10px;">
                            <div class="kf-field" style="flex:2;">
                                <label for="<?php echo $titleKey; ?>"><strong>Column <?php echo $_col; ?> Title</strong></label>
                                <input type="text" id="<?php echo $titleKey; ?>" name="<?php echo $titleKey; ?>" value="<?php echo htmlspecialchars($v($titleKey)); ?>" placeholder="<?php echo htmlspecialchars($defaultColTitles[$_col]); ?>">
                            </div>
                            <div class="kf-field" style="flex:1;">
                                <label for="<?php echo $iconKey; ?>"><strong>Column <?php echo $_col; ?> Icon</strong> <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                                <input type="text" id="<?php echo $iconKey; ?>" name="<?php echo $iconKey; ?>" value="<?php echo htmlspecialchars($v($iconKey)); ?>" placeholder="e.g. fas fa-link, fab fa-discord">
                            </div>
                        </div>

                        <div id="kf-footer-col<?php echo $_col; ?>-list" data-kf-col="<?php echo $_col; ?>">
                            <?php foreach ($items as $idx => $linkItem): ?>
                                <?php echo kfRenderFooterLinkRow($_col, $idx, $linkItem); ?>
                            <?php endforeach; ?>
                        </div>

                        <div style="display:flex;gap:10px;margin-top:10px;">
                            <button type="button" class="kf-btn kf-btn-add" data-kf-add-footer-link="<?php echo $_col; ?>">+ Add Link to Column <?php echo $_col; ?></button>
                        </div>

                        <template id="kf-footer-col<?php echo $_col; ?>-template">
                            <?php echo kfRenderFooterLinkRow($_col, '__INDEX__', ['label' => '', 'url' => '', 'target' => '', 'enabled' => '1']); ?>
                        </template>
                    </div>
                    <?php endfor; ?>
                <?php kfSectionClose(); ?>
            </div>

            <!-- ════════════ CART / CHECKOUT ════════════ -->
            <div class="kf-pane" data-pane="cart">

                <?php kfSectionOpen('checkout_marquee', 'Checkout — Marquee', 'A horizontally scrolling row of logos rendered at the top of cart.php (the viewcart and checkout steps). Mirror of the hero logo marquee but with its own image set — typical use is crypto / payment-provider icons, badges, or accepted-currency strips.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <input type="checkbox" name="checkout_marquee_enabled" value="1" <?php echo $v('checkout_marquee_enabled') === '1' ? 'checked' : ''; ?>>
                                Show checkout marquee
                            </label>

                            <label class="kf-toggle" style="margin-top:14px;">
                                <input type="checkbox" name="checkout_marquee_greyscale" value="1" <?php echo (!isset($s['checkout_marquee_greyscale']) || $s['checkout_marquee_greyscale'] === '1') ? 'checked' : ''; ?>>
                                Show logos in greyscale
                            </label>
                            <p class="kf-help">When ON (default), all logos are desaturated and slightly faded. Hover over each to see it briefly in color.</p>
                        </div>
                        <div class="kf-field" style="flex:0 0 220px;">
                            <label for="checkout_marquee_speed">Scroll Speed</label>
                            <?php $cmSpeed = isset($s['checkout_marquee_speed']) ? $s['checkout_marquee_speed'] : '1'; ?>
                            <select id="checkout_marquee_speed" name="checkout_marquee_speed">
                                <option value="0.5"  <?php echo $cmSpeed === '0.5'  ? 'selected' : ''; ?>>0.5× (very slow)</option>
                                <option value="0.75" <?php echo $cmSpeed === '0.75' ? 'selected' : ''; ?>>0.75× (slow)</option>
                                <option value="1"    <?php echo $cmSpeed === '1'    ? 'selected' : ''; ?>>1× (default)</option>
                                <option value="1.5"  <?php echo $cmSpeed === '1.5'  ? 'selected' : ''; ?>>1.5×</option>
                                <option value="2"    <?php echo $cmSpeed === '2'    ? 'selected' : ''; ?>>2×</option>
                                <option value="2.5"  <?php echo $cmSpeed === '2.5'  ? 'selected' : ''; ?>>2.5×</option>
                                <option value="3"    <?php echo $cmSpeed === '3'    ? 'selected' : ''; ?>>3×</option>
                                <option value="4"    <?php echo $cmSpeed === '4'    ? 'selected' : ''; ?>>4×</option>
                                <option value="5"    <?php echo $cmSpeed === '5'    ? 'selected' : ''; ?>>5× (fast)</option>
                                <option value="7"    <?php echo $cmSpeed === '7'    ? 'selected' : ''; ?>>7× (very fast)</option>
                                <option value="10"   <?php echo $cmSpeed === '10'   ? 'selected' : ''; ?>>10× (extreme)</option>
                            </select>
                            <p class="kf-help">Higher = faster horizontal scroll. The loop is seamless regardless of speed.</p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('checkout_marquee', $s) && is_array($s['checkout_marquee'])) {
                        $savedCheckoutMarquee = $s['checkout_marquee'];
                    } else {
                        $savedCheckoutMarquee = [];
                    }
                    ?>

                    <div id="kf-checkout-marquee-list">
                        <?php foreach ($savedCheckoutMarquee as $idx => $item): ?>
                            <?php echo kfRenderMarqueeRow($idx, $item, 'checkout_marquee'); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-checkout-marquee">+ Add Logo</button>
                    </div>
                    <template id="kf-checkout-marquee-template">
                        <?php echo kfRenderMarqueeRow('__INDEX__', ['url' => '', 'alt' => ''], 'checkout_marquee'); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php
                /*
                 * Three configurable notice slots, each rendered by the cart
                 * templates at a fixed position. Wrapped in ONE outer
                 * collapsible section with three sub-dropdowns inside, to
                 * match the Primary Navbar / Hero Marquee pattern (admin
                 * expands the outer "Notices" section, then expands the
                 * individual notice slot they want to edit).
                 *
                 *   CP   → configureproduct.tpl, where the stock "Have
                 *          Questions?" alert used to live.
                 *   COT  → checkout.tpl, right under the page heading
                 *          ("Review & Checkout").
                 *   COB  → checkout.tpl, right above the Terms of Service /
                 *          submit block (where the stock "Your store login
                 *          details" alert used to live).
                 *
                 * Defaults match the previously-hardcoded stock notices for
                 * CP and COB so a fresh install looks unchanged. COT defaults
                 * to disabled — new slot, no stock equivalent to mimic.
                 */
                $cartNotices = [
                    'cp' => [
                        'title_field'    => 'Configure Product Notice',
                        'location'       => 'Configure-product step, above the Continue button',
                        'enabled'        => !array_key_exists('cart_notice_cp_enabled', $s) || $s['cart_notice_cp_enabled'] === '1',
                        'severity'       => $s['cart_notice_cp_severity'] ?? 'warning',
                        'icon'           => array_key_exists('cart_notice_cp_icon',  $s) ? $s['cart_notice_cp_icon']  : 'fas fa-question-circle',
                        'title_content'  => array_key_exists('cart_notice_cp_title', $s) ? $s['cart_notice_cp_title'] : '',
                        'html'           => array_key_exists('cart_notice_cp_html',  $s) ? $s['cart_notice_cp_html']  : 'Have Questions? Contact a staff member before proceeding! <a href="#" onclick="$crisp.push([\'do\', \'chat:open\']);void 0;" class="alert-link">Click here to start a chat.</a>',
                    ],
                    'co_top' => [
                        'title_field'    => 'Checkout Page Notice (Top)',
                        'location'       => 'Final checkout page, between credit balance options and the payment gateway list',
                        'enabled'        => !empty($s['cart_notice_co_top_enabled']),
                        'severity'       => $s['cart_notice_co_top_severity'] ?? 'info',
                        'icon'           => array_key_exists('cart_notice_co_top_icon',  $s) ? $s['cart_notice_co_top_icon']  : '',
                        'title_content'  => array_key_exists('cart_notice_co_top_title', $s) ? $s['cart_notice_co_top_title'] : '',
                        'html'           => array_key_exists('cart_notice_co_top_html',  $s) ? $s['cart_notice_co_top_html']  : '',
                    ],
                    'co_bot' => [
                        'title_field'    => 'Checkout Page Notice (Bottom)',
                        'location'       => 'Final checkout page, right above the Terms of Service',
                        'enabled'        => !array_key_exists('cart_notice_co_bot_enabled', $s) || $s['cart_notice_co_bot_enabled'] === '1',
                        'severity'       => $s['cart_notice_co_bot_severity'] ?? 'warning',
                        'icon'           => array_key_exists('cart_notice_co_bot_icon',  $s) ? $s['cart_notice_co_bot_icon']  : '',
                        'title_content'  => array_key_exists('cart_notice_co_bot_title', $s) ? $s['cart_notice_co_bot_title'] : '',
                        'html'           => array_key_exists('cart_notice_co_bot_html',  $s) ? $s['cart_notice_co_bot_html']  : 'Your store login details will be the email and password you create during checkout.',
                    ],
                ];
                ?>

                <?php kfSectionOpen('cart_notices', 'Cart/Checkout — Notice Boxes', 'Three editable alert boxes rendered at fixed positions on the cart flow. Each one can be independently enabled/disabled, color-themed (info / success / warning / danger), assigned a Font Awesome icon, and given custom HTML body content. Defaults match the stock kwick_cart notices so a fresh install looks unchanged.'); ?>
                    <?php foreach ($cartNotices as $slug => $n): ?>
                        <?php kfRenderNoticeEditor($slug, $n); ?>
                    <?php endforeach; ?>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('payment_gateways', 'Cart/Checkout — Payment Gateways', 'Admin-controlled rendering of payment options on the checkout page. Each row binds to one WHMCS gateway (from Setup → Payments) and controls its display title, subtext, icon, optional "Preferred" ribbon, and stacking order. Drag the ⋮⋮ handle to reorder. If you don\'t add any rows, the cart falls back to WHMCS\'s default gateway list with stock styling.'); ?>
                    <?php
                    $activeGateways  = kfGetActivePaymentGateways();
                    $savedGateways   = (array_key_exists('payment_gateways', $s) && is_array($s['payment_gateways']))
                        ? $s['payment_gateways']
                        : [];
                    // Section-level color overrides applied across the cart's
                    // payment-gateway cards. NOTE the non-preferred border/glow
                    // color is now SET PER-GATEWAY (in each row), not section-
                    // level — find it on the row editor below.
                    $pgRibbonColor    = isset($s['payment_ribbon_color'])    ? trim($s['payment_ribbon_color'])    : '';
                    $pgPreferredColor = isset($s['payment_preferred_color']) ? trim($s['payment_preferred_color']) : '';
                    ?>

                    <div class="kf-row" style="background:var(--kf-surface-2,#f7f5f0);border:1px dashed var(--kf-border,#d8d3cc);border-radius:10px;padding:14px 16px;margin-bottom:18px;">
                        <div class="kf-field" style="flex:0 0 240px;">
                            <label>"Preferred" Ribbon Color</label>
                            <input type="color" name="payment_ribbon_color" value="<?php echo htmlspecialchars($pgRibbonColor !== '' ? $pgRibbonColor : '#fdc858', ENT_QUOTES); ?>">
                            <label class="kf-toggle" style="margin-top:6px;">
                                <input type="checkbox" name="payment_ribbon_color_enabled" value="1" <?php echo $pgRibbonColor !== '' ? 'checked' : ''; ?>>
                                Override default gold ribbon
                            </label>
                            <p class="kf-help">When off, the ribbon uses the built-in gold gradient. When on, the picked color becomes the solid ribbon background.</p>
                        </div>
                        <div class="kf-field" style="flex:0 0 240px;">
                            <label>"Preferred" Border / Glow Color</label>
                            <input type="color" name="payment_preferred_color" value="<?php echo htmlspecialchars($pgPreferredColor !== '' ? $pgPreferredColor : '#d97706', ENT_QUOTES); ?>">
                            <label class="kf-toggle" style="margin-top:6px;">
                                <input type="checkbox" name="payment_preferred_color_enabled" value="1" <?php echo $pgPreferredColor !== '' ? 'checked' : ''; ?>>
                                Override default gold accent
                            </label>
                            <p class="kf-help">When a Preferred gateway is selected, its border + inner glow use this color (defaults to rich gold). Overrides any per-row color setting so the preferred treatment stays distinctive.</p>
                        </div>
                    </div>

                    <div id="kf-payment-gateways-list">
                        <?php foreach ($savedGateways as $pgIdx => $pg): ?>
                            <?php echo kfRenderPaymentGatewayRow($pgIdx, $pg, $activeGateways); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-payment-gateway">+ Add Payment Gateway</button>
                    </div>
                    <template id="kf-payment-gateway-template">
                        <?php echo kfRenderPaymentGatewayRow('__INDEX__', ['gateway' => '', 'title' => '', 'subtext' => '', 'icon' => '', 'preferred' => '0', 'preferred_label' => 'PREFERRED', 'accent' => '', 'visible' => '1'], $activeGateways); ?>
                    </template>
                <?php kfSectionClose(); ?>

            </div>

            <!-- ════════════ CLIENT AREA ════════════ -->
            <div class="kf-pane" data-pane="clientarea">

                <?php kfSectionOpen('ca_stat_tiles', 'Top Stat Tiles', 'The row of cards at the top of the client area home (clientareahome.tpl) — by default: Services, Domains, Invoices, Live Chat. Add/remove/reorder freely. The stat number for each tile is pulled live from WHMCS\'s client stats.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $stEnabled = ($s['stat_tiles_enabled'] ?? '1') === '1'; ?>
                                <input type="checkbox" name="stat_tiles_enabled" value="1" <?php echo $stEnabled ? 'checked' : ''; ?>>
                                Show stat tiles row on client area home
                            </label>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('stat_tiles', $s) && is_array($s['stat_tiles'])) {
                        $savedTiles = $s['stat_tiles'];
                    } else {
                        $savedTiles = Settings::defaultStatTiles();
                    }
                    ?>

                    <div id="kf-stat-tiles-list">
                        <?php foreach ($savedTiles as $idx => $t): ?>
                            <?php echo kfRenderStatTileRow($idx, $t); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-stat-tile">+ Add Stat Tile</button>
                    </div>
                    <template id="kf-stat-tile-template">
                        <?php echo kfRenderStatTileRow('__INDEX__', ['title' => '', 'subtext' => '', 'icon' => '', 'color' => '#1a6fff', 'stat' => 'dashes', 'url' => '#', 'visible' => '1']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('ca_info_cards', 'Custom Info Cards', 'Optional banner cards between the stat tiles and WHMCS\'s built-in panels. Each card has a title, icon, description, single CTA button, and accent color (top border). Empty by default — add only the cards you want.'); ?>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $icEnabled = ($s['info_cards_enabled'] ?? '0') === '1'; ?>
                                <input type="checkbox" name="info_cards_enabled" value="1" <?php echo $icEnabled ? 'checked' : ''; ?>>
                                Show custom info cards section
                            </label>
                            <p class="kf-help">When off, no info cards render regardless of how many are configured below.</p>
                        </div>
                    </div>

                    <?php
                    if (array_key_exists('info_cards', $s) && is_array($s['info_cards'])) {
                        $savedCards = $s['info_cards'];
                    } else {
                        $savedCards = [];
                    }
                    ?>

                    <div id="kf-info-cards-list">
                        <?php foreach ($savedCards as $idx => $c): ?>
                            <?php echo kfRenderInfoCardRow($idx, $c); ?>
                        <?php endforeach; ?>
                    </div>
                    <div style="display:flex;gap:10px;margin-top:14px;">
                        <button type="button" class="kf-btn kf-btn-add" id="kf-add-info-card">+ Add Info Card</button>
                    </div>
                    <template id="kf-info-card-template">
                        <?php echo kfRenderInfoCardRow('__INDEX__', ['title' => '', 'icon' => '', 'description' => '', 'btn_text' => '', 'btn_url' => '', 'color' => '#1a6fff', 'visible' => '1', 'product_ids' => '']); ?>
                    </template>
                <?php kfSectionClose(); ?>

                <?php kfSectionOpen('ca_panel_accents', 'WHMCS Panel Accents', 'The accent color (top border) for each of WHMCS\'s built-in client-area home panels. These render below your stat tiles and custom info cards.'); ?>
                    <?php $pa = Settings::defaultPanelAccents(); ?>
                    <div class="kf-row">
                        <div class="kf-field" style="flex:0 0 280px;">
                            <label>Active Products/Services</label>
                            <input type="color" name="panel_active_products" value="<?php echo htmlspecialchars($v('panel_active_products', $pa['active_products']) ?: $pa['active_products']); ?>">
                        </div>
                        <div class="kf-field" style="flex:0 0 280px;">
                            <label>Recent News</label>
                            <input type="color" name="panel_recent_news" value="<?php echo htmlspecialchars($v('panel_recent_news', $pa['recent_news']) ?: $pa['recent_news']); ?>">
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field" style="flex:0 0 280px;">
                            <label>Affiliate Program</label>
                            <input type="color" name="panel_affiliate" value="<?php echo htmlspecialchars($v('panel_affiliate', $pa['affiliate']) ?: $pa['affiliate']); ?>">
                        </div>
                        <div class="kf-field" style="flex:0 0 280px;">
                            <label>Recent Support Tickets</label>
                            <input type="color" name="panel_recent_tickets" value="<?php echo htmlspecialchars($v('panel_recent_tickets', $pa['recent_tickets']) ?: $pa['recent_tickets']); ?>">
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $rnHidden = ($s['panel_recent_news_hidden'] ?? '0') === '1'; ?>
                                <input type="checkbox" name="panel_recent_news_hidden" value="1" <?php echo $rnHidden ? 'checked' : ''; ?>>
                                Hide "Recent News" panel entirely
                            </label>
                            <p class="kf-help">Removes the recent-news/announcements card from the client area home. Hidden via CSS — WHMCS still publishes announcements at <code>/announcements.php</code>.</p>
                        </div>
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $afHidden = ($s['panel_affiliate_hidden'] ?? '0') === '1'; ?>
                                <input type="checkbox" name="panel_affiliate_hidden" value="1" <?php echo $afHidden ? 'checked' : ''; ?>>
                                Hide "Affiliate Program" panel entirely
                            </label>
                            <p class="kf-help">Removes the affiliate-program promo card from the client area home. The <code>/affiliates.php</code> page itself stays accessible (and is still reachable from the user menu).</p>
                        </div>
                    </div>
                    <div class="kf-row">
                        <div class="kf-field">
                            <label class="kf-toggle">
                                <?php $rtHidden = ($s['panel_recent_tickets_hidden'] ?? '0') === '1'; ?>
                                <input type="checkbox" name="panel_recent_tickets_hidden" value="1" <?php echo $rtHidden ? 'checked' : ''; ?>>
                                Hide "Recent Support Tickets" panel entirely
                            </label>
                            <p class="kf-help">Some setups prefer to keep this off the home page since it duplicates the Support tab. Hidden via CSS — WHMCS still tracks tickets internally.</p>
                        </div>
                    </div>
                <?php kfSectionClose(); ?>
            </div>

            <!-- ════════════ HELP ════════════ -->
            <div class="kf-pane" data-pane="help">
                <?php kfSectionOpen('help_rules', 'The Hard Rules — Read These First', 'Three non-negotiables that prevent 95% of "why doesn\'t this work" tickets.'); ?>
                    <div class="kf-info-box" style="background:rgba(204,40,40,.06);border-color:rgba(204,40,40,.20);color:#7d1818;">
                        <strong style="color:#cc2828;">1. NEVER use <code>custom.css</code> in this WHMCS install.</strong><br>
                        All styles live inline in <code>.tpl</code> files inside <code>{literal}&lt;style&gt;…&lt;/style&gt;{/literal}</code> blocks, and the addon emits a small dynamic <code>&lt;style&gt;</code> block at runtime via the <code>ClientAreaHeadOutput</code> hook. A <code>custom.css</code> file causes persistent, hard-to-clear caching issues with WHMCS's asset pipeline. If you need a static tweak, edit the <code>.tpl</code> directly. For dynamic control, use this addon.
                    </div>
                    <div class="kf-info-box" style="background:rgba(217,119,6,.06);border-color:rgba(217,119,6,.20);color:#7d4308;">
                        <strong style="color:#b96a05;">2. Clear compiled templates after EVERY change.</strong><br>
                        <code>Configuration → System Settings → Cleanup → check "Compiled Templates" → Run.</code><br>
                        Then hard-refresh your browser (Ctrl/Cmd + Shift + R). WHMCS aggressively caches compiled <code>.tpl</code> files — if you upload new files and the page still looks old, this is 95% of the reason.
                    </div>
                    <div class="kf-info-box">
                        <strong>3. Theme preview URL is EXACTLY <code>/index.php?systpl=kwickflix</code>.</strong><br>
                        The <code>?systpl=</code> parameter only works on <code>/index.php</code> — not on arbitrary client-area URLs like <code>/cart.php?systpl=kwickflix</code>. If you want to test the cart without activating the template, you have to activate it first.
                    </div>
                <?php kfSectionClose(false); ?>

                <?php kfSectionOpen('help_lookup', 'Where Do I Find…?', 'Common tasks mapped to the tab + section where they live.'); ?>
                    <div class="kf-info-box">
                        <strong>Change the site's accent color</strong> → General tab → Master Accent Color. Drives buttons, links, focus rings, badges, and selected states sitewide.
                    </div>
                    <div class="kf-info-box">
                        <strong>Set my favicon</strong> → Header / Nav tab → Logos section, third row. Accepts <code>.ico</code>, <code>.png</code>, <code>.svg</code>, <code>.jpg</code>, <code>.gif</code>, <code>.webp</code> — MIME type auto-detected from the file extension.
                    </div>
                    <div class="kf-info-box">
                        <strong>Make my site look good when shared on Discord / Twitter / Facebook</strong> → General tab → SEO / Social Sharing. Fill in OG Title, OG Description, and an OG Image URL (1200×630 works on every platform). Emits both <code>og:*</code> and <code>twitter:*</code> meta tags automatically.
                    </div>
                    <div class="kf-info-box">
                        <strong>Show a promo banner at the top of every page</strong> → General tab → Sitewide Announcement Bar. Toggle on, set the message, pick colors, optionally make it dismissable. Renders above the navbar at z-index 1050. Dismissal is keyed to a hash of the message text, so changing the message auto-resets visitors who dismissed the old one.
                    </div>
                    <div class="kf-info-box">
                        <strong>Add Google Analytics / GTM / Meta pixel / chat widget</strong> → General tab → Custom Code Injection. Paste <code>&lt;script&gt;</code> blocks into Custom HEAD HTML (for analytics, schema markup) or Custom FOOTER HTML (for chat widgets, deferred analytics). Renders raw with no escaping — admin is trusted.
                    </div>
                    <div class="kf-info-box">
                        <strong>Backup / restore / migrate my settings</strong> → General tab → Settings Export / Import. Copy to clipboard, download as JSON, or paste a previously-exported blob back in to overwrite. Useful for staging → production migrations.
                    </div>
                    <div class="kf-info-box">
                        <strong>Add or reorder navbar links</strong> → Header / Nav tab → Primary Navbar (Row 1) or Secondary Navbar (Row 2). Drag the ⋮⋮ handle to reorder.
                    </div>
                    <div class="kf-info-box">
                        <strong>Set a whole-site background image or video</strong> → Header / Nav tab → Whole-Site Background. Use small (&lt;5MB) MP4 for video.
                    </div>
                    <div class="kf-info-box">
                        <strong>Edit hero title / stats / social bar</strong> → Homepage tab.
                    </div>
                    <div class="kf-info-box">
                        <strong>Add a logo marquee to the cart</strong> → Cart/Checkout tab → Cart/Checkout — Marquee.
                    </div>
                    <div class="kf-info-box">
                        <strong>Show a notice on the configure-product or checkout page</strong> → Cart/Checkout tab → Cart/Checkout — Notice Boxes. Three slots: CP (configure), CO Top (between credit balance + gateways), CO Bot (above ToS).
                    </div>
                    <div class="kf-info-box">
                        <strong>Reorder, restyle, or customize the payment gateways</strong> → Cart/Checkout tab → Cart/Checkout — Payment Gateways.
                    </div>
                    <div class="kf-info-box">
                        <strong>Hide the Recent News / Affiliate / Recent Tickets cards on the client dashboard</strong> → Client Area tab → WHMCS Panel Accents (each has a hide toggle).
                    </div>
                    <div class="kf-info-box">
                        <strong>Edit footer columns / links</strong> → Footer tab.
                    </div>
                <?php kfSectionClose(false); ?>

                <?php kfSectionOpen('help_payments', 'Payment Gateways — Quick Reference', 'How the per-row + section-level color pickers cascade, and how the preferred ribbon works.'); ?>
                    <div class="kf-info-box">
                        <strong>Cascade for the selected-card border + inner glow:</strong><br>
                        1. Is this card marked <strong>Preferred</strong>? → use the section-level <em>"Preferred" Border / Glow Color</em>.<br>
                        2. Else, does this row have its own <em>Border / Glow Color</em> set? → use that.<br>
                        3. Else → use the site's <em>Master Accent</em> color.<br>
                        The preferred treatment always wins so it stays visually distinct, even if the row also has a per-row color set.
                    </div>
                    <div class="kf-info-box">
                        <strong>The preferred gateway auto-selects on page load.</strong><br>
                        The first row marked Preferred (per drag order) becomes the default <code>checked</code> radio button when the customer reaches checkout. Customer can still pick anything else.
                    </div>
                    <div class="kf-info-box">
                        <strong>The icon field accepts three formats — auto-detected:</strong><br>
                        Emoji: <code>💳</code><br>
                        Path or URL: <code>/img/cards/visa.png</code> or <code>https://…/icon.svg</code> (rendered as <code>&lt;img&gt;</code>, 20×20)<br>
                        Raw HTML: <code>&lt;i class="fab fa-cc-visa"&gt;&lt;/i&gt;</code>
                    </div>
                    <div class="kf-info-box">
                        <strong>Empty state:</strong> if you configure zero gateway rows, or none of them match active WHMCS gateways from <code>Setup → Payments</code>, the cart shows a centered "No payment options are currently available — please contact support" notice. Configure at least one matching active gateway to avoid this.
                    </div>
                <?php kfSectionClose(false); ?>

                <?php kfSectionOpen('help_notices', 'Notice Boxes — Quick Reference', 'How the three cart notice slots render and what HTML is allowed in the body.'); ?>
                    <div class="kf-info-box">
                        <strong>Three slots, three locations:</strong><br>
                        <code>CP</code> → Configure-product step, above the Continue button.<br>
                        <code>CO Top</code> → Final checkout page, between credit-balance options and the payment gateway list.<br>
                        <code>CO Bot</code> → Final checkout page, just above the Terms of Service checkbox.
                    </div>
                    <div class="kf-info-box">
                        <strong>Rendering rules:</strong><br>
                        Title alone (no body) → title row centers, with icons if a FA icon is set.<br>
                        Body alone (no title) → just the body text centers, no icons render even if set.<br>
                        Both title and body → title row with icons flanking, body centered below.<br>
                        Both empty + enabled → nothing renders (no empty box).
                    </div>
                    <div class="kf-info-box">
                        <strong>HTML allowed in the body:</strong> <code>&lt;a&gt;</code>, <code>&lt;br&gt;</code>, <code>&lt;strong&gt;</code>, <code>&lt;em&gt;</code>, basic inline tags. Smarty interpolation is bypassed via <code>{$var|escape:'none' nofilter}</code> so links render properly. <code>javascript:</code> URLs in <code>href</code>/<code>onclick</code> are auto-sanitized to prevent chat widgets opening blank tabs.
                    </div>
                <?php kfSectionClose(false); ?>

                <?php kfSectionOpen('help_troubleshoot', 'Troubleshooting', 'Common issues and their fixes.'); ?>
                    <div class="kf-info-box">
                        <strong>I uploaded new files but the page hasn't changed.</strong><br>
                        Clear compiled templates (see Hard Rule #2) and hard-refresh the browser. This fixes 95% of "nothing changed" reports.
                    </div>
                    <div class="kf-info-box">
                        <strong>The page is completely unstyled — navbar shows as bulleted list.</strong><br>
                        Bootstrap CSS isn't loading. Check browser DevTools → Network tab for 404s on <code>bootstrap.min.css</code>. Verify all three folders (<code>kwickflix</code>, <code>kwick_cart</code>, <code>kwickflixstyle</code>) uploaded completely.
                    </div>
                    <div class="kf-info-box">
                        <strong>Dropdowns / modals are stuck visible on screen.</strong><br>
                        The addon emits a defensive <code>display:none</code> rule for <code>.dropdown-menu:not(.show)</code> and <code>.modal:not(.show)</code> on every page. If you see this anyway, the addon's <code>ClientAreaHeadOutput</code> hook isn't firing — check <code>Setup → System Logs → Activity Log</code> for hook errors.
                    </div>
                    <div class="kf-info-box">
                        <strong>My admin save doesn't seem to stick.</strong><br>
                        Check <code>Setup → System Logs → Activity Log</code> for errors. Also verify your admin role has access to this addon (<code>Setup → Administrator Roles → your role → Addon Modules → tick KwickFlix Style</code>).
                    </div>
                    <div class="kf-info-box">
                        <strong>The cart page looks ugly / unstyled.</strong><br>
                        Verify <code>Setup → General Settings → Ordering → Default Order Form Template</code> is set to <code>kwick_cart</code>. The bridge CSS at <code>templates/orderforms/kwick_cart/css/kwickflix.css</code> must exist.
                    </div>
                <?php kfSectionClose(false); ?>

                <?php kfSectionOpen('help_extending', 'Extending the Addon', 'Pointers for developers who want to add their own fields or sections.'); ?>
                    <div class="kf-info-box">
                        <strong>Adding a new setting:</strong>
                        <ol style="margin:8px 0 0 22px;padding:0;">
                            <li>Add the field to <code>kwickflixstyle.php</code> (model after an existing <code>kfSectionOpen()</code> block).</li>
                            <li>Add it to the save handler payload at the top of <code>kwickflixstyle_output()</code>.</li>
                            <li>Expose it as a Smarty variable in <code>hooks.php</code> (inside <code>$kfFrontendVars</code>).</li>
                            <li>Consume it in your <code>.tpl</code> as <code>{$kf_your_setting}</code>.</li>
                            <li>For HTML values, render with <code>{$kf_var|escape:'none' nofilter}</code> to bypass Smarty auto-escape.</li>
                        </ol>
                    </div>
                    <div class="kf-info-box">
                        <strong>Adding a drag-and-drop repeater list:</strong> follow the Payment Gateways pattern — write a <code>kfRenderXyzRow($idx, $row)</code> function, render the list + <code>&lt;template&gt;</code> + Add button in the admin section, then call <code>bindRepeater({...})</code> in the JS. Drag/drop, up/down, delete, and live-title-sync are all free — you just match the pattern.
                    </div>
                    <div class="kf-info-box">
                        <strong>Settings storage:</strong> single MySQL table <code>mod_kwickflixstyle_settings</code> (key/value). Complex values are JSON-encoded automatically. See <code>lib/Settings.php</code>.
                    </div>
                    <div class="kf-info-box">
                        <strong>The full README</strong> with file tree, install steps, cart deep-dive, and uninstall procedure ships at the top level of the package zip as <code>README.md</code>.
                    </div>
                <?php kfSectionClose(false); ?>
            </div>
        </form>
    </div>

    <script>
    (function(){
        var wrap = document.querySelector('.kf-admin-wrap');
        if (!wrap) return;
        var tabs   = wrap.querySelectorAll('.kf-tab');
        var panes  = wrap.querySelectorAll('.kf-pane');
        var hidden = wrap.querySelector('#kf_active_tab');
        var initial = '<?php echo htmlspecialchars($activeTab, ENT_QUOTES); ?>';

        function activate(name){
            tabs.forEach(function(t){
                if (t.getAttribute('data-tab') === name) t.classList.add('active');
                else t.classList.remove('active');
            });
            panes.forEach(function(p){
                if (p.getAttribute('data-pane') === name) p.classList.add('active');
                else p.classList.remove('active');
            });
            if (hidden) hidden.value = name;
        }

        tabs.forEach(function(t){
            t.addEventListener('click', function(e){
                e.preventDefault();
                activate(t.getAttribute('data-tab'));
            });
        });
        activate(initial);

        // ─── Hex twin injection (reusable, used by both initial page
        //     load AND each new row cloned by the Add button or
        //     duplicated by the ❐ action) ──────────────────────────────
        // For every <input type="color"> inside `scope`, render a text
        // input next to it that displays/accepts the hex value. The two
        // stay in sync — typing valid hex updates the picker, picking
        // updates the text. Saves clicks for admins who already know the
        // hex value they want. Idempotent — won't double-wrap a color
        // input that's already been processed.
        function injectHexTwins(scope) {
            scope.querySelectorAll('input[type="color"]').forEach(function (colorInput) {
                if (colorInput.parentNode && colorInput.parentNode.classList.contains('kf-color-combo')) return;

                var hex = document.createElement('input');
                hex.type        = 'text';
                hex.className   = 'kf-color-hex';
                hex.maxLength   = 7;
                hex.placeholder = '#RRGGBB';
                hex.value       = colorInput.value;
                hex.spellcheck  = false;
                hex.setAttribute('autocomplete', 'off');

                var combo = document.createElement('div');
                combo.className = 'kf-color-combo';

                colorInput.parentNode.insertBefore(combo, colorInput);
                combo.appendChild(colorInput);
                combo.appendChild(hex);

                colorInput.addEventListener('input', function () {
                    hex.value = colorInput.value;
                    hex.classList.remove('kf-color-hex-invalid');
                });
                hex.addEventListener('input', function () {
                    var v = hex.value.trim();
                    if (v && v[0] !== '#') { v = '#' + v; hex.value = v; }
                    if (/^#[0-9a-fA-F]{6}$/.test(v)) {
                        colorInput.value = v;
                        hex.classList.remove('kf-color-hex-invalid');
                    } else if (/^#[0-9a-fA-F]{3}$/.test(v)) {
                        var full = '#' + v[1]+v[1] + v[2]+v[2] + v[3]+v[3];
                        colorInput.value = full;
                        hex.classList.remove('kf-color-hex-invalid');
                    } else if (v !== '' && v !== '#') {
                        hex.classList.add('kf-color-hex-invalid');
                    } else {
                        hex.classList.remove('kf-color-hex-invalid');
                    }
                });
                hex.addEventListener('blur', function () {
                    if (hex.classList.contains('kf-color-hex-invalid')) {
                        hex.value = colorInput.value;
                        hex.classList.remove('kf-color-hex-invalid');
                    }
                });
            });
        }

        // ─── Generic repeater handler (used by cards + nav1) ──
        function bindRepeater(opts) {
            // opts: { listId, addBtnId, templateId, prefix }
            var list = wrap.querySelector(opts.listId);
            var addBtn = wrap.querySelector(opts.addBtnId);
            var template = wrap.querySelector(opts.templateId);
            if (!list) return;

            var nextIdx = list.querySelectorAll('.kf-card-row').length;
            var prefixRegex = new RegExp('^' + opts.prefix + '\\[[^\\]]+\\]');

            function renumber(){
                var rows = list.querySelectorAll('.kf-card-row');
                rows.forEach(function(row, i){
                    row.setAttribute('data-idx', i);
                    row.querySelectorAll('input,textarea,select').forEach(function(el){
                        var name = el.getAttribute('name');
                        if (!name) return;
                        el.setAttribute('name', name.replace(prefixRegex, opts.prefix + '[' + i + ']'));
                    });
                });
                nextIdx = rows.length;
            }

            function syncTitle(row){
                var titleInput = row.querySelector('input[data-sync-summary="1"]');
                var titleEl    = row.querySelector('.kf-card-row-title');
                if (!titleInput || !titleEl) return;
                var update = function(){
                    var v = titleInput.value.trim();
                    // preserve any sub-label (icon hint) span
                    var sub = titleEl.querySelector('span');
                    titleEl.textContent = v || (titleEl.getAttribute('data-bind-from') === 'label' ? 'New nav item' : 'Untitled card');
                    if (sub) titleEl.appendChild(sub);
                };
                titleInput.addEventListener('input', update);
                titleInput.addEventListener('change', update);
            }

            // Live update of the "Hidden" pill in a row's summary when the
            // admin toggles the Visible checkbox. Without this, the pill
            // only updates after a save+reload — checking/unchecking feels
            // disconnected from the visual feedback the admin sees.
            function syncVisibleBadge(row){
                var toggle = row.querySelector('input[type="checkbox"][data-kf-visible-toggle]');
                if (!toggle) return;
                var titleEl = row.querySelector('.kf-card-row-title');
                if (!titleEl) return;
                toggle.addEventListener('change', function(){
                    var existing = titleEl.querySelector('span[data-kf-hidden-badge]');
                    if (!toggle.checked && !existing) {
                        var badge = document.createElement('span');
                        badge.setAttribute('data-kf-hidden-badge', '1');
                        badge.style.cssText = 'background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;';
                        badge.textContent = 'Hidden';
                        titleEl.appendChild(badge);
                    } else if (toggle.checked && existing) {
                        existing.remove();
                    }
                });
            }

            // ─── Drag-and-drop reorder via the ⋮⋮ grip handle ────────
            // The grip enables draggability on mousedown and releases it
            // on mouseup, so input fields and buttons inside the row stay
            // interactive (clicks don't start a drag). Visual feedback:
            // .kf-dragging on the row being moved, .kf-drop-target on
            // whichever row the cursor is hovering over.
            function bindDragHandle(row) {
                var grip = row.querySelector('.kf-card-row-grip');
                if (!grip) return;
                grip.style.cursor = 'grab';
                grip.style.userSelect = 'none';

                grip.addEventListener('mousedown', function () {
                    row.setAttribute('draggable', 'true');
                    grip.style.cursor = 'grabbing';
                });
                // Release draggability on global mouseup (handles cases where
                // the user mousedowns on the grip but releases off the row)
                document.addEventListener('mouseup', function () {
                    if (row.getAttribute('draggable') === 'true') {
                        row.removeAttribute('draggable');
                        grip.style.cursor = 'grab';
                    }
                });

                row.addEventListener('dragstart', function (e) {
                    row.classList.add('kf-dragging');
                    e.dataTransfer.effectAllowed = 'move';
                    // Firefox requires setData to initiate the drag at all
                    e.dataTransfer.setData('text/plain', row.dataset.idx || '');
                });
                row.addEventListener('dragend', function () {
                    row.classList.remove('kf-dragging');
                    row.removeAttribute('draggable');
                    grip.style.cursor = 'grab';
                });
            }

            // ─── List-level drag-and-drop drop handlers ──────────────
            // Bound once per list (not per row). Each row inside calls
            // bindDragHandle in bindRow() to enable draggability when its
            // grip is grabbed. The list catches dragover/drop events
            // bubbling up from any row inside.
            if (!list._kfDragBound) {
                list._kfDragBound = true;

                // Helper: clear any existing drop indicators in the list
                var clearDropIndicators = function () {
                    list.querySelectorAll('.kf-drop-before, .kf-drop-after').forEach(function (r) {
                        r.classList.remove('kf-drop-before', 'kf-drop-after');
                    });
                };

                list.addEventListener('dragover', function (e) {
                    var dragging = list.querySelector('.kf-card-row.kf-dragging');
                    if (!dragging) return;
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'move';

                    var target = e.target.closest('.kf-card-row');
                    // Clear stale indicators on every move so only one row
                    // shows the drop line at a time.
                    clearDropIndicators();
                    if (!target || target === dragging) return;

                    // Decide before/after target based on cursor position
                    // relative to the row's vertical midpoint. Same logic
                    // the drop handler uses, so what you see is what you get.
                    var rect = target.getBoundingClientRect();
                    var afterMiddle = (e.clientY - rect.top) > (rect.height / 2);
                    target.classList.add(afterMiddle ? 'kf-drop-after' : 'kf-drop-before');
                });

                list.addEventListener('drop', function (e) {
                    var dragging = list.querySelector('.kf-card-row.kf-dragging');
                    if (!dragging) { clearDropIndicators(); return; }
                    e.preventDefault();
                    var target = e.target.closest('.kf-card-row');
                    clearDropIndicators();
                    if (!target || target === dragging) return;
                    var rect = target.getBoundingClientRect();
                    var afterMiddle = (e.clientY - rect.top) > (rect.height / 2);
                    if (afterMiddle) {
                        list.insertBefore(dragging, target.nextSibling);
                    } else {
                        list.insertBefore(dragging, target);
                    }
                    renumber();
                });

                // Drag canceled (Esc, dropped outside the list, etc.) —
                // dragend bubbles up to the list from the dragged row.
                list.addEventListener('dragend', function () {
                    clearDropIndicators();
                });
            }

            function bindRow(row){
                syncTitle(row);
                syncVisibleBadge(row);
                // Hex-twin text inputs for any color picker in this row —
                // needed because new rows cloned from the template don't
                // get processed by the initial-pass injectHexTwins(wrap).
                injectHexTwins(row);
                // Drag-and-drop handle on the grip (⋮⋮) of this row.
                bindDragHandle(row);
                row.querySelectorAll('[data-action]').forEach(function(btn){
                    btn.addEventListener('click', function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        var action = btn.getAttribute('data-action');
                        if (action === 'delete'){
                            if (confirm('Delete this entry?')){
                                row.remove();
                                renumber();
                            }
                        } else if (action === 'up'){
                            var prev = row.previousElementSibling;
                            if (prev) list.insertBefore(row, prev);
                            renumber();
                        } else if (action === 'down'){
                            var next = row.nextElementSibling;
                            if (next) list.insertBefore(next, row);
                            renumber();
                        } else if (action === 'duplicate'){
                            // cloneNode(true) copies the DOM as-is, but native form
                            // elements track their current value as a *property*, not
                            // an attribute — so a fresh clone would carry the original
                            // (stale) attribute values. Sync property → attribute on
                            // every input/textarea/select first so typed-in data is
                            // preserved in the duplicate.
                            row.querySelectorAll('input').forEach(function(el){
                                if (el.type === 'checkbox' || el.type === 'radio') {
                                    if (el.checked) el.setAttribute('checked', '');
                                    else el.removeAttribute('checked');
                                } else {
                                    el.setAttribute('value', el.value);
                                }
                            });
                            row.querySelectorAll('textarea').forEach(function(el){
                                el.textContent = el.value;
                            });
                            row.querySelectorAll('select').forEach(function(el){
                                Array.from(el.options).forEach(function(opt){
                                    if (opt.value === el.value) opt.setAttribute('selected', 'selected');
                                    else opt.removeAttribute('selected');
                                });
                            });
                            var clone = row.cloneNode(true);
                            // Insert immediately after the original so the duplicate
                            // appears right next to the source card.
                            row.parentNode.insertBefore(clone, row.nextSibling);
                            bindRow(clone);
                            renumber();
                            // Open the clone and focus its title for quick editing
                            clone.setAttribute('open', '');
                            var titleInput = clone.querySelector('input[data-sync-summary="1"]');
                            if (titleInput) { titleInput.focus(); titleInput.select(); }
                        }
                    });
                });
            }

            list.querySelectorAll('.kf-card-row').forEach(bindRow);

            if (addBtn && template){
                addBtn.addEventListener('click', function(e){
                    e.preventDefault();
                    var html = template.innerHTML.replace(/__INDEX__/g, nextIdx);
                    var holder = document.createElement('div');
                    holder.innerHTML = html.trim();
                    var newRow = holder.firstElementChild;
                    list.appendChild(newRow);
                    bindRow(newRow);
                    nextIdx++;
                    newRow.setAttribute('open', '');
                    var titleInput = newRow.querySelector('input[data-sync-summary="1"]');
                    if (titleInput) titleInput.focus();
                });
            }
        }

        // Bind all repeaters
        bindRepeater({ listId: '#kf-cards-list',   addBtnId: '#kf-add-card',    templateId: '#kf-card-template',    prefix: 'cards' });
        bindRepeater({ listId: '#kf-nav1-list',    addBtnId: '#kf-add-nav1',    templateId: '#kf-nav1-template',    prefix: 'nav1'  });
        bindRepeater({ listId: '#kf-nav2-list',    addBtnId: '#kf-add-nav2',    templateId: '#kf-nav2-template',    prefix: 'nav2'  });
        bindRepeater({ listId: '#kf-stats-list',   addBtnId: '#kf-add-stat',    templateId: '#kf-stat-template',    prefix: 'hero_stats'   });
        bindRepeater({ listId: '#kf-hero-social-list',  addBtnId: '#kf-add-hero-social',  templateId: '#kf-hero-social-template',  prefix: 'hero_social'  });
        bindRepeater({ listId: '#kf-marquee-list', addBtnId: '#kf-add-marquee', templateId: '#kf-marquee-template', prefix: 'hero_marquee' });
        bindRepeater({ listId: '#kf-checkout-marquee-list', addBtnId: '#kf-add-checkout-marquee', templateId: '#kf-checkout-marquee-template', prefix: 'checkout_marquee' });
        bindRepeater({ listId: '#kf-reviews-list', addBtnId: '#kf-add-review',  templateId: '#kf-review-template',  prefix: 'reviews' });
        bindRepeater({ listId: '#kf-social-list',  addBtnId: '#kf-add-social',  templateId: '#kf-social-template',  prefix: 'social' });
        bindRepeater({ listId: '#kf-stat-tiles-list', addBtnId: '#kf-add-stat-tile', templateId: '#kf-stat-tile-template', prefix: 'stat_tiles' });
        bindRepeater({ listId: '#kf-info-cards-list', addBtnId: '#kf-add-info-card', templateId: '#kf-info-card-template', prefix: 'info_cards' });
        bindRepeater({ listId: '#kf-payment-gateways-list', addBtnId: '#kf-add-payment-gateway', templateId: '#kf-payment-gateway-template', prefix: 'payment_gateways' });

        // ─── Settings Export (Copy + Download) ───────────────
        // The textarea #kf-export-json is pre-filled server-side with a
        // JSON_PRETTY_PRINT snapshot of every saved setting. These two
        // buttons let admins grab it via clipboard or as a .json file.
        var exportTa  = document.getElementById('kf-export-json');
        var copyBtn   = document.getElementById('kf-export-copy');
        var dlBtn     = document.getElementById('kf-export-download');
        if (exportTa && copyBtn) {
            copyBtn.addEventListener('click', function () {
                exportTa.select();
                exportTa.setSelectionRange(0, exportTa.value.length);
                var ok = false;
                try { ok = document.execCommand('copy'); } catch (e) {}
                // Modern clipboard API as fallback (works on most browsers)
                if (!ok && navigator.clipboard) {
                    navigator.clipboard.writeText(exportTa.value).then(function(){
                        copyBtn.textContent = '✓ Copied';
                        setTimeout(function(){ copyBtn.textContent = '📋 Copy to clipboard'; }, 1500);
                    });
                    return;
                }
                copyBtn.textContent = ok ? '✓ Copied' : '⚠ Press Ctrl/Cmd+C';
                setTimeout(function(){ copyBtn.textContent = '📋 Copy to clipboard'; }, 1500);
            });
        }
        if (exportTa && dlBtn) {
            dlBtn.addEventListener('click', function () {
                var blob = new Blob([exportTa.value], { type: 'application/json;charset=utf-8' });
                var stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
                var name = 'kwickflixstyle-settings-' + stamp + '.json';
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = name;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(function(){ URL.revokeObjectURL(a.href); }, 1500);
            });
        }

        // Three footer column repeaters. The Add buttons here use data-attr
        // selectors rather than ids so we can iterate by column number.
        [1, 2, 3].forEach(function (colNum) {
            bindRepeater({
                listId:     '#kf-footer-col' + colNum + '-list',
                addBtnId:   '[data-kf-add-footer-link="' + colNum + '"]',
                templateId: '#kf-footer-col' + colNum + '-template',
                prefix:     'footer_col' + colNum + '_items',
            });
        });

        // ─── Collapsible section state persistence ────
        // localStorage key per section: kf_sec_<id> = '1' (open) | '0' (closed)
        // Sections render CLOSED by default. Restore opens from localStorage.
        var sections = wrap.querySelectorAll('.kf-section[data-section]');
        sections.forEach(function (sec) {
            var id = sec.getAttribute('data-section');
            try {
                var saved = localStorage.getItem('kf_sec_' + id);
                if (saved === '1') sec.setAttribute('open', '');
                // saved === '0' or null → leave closed (default)
            } catch (e) { /* localStorage may be blocked */ }

            sec.addEventListener('toggle', function () {
                try {
                    localStorage.setItem('kf_sec_' + id, sec.open ? '1' : '0');
                } catch (e) {}
            });
        });

        // ─── Color picker hex-twin auto-injection — initial pass ─────
        // injectHexTwins is also called from bindRow() so newly added or
        // duplicated rows get their hex twins immediately (without this,
        // the hex text input only appeared after a save+reload).
        injectHexTwins(wrap);

        // After a save (banner present), scroll the wrap into view so the
        // user can see the success confirmation without losing context.
        if (wrap.querySelector('.kf-banner')) {
            try { wrap.scrollIntoView({behavior:'smooth', block:'start'}); } catch(e){}
        }
    })();
    </script>
    <?php
    echo ob_get_clean();
}

/**
 * Validate hex color string. Returns the value if valid, else empty.
 */
function kfStyleHexOrEmpty($v)
{
    $v = trim((string) $v);
    if ($v === '') return '';
    if (preg_match('/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', $v)) return $v;
    return '';
}

/**
 * Decode any HTML entities the form posted back, then trim. Used on every
 * user-typed text field that gets re-rendered into an HTML attribute on
 * the next page load.
 *
 * Why this exists: when an input's value contains `&`, we escape it to
 * `&amp;` on render so the HTML attribute is valid. The browser decodes
 * one level of entities when parsing the attribute, so the input's
 * .value property is back to `&`. BUT — in some WHMCS / browser / proxy
 * configurations, that decoding doesn't happen consistently, and the
 * literal string `&amp;` ends up in $_POST on submission. With each
 * save it grows: `&amp;` → `&amp;amp;` → `&amp;amp;amp;` …
 *
 * Decoding before storing breaks the loop: whatever shape the entity
 * arrives in, we store the human-readable character. The render still
 * escapes once for HTML output, so XSS protection is preserved.
 */
function kfStyleCleanText($v)
{
    if (!is_string($v)) return '';
    // Loop the decode — html_entity_decode strips ONE level of entities per
    // call. If the value has accumulated `&amp;amp;amp;` over many saves,
    // a single call gives us `&amp;amp;`. Keep decoding until the result
    // stops changing, so one save fully unwinds the accumulation. Cap at
    // 8 iterations as a safety brake against any pathological input.
    $prev = null;
    $iter = 0;
    while ($prev !== $v && $iter < 8) {
        $prev = $v;
        $v = html_entity_decode($v, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $iter++;
    }
    return trim($v);
}

/**
 * Validate marquee speed multiplier. Allowed values span 0.5× to 10×.
 * Anything else → '1' (default).
 */
function kfStyleMarqueeSpeed($v)
{
    $v = trim((string) $v);
    $allowed = ['0.5', '0.75', '1', '1.5', '2', '2.5', '3', '4', '5', '7', '10'];
    return in_array($v, $allowed, true) ? $v : '1';
}

/**
 * Return the active payment gateways in this WHMCS install, keyed by
 * system name with the friendly display name as the value. Used to
 * populate the gateway-select dropdown in the addon's Payment Gateways
 * editor (Cart/Checkout tab).
 *
 * Source: tblpaymentgateways. WHMCS stores each gateway's settings as
 * rows of (gateway, setting, value). The "name" setting holds the
 * friendly name; the "visible" setting controls whether clients see it.
 * We pull all gateways and treat ones without an explicit visible='off'
 * row as active (matches stock cart's filtering).
 *
 * Returns ['' => '— select gateway —'] prepended so the dropdown has
 * a valid placeholder option.
 */
function kfGetActivePaymentGateways()
{
    $out = ['' => '— select gateway —'];
    try {
        if (!class_exists('WHMCS\\Database\\Capsule')) return $out;
        $rows = \WHMCS\Database\Capsule::table('tblpaymentgateways')
            ->whereIn('setting', ['name', 'visible'])
            ->get(['gateway', 'setting', 'value']);
        $byGateway = [];
        foreach ($rows as $r) {
            $sys = (string) ($r->gateway ?? '');
            if ($sys === '') continue;
            if (!isset($byGateway[$sys])) $byGateway[$sys] = ['name' => $sys, 'visible' => true];
            if ($r->setting === 'name')    $byGateway[$sys]['name']    = (string) $r->value;
            if ($r->setting === 'visible') $byGateway[$sys]['visible'] = ((string) $r->value) !== 'off';
        }
        foreach ($byGateway as $sys => $g) {
            if (!$g['visible']) continue;
            $out[$sys] = $g['name'];
        }
        asort($out);
        // Re-prepend the placeholder so it stays at the top after sort
        unset($out['']);
        $out = ['' => '— select gateway —'] + $out;
    } catch (\Throwable $e) {
        // Silent fallback — if the DB query fails for any reason the
        // dropdown is still functional (admin can type the sysname
        // manually as a free-text fallback). Errors here shouldn't
        // crash the addon UI.
    }
    return $out;
}

/**
 * Whitelist cart-notice severity to the four Bootstrap-style alert kinds.
 * Maps to color tokens in the bridge stylesheet (.kf-cart-notice-success
 * / -info / -warning / -danger). Anything else falls back to 'warning'.
 */
function kfStyleNoticeSeverity($v)
{
    $v = strtolower(trim((string) $v));
    $allowed = ['success', 'info', 'warning', 'danger'];
    return in_array($v, $allowed, true) ? $v : 'warning';
}

/**
 * Render one cart-notice sub-dropdown. Mirrors the nav1 / hero_marquee
 * editor pattern: a <details class="kf-card-row"> that the admin can
 * expand/collapse inside the outer Cart/Checkout — Notices section.
 *
 * Unlike nav1/marquee these aren't reorderable rows (each notice has a
 * fixed position in the cart flow), so the row header has no grip /
 * up / down / delete buttons — just the title, a small location hint,
 * and a "Hidden" badge when the notice is toggled off.
 *
 * @param string $slug Form-field name prefix without the cart_notice_
 *                     part — e.g. 'cp', 'co_top', 'co_bot'. Full names
 *                     resolve to cart_notice_{slug}_enabled etc.
 * @param array  $n    Hydrated notice config:
 *                     {title, location, enabled, severity, icon, html}
 */
function kfRenderNoticeEditor($slug, array $n)
{
    $h     = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $name  = 'cart_notice_' . $slug;
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($slug); ?>">
        <summary class="kf-card-row-header">
            <span class="kf-card-row-title">
                <?php echo $h($n['title_field']); ?>
                <span style="color:#7a7268;font-weight:500;font-size:12px;margin-left:6px;">— <?php echo $h($n['location']); ?></span>
                <?php if (!$n['enabled']): ?>
                    <span style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label class="kf-toggle">
                        <input type="checkbox" name="<?php echo $h($name); ?>_enabled" value="1" <?php echo $n['enabled'] ? 'checked' : ''; ?>>
                        Show this notice
                    </label>
                    <p class="kf-help">Uncheck to remove the notice entirely from its page.</p>
                </div>
                <div class="kf-field" style="flex:0 0 180px;">
                    <label for="<?php echo $h($name); ?>_severity">Severity / Color</label>
                    <select id="<?php echo $h($name); ?>_severity" name="<?php echo $h($name); ?>_severity">
                        <option value="info"    <?php echo $n['severity'] === 'info'    ? 'selected' : ''; ?>>Info (blue)</option>
                        <option value="success" <?php echo $n['severity'] === 'success' ? 'selected' : ''; ?>>Success (accent)</option>
                        <option value="warning" <?php echo $n['severity'] === 'warning' ? 'selected' : ''; ?>>Warning (amber)</option>
                        <option value="danger"  <?php echo $n['severity'] === 'danger'  ? 'selected' : ''; ?>>Danger (red)</option>
                    </select>
                    <p class="kf-help">Background, border, and text color.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label for="<?php echo $h($name); ?>_title">Title <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" id="<?php echo $h($name); ?>_title" name="<?php echo $h($name); ?>_title" value="<?php echo $h($n['title_content']); ?>" placeholder="e.g. Important Notice">
                    <p class="kf-help">A bold centered heading rendered above the body. <strong>Icons only render when a title is set</strong>, flanking it on either side. Leave blank for a body-only notice with no icon.</p>
                </div>
                <div class="kf-field" style="flex:0 0 220px;">
                    <label for="<?php echo $h($name); ?>_icon">Title Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" id="<?php echo $h($name); ?>_icon" name="<?php echo $h($name); ?>_icon" value="<?php echo $h($n['icon']); ?>" placeholder="fas fa-exclamation-triangle">
                    <p class="kf-help">Font Awesome class. Renders on both sides of the title text. Ignored when title is empty.</p>
                </div>
            </div>

            <div class="kf-field" style="margin-top:8px;">
                <label for="<?php echo $h($name); ?>_html">Body <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— HTML allowed, centered</span></label>
                <textarea id="<?php echo $h($name); ?>_html" name="<?php echo $h($name); ?>_html" rows="3" style="width:100%;font-family:'SFMono-Regular',Consolas,monospace;font-size:13px;"><?php echo $h($n['html']); ?></textarea>
                <p class="kf-help">Plain text or HTML. <code>&lt;a&gt;</code>, <code>&lt;br&gt;</code>, <code>&lt;strong&gt;</code> etc all work. <code>javascript:</code> URLs in <code>onclick</code>/<code>href</code> are auto-sanitized (trailing <code>return false</code> → <code>void 0</code>).</p>
            </div>
        </div>
    </details>
    <?php
}

/**
 * Normalize an admin-entered list of product IDs (info card gating).
 *
 * Accepts loose input — '3,5,87,6' / '3 5 87 6' / '3, 5, 87, 6 ' — strips
 * everything except digits and commas, drops empties, dedupes, joins as a
 * canonical 'a,b,c' string. The hook can then `explode(',', $list)` without
 * needing to re-parse on every page load.
 */
function kfStyleNormalizeProductIds($v)
{
    $v = trim((string) $v);
    if ($v === '') return '';
    // Split on anything that isn't a digit, then keep numeric tokens only.
    $tokens = preg_split('/[^0-9]+/', $v, -1, PREG_SPLIT_NO_EMPTY);
    if (empty($tokens)) return '';
    // Dedupe while preserving order — admin's first occurrence wins.
    $tokens = array_values(array_unique(array_map('intval', $tokens)));
    // Drop zero / negative IDs (no such product in WHMCS).
    $tokens = array_filter($tokens, function ($n) { return $n > 0; });
    return implode(',', $tokens);
}

/**
 * Parse the per-link footer column POST array into a clean settings array.
 *
 * Drops rows whose label OR url is empty (they're not useful as a footer
 * link). Preserves order. Normalizes target to either '' or '_blank'.
 *
 * @param mixed $rawItems Whatever was in $_POST['footer_colN_items'] —
 *                        usually an array of associative arrays, but
 *                        defensively handle string/null.
 * @return array Clean list of {label, url, icon, target, enabled}
 */
function kfStyleParseFooterItems($rawItems)
{
    if (!is_array($rawItems)) return [];
    $out = [];
    foreach ($rawItems as $row) {
        if (!is_array($row)) continue;
        $label = kfStyleCleanText((string) ($row['label'] ?? ''));
        $url   = kfStyleCleanText((string) ($row['url']   ?? ''));
        // Only persist rows that have BOTH a label and a URL — empty rows
        // are typically the cloned template that the admin never filled in.
        if ($label === '' || $url === '') continue;
        $target = ($row['target'] ?? '') === '_blank' ? '_blank' : '';
        $out[] = [
            'label'   => $label,
            'url'     => $url,
            'target'  => $target,
            // Default to enabled when the key is missing; '0' is explicit disable.
            'enabled' => (!empty($row['enabled'])) ? '1' : '0',
        ];
    }
    return $out;
}

/**
 * Open a collapsible section box. Pair with kfSectionClose().
 *
 * Renders <details> + summary header + body wrapper. Content is appended
 * by subsequent echoes. Per-section save button is added by kfSectionClose.
 *
 * Sections render CLOSED by default. JS restores any open-state the admin
 * previously set via localStorage (kf_sec_<id> = '1' opens, '0' or null
 * leaves closed).
 *
 * @param string $id   Stable id for state persistence (snake_case).
 * @param string $title Section heading shown in the summary.
 * @param string $desc  Optional description below the heading.
 */
function kfSectionOpen($id, $title, $desc = '')
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    echo '<details class="kf-section" data-section="' . $h($id) . '">';
    echo   '<summary class="kf-section-head">';
    echo     '<span class="kf-section-chev">▾</span>';
    echo     '<h3>' . $h($title) . '</h3>';
    echo   '</summary>';
    echo   '<div class="kf-section-body">';
    if ($desc !== '') {
        echo '<p class="kf-section-desc">' . $h($desc) . '</p>';
    }
}

/**
 * Close a collapsible section. Optionally appends a per-section save button.
 *
 * The save button submits the same outer form (one form for all settings),
 * so clicking it commits ALL pending changes across sections, not just this
 * one. The per-section button is purely an ergonomic affordance — keeps
 * the action close to where the admin is editing.
 *
 * @param bool $showSaveButton Default true. Set false for read-only sections (Help).
 */
function kfSectionClose($showSaveButton = true)
{
    if ($showSaveButton) {
        echo '<div class="kf-section-foot">';
        echo   '<button type="submit" name="kf_save" value="1" class="kf-btn kf-btn-primary">Save Changes</button>';
        echo '</div>';
    }
    echo   '</div>'; // .kf-section-body
    echo '</details>';
}

/**
 * Render one Client Area Stat Tile editor row.
 *
 * Each tile produces a card in the row at the top of clientareahome.tpl.
 * The `stat` value drives which $clientsstats field appears in the big
 * number — validated against a fixed whitelist on save so admins can't
 * inject unsupported Smarty variable references.
 */
function kfRenderStatTileRow($idx, array $t)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $isVisible  = !array_key_exists('visible', $t) || $t['visible'] !== '0';
    $title      = $t['title'] ?? '';
    $stat       = $t['stat']  ?? 'dashes';

    $statOptions = [
        'services'   => 'Active Services count',
        'domains'    => 'Active Domains count',
        'invoices'   => 'Unpaid Invoices count',
        'tickets'    => 'Active Tickets count',
        'affiliates' => 'Affiliate Signups count',
        'quotes'     => 'Quotes count',
        'credit'     => 'Credit Balance (formatted currency)',
        'dashes'     => 'No stat — show "--" (for Live Chat, etc.)',
    ];

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($title === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="title"><?php echo $h($title !== '' ? $title : 'New stat tile'); ?>
                <?php if (!$isVisible): ?>
                    <span style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Tile Title <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="stat_tiles[<?php echo $h($idx); ?>][title]" value="<?php echo $h($title); ?>" placeholder="e.g. Services, Invoices, Live Chat" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>Font Awesome Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="stat_tiles[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($t['icon'] ?? ''); ?>" placeholder="e.g. fas fa-cube, fas fa-headset">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Subtext <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="stat_tiles[<?php echo $h($idx); ?>][subtext]" value="<?php echo $h($t['subtext'] ?? ''); ?>" placeholder="e.g. Click to manage, Open live chat, Add funds">
                    <p class="kf-help">Optional one-line note shown directly under the tile title at a smaller size. Title size doesn't change — this just adds a short hint below it.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 240px;">
                    <label>Accent Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— the bottom bar</span></label>
                    <input type="color" name="stat_tiles[<?php echo $h($idx); ?>][color]" value="<?php echo $h(!empty($t['color']) ? $t['color'] : '#1a6fff'); ?>">
                </div>
                <div class="kf-field">
                    <label>Stat Source</label>
                    <select name="stat_tiles[<?php echo $h($idx); ?>][stat]">
                        <?php foreach ($statOptions as $val => $label): ?>
                            <option value="<?php echo $h($val); ?>" <?php echo $stat === $val ? 'selected' : ''; ?>><?php echo $h($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="kf-help">Determines what number shows above the title. Pulled live from WHMCS's client stats.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Click URL</label>
                    <input type="text" name="stat_tiles[<?php echo $h($idx); ?>][url]" value="<?php echo $h($t['url'] ?? '#')   ; ?>" placeholder="clientarea.php?action=services">
                    <p class="kf-help">Relative path, absolute URL, or <code>javascript:</code> action. For a live chat button: <code>javascript:$crisp.push(['do','chat:open']);void 0;</code> &nbsp;<span style="color:#7a7268;">(use <code>void 0;</code> at the end, not <code>return false;</code> — <code>return</code> isn't valid outside a function and breaks the link silently)</span></p>
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>&nbsp;</label>
                    <label class="kf-toggle" style="margin-top:8px;">
                        <input type="checkbox" name="stat_tiles[<?php echo $h($idx); ?>][visible]" value="1" <?php echo $isVisible ? 'checked' : ''; ?>>
                        Visible on home
                    </label>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Client Area Custom Info Card editor row.
 *
 * Each card appears under the stat tiles row, before WHMCS's built-in
 * panels (Active Products, Recent News, etc.). Layout: card header with
 * icon + title, body with description and a single CTA button.
 */
function kfRenderInfoCardRow($idx, array $c)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $isVisible  = !array_key_exists('visible', $c) || $c['visible'] !== '0';
    $title      = $c['title'] ?? '';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($title === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="title"><?php echo $h($title !== '' ? $title : 'New info card'); ?>
                <?php if (!$isVisible): ?>
                    <span style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"        title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down"      title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn" data-action="duplicate" title="Duplicate this card">❐</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Card Title <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="info_cards[<?php echo $h($idx); ?>][title]" value="<?php echo $h($title); ?>" placeholder="Card title shown in the header bar" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>Font Awesome Icon</label>
                    <input type="text" name="info_cards[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($c['icon'] ?? ''); ?>" placeholder="e.g. fas fa-box-open, fas fa-book">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Description Text</label>
                    <textarea name="info_cards[<?php echo $h($idx); ?>][description]" style="min-height:54px;font-family:inherit;font-size:13px;" placeholder="One-line description shown in the card body."><?php echo $h($c['description'] ?? ''); ?></textarea>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Button Text</label>
                    <input type="text" name="info_cards[<?php echo $h($idx); ?>][btn_text]" value="<?php echo $h($c['btn_text'] ?? ''); ?>" placeholder="Button label text">
                </div>
                <div class="kf-field">
                    <label>Button URL</label>
                    <input type="text" name="info_cards[<?php echo $h($idx); ?>][btn_url]" value="<?php echo $h($c['btn_url'] ?? ''); ?>" placeholder="clientarea.php?action=... or /index.php?m=...">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 240px;">
                    <label>Accent Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— top border</span></label>
                    <input type="color" name="info_cards[<?php echo $h($idx); ?>][color]" value="<?php echo $h(!empty($c['color']) ? $c['color'] : '#1a6fff'); ?>">
                </div>
                <div class="kf-field" style="flex:1;">
                    <label>&nbsp;</label>
                    <label class="kf-toggle" style="margin-top:8px;">
                        <input type="checkbox" name="info_cards[<?php echo $h($idx); ?>][visible]" value="1" <?php echo $isVisible ? 'checked' : ''; ?>>
                        Visible on home
                    </label>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Visible to product IDs <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional, comma-separated</span></label>
                    <input type="text" name="info_cards[<?php echo $h($idx); ?>][product_ids]" value="<?php echo $h($c['product_ids'] ?? ''); ?>" placeholder="3, 5, 87, 6">
                    <p class="kf-help" style="margin-top:4px;">When set, only clients with at least one <strong>Active</strong> service from these product IDs see this card (suspended, cancelled, or terminated services don't qualify). Find product IDs under <em>Setup → Products/Services → Products/Services</em>. Leave blank to show to everyone.</p>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Member Review editor row.
 */
function kfRenderReviewRow($idx, array $r)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $stars = isset($r['stars']) ? max(1, min(5, (int) $r['stars'])) : 5;
    $author = $r['author'] ?? '';
    $text   = $r['text']   ?? '';
    $titleDisplay = $author !== '' ? str_repeat('★', $stars) . ' — ' . $author : 'New review';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($author === '' && $text === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="author"><?php echo $h($titleDisplay); ?></span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>
        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 140px;">
                    <label>Stars</label>
                    <select name="reviews[<?php echo $h($idx); ?>][stars]">
                        <?php for ($n = 5; $n >= 1; $n--): ?>
                            <option value="<?php echo $n; ?>" <?php echo $stars === $n ? 'selected' : ''; ?>><?php echo str_repeat('★', $n) . str_repeat('☆', 5 - $n); ?> (<?php echo $n; ?>)</option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="kf-field">
                    <label>Author <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="reviews[<?php echo $h($idx); ?>][author]" value="<?php echo $h($author); ?>" placeholder="Username or display name" data-sync-summary="1">
                </div>
            </div>
            <div class="kf-row">
                <div class="kf-field">
                    <label>Review Text <span style="color:#cc2828;">*</span></label>
                    <textarea name="reviews[<?php echo $h($idx); ?>][text]" style="min-height:64px;font-family:inherit;font-size:13px;" placeholder="The review quote..."><?php echo $h($text); ?></textarea>
                </div>
                <div class="kf-field">
                    <label>Optional Link <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— if you have proof of review</span></label>
                    <input type="text" name="reviews[<?php echo $h($idx); ?>][link]" value="<?php echo $h($r['link'] ?? ''); ?>" placeholder="https://reddit.com/r/example/...">
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Social Button editor row.
 */
function kfRenderSocialBtnRow($idx, array $b)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $titleDisplay = !empty($b['label']) ? $b['label'] : 'New button';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (empty($b['label']) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="label"><?php echo $h($titleDisplay); ?>
                <?php if (!empty($b['icon'])): ?>
                    <span style="color:#7a7268;font-weight:500;font-size:12px;margin-left:6px;"><?php echo $h($b['icon']); ?></span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>
        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Button Label <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="social[<?php echo $h($idx); ?>][label]" value="<?php echo $h($b['label'] ?? ''); ?>" placeholder="e.g. Join the Discord" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>URL <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="social[<?php echo $h($idx); ?>][url]" value="<?php echo $h($b['url'] ?? ''); ?>" placeholder="https://discord.gg/example">
                </div>
            </div>
            <div class="kf-row">
                <div class="kf-field">
                    <label>Font Awesome Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="social[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($b['icon'] ?? ''); ?>" placeholder="e.g. fab fa-discord, fab fa-telegram, fas fa-comments">
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Brand Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— icon + border</span></label>
                    <input type="color" name="social[<?php echo $h($idx); ?>][color]" value="<?php echo $h(!empty($b['color']) ? $b['color'] : '#5561EA'); ?>">
                </div>
                <div class="kf-field" style="flex:0 0 160px;">
                    <label>Open in New Tab</label>
                    <select name="social[<?php echo $h($idx); ?>][target]">
                        <option value=""        <?php echo empty($b['target']) ? 'selected' : ''; ?>>Same tab</option>
                        <option value="_blank"  <?php echo (($b['target'] ?? '') === '_blank') ? 'selected' : ''; ?>>New tab</option>
                    </select>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Hero Stat row (number + highlight + label).
 */
function kfRenderStatRow($idx, array $stat)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $titleDisplay = !empty($stat['number']) ? ($stat['number'] . ($stat['highlight'] ?? '') . ' — ' . ($stat['label'] ?? '')) : 'New stat';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (empty($stat['number']) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="number"><?php echo $h($titleDisplay); ?></span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>
        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 160px;">
                    <label>Number</label>
                    <input type="text" name="hero_stats[<?php echo $h($idx); ?>][number]" value="<?php echo $h($stat['number'] ?? ''); ?>" placeholder="e.g. 100, 24, 5" data-sync-summary="1">
                </div>
                <div class="kf-field" style="flex:0 0 160px;">
                    <label>Highlight <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— accent suffix</span></label>
                    <input type="text" name="hero_stats[<?php echo $h($idx); ?>][highlight]" value="<?php echo $h($stat['highlight'] ?? ''); ?>" placeholder="e.g. K+, /7, ★">
                </div>
                <div class="kf-field">
                    <label>Label</label>
                    <input type="text" name="hero_stats[<?php echo $h($idx); ?>][label]" value="<?php echo $h($stat['label'] ?? ''); ?>" placeholder="e.g. Customers, Support, Rating">
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Hero Social Bar tile editor row.
 *
 * Each tile has an image OR Font Awesome icon (image wins if both set),
 * a label, and a link URL. All social bar links always open in a new
 * tab — there's no per-item target option, by design (this bar is
 * for off-site destinations: Discord, status pages, socials, etc).
 */
function kfRenderSocialRow($idx, array $soc)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $label = $soc['label'] ?? '';
    $titleDisplay = $label !== '' ? $label : 'New social tile';
    // Default-on: missing key means visible (matches stat_tiles / info_cards).
    $isVisible = !isset($soc['visible']) || $soc['visible'] !== '0';
    $iconColor = $soc['icon_color'] ?? '';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($label === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="label"><?php echo $h($titleDisplay); ?>
                <?php if (!$isVisible): ?>
                    <span style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>
        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Label <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="hero_social[<?php echo $h($idx); ?>][label]" value="<?php echo $h($label); ?>" placeholder="e.g. Discord, Status, Reviews" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>Link URL <span style="color:#cc2828;">*</span></label>
                    <input type="url" name="hero_social[<?php echo $h($idx); ?>][url]" value="<?php echo $h($soc['url'] ?? ''); ?>" placeholder="https://discord.gg/yourserver">
                    <p class="kf-help">Normal links (http / https) open in a new tab. <code>javascript:</code> / <code>mailto:</code> / <code>tel:</code> / page anchors stay in the current tab so chat widgets and similar in-page actions work properly.</p>
                </div>
            </div>
            <div class="kf-row">
                <div class="kf-field">
                    <label>Image URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="hero_social[<?php echo $h($idx); ?>][image]" value="<?php echo $h($soc['image'] ?? ''); ?>" placeholder="/templates/kwickflix/img/social/discord.svg">
                    <p class="kf-help">If set, this image is shown instead of the Font Awesome icon below. Square SVG / PNG works best (~24-32px display size).</p>
                </div>
                <div class="kf-field">
                    <label>Font Awesome Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— fallback</span></label>
                    <input type="text" name="hero_social[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($soc['icon'] ?? ''); ?>" placeholder="e.g. fab fa-discord, fas fa-chart-line">
                    <p class="kf-help">Used when no image is set. Browse icons at fontawesome.com/icons.</p>
                </div>
            </div>
            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Icon Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="color" name="hero_social[<?php echo $h($idx); ?>][icon_color]" value="<?php echo $h($iconColor !== '' ? $iconColor : '#22a04a'); ?>">
                    <p class="kf-help">Overrides the Font Awesome icon color for this tile. Leave at the default (or clear via "Reset" in your browser's color picker) to inherit the master accent color. No effect when an Image URL is set.</p>
                </div>
                <div class="kf-field">
                    <label>&nbsp;</label>
                    <label class="kf-toggle" style="margin-top:8px;">
                        <input type="checkbox" name="hero_social[<?php echo $h($idx); ?>][visible]" value="1" <?php echo $isVisible ? 'checked' : ''; ?>>
                        Visible on homepage
                    </label>
                    <p class="kf-help">Uncheck to hide the tile without deleting it.</p>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Marquee logo row (image URL + alt).
 *
 * @param int|string $idx
 * @param array      $item   {url, alt}
 * @param string     $prefix Field name prefix — 'hero_marquee' (default) or
 *                           'checkout_marquee'. Both use the same row shape
 *                           and bindRepeater plumbing; only the form-field
 *                           name namespace differs.
 */
function kfRenderMarqueeRow($idx, array $item, $prefix = 'hero_marquee')
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $titleDisplay = !empty($item['alt']) ? $item['alt'] : (!empty($item['url']) ? basename($item['url']) : 'New logo');

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (empty($item['url']) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="alt"><?php echo $h($titleDisplay); ?></span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>
        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Image URL <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="<?php echo $h($prefix); ?>[<?php echo $h($idx); ?>][url]" value="<?php echo $h($item['url'] ?? ''); ?>" placeholder="/templates/kwickflix/img/marquee/logo.svg">
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Alt Text</label>
                    <input type="text" name="<?php echo $h($prefix); ?>[<?php echo $h($idx); ?>][alt]" value="<?php echo $h($item['alt'] ?? ''); ?>" placeholder="e.g. Brand Name" data-sync-summary="1">
                </div>
            </div>
            <p class="kf-help" style="margin:6px 0 0;">Upload logos to <code>/templates/kwickflix/img/marquee/</code> and reference as <code>/templates/kwickflix/img/marquee/filename.svg</code>, or paste any full external URL. SVG or PNG with transparent background works best.</p>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Second Navbar (Row 2) editor row.
 *
 * @param int|string $idx
 * @param array      $item   {title, url, icon, icon_color, glow_color, target}
 * @return string HTML
 */
function kfRenderNav2Row($idx, array $item)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $titleDisplay = !empty($item['title']) ? $item['title'] : 'New nav item';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (empty($item['title']) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="title"><?php echo $h($titleDisplay); ?>
                <?php if (!empty($item['icon'])): ?>
                    <span style="color:#7a7268;font-weight:500;font-size:12px;margin-left:6px;"><?php echo $h($item['icon']); ?></span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Menu Label <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="nav2[<?php echo $h($idx); ?>][title]" value="<?php echo $h($item['title'] ?? ''); ?>" placeholder="Button label" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>URL <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="nav2[<?php echo $h($idx); ?>][url]" value="<?php echo $h($item['url'] ?? ''); ?>" placeholder="/your-page.php  or  https://example.com">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Font Awesome Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="nav2[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($item['icon'] ?? ''); ?>" placeholder="e.g. fad fa-tv-retro, fab fa-discord">
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Open in New Tab</label>
                    <select name="nav2[<?php echo $h($idx); ?>][target]">
                        <option value=""        <?php echo empty($item['target']) ? 'selected' : ''; ?>>Same tab</option>
                        <option value="_blank"  <?php echo (($item['target'] ?? '') === '_blank') ? 'selected' : ''; ?>>New tab</option>
                    </select>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Icon Color</label>
                    <input type="color" name="nav2[<?php echo $h($idx); ?>][icon_color]" value="<?php echo $h(!empty($item['icon_color']) ? $item['icon_color'] : '#13110e'); ?>">
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Hover Glow Color</label>
                    <input type="color" name="nav2[<?php echo $h($idx); ?>][glow_color]" value="<?php echo $h(!empty($item['glow_color']) ? $item['glow_color'] : '#22a04a'); ?>">
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one Footer Link editor row (used by all three footer columns).
 *
 * Same shape as the Secondary Navbar (nav2) row but trimmed down — no
 * color fields, since footer links are always rendered against the dark
 * footer background and don't need per-link colors. Adds an enable
 * toggle so links can be disabled without losing their settings.
 *
 * @param int        $colNum Which footer column this belongs to (1, 2, 3)
 * @param int|string $idx
 * @param array      $item   {label, url, icon, target, enabled}
 * @return string HTML
 */
function kfRenderFooterLinkRow($colNum, $idx, array $item)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $labelDisplay = !empty($item['label']) ? $item['label'] : 'New footer link';
    $isEnabled = !array_key_exists('enabled', $item) || $item['enabled'] !== '0';
    $name = "footer_col{$colNum}_items";

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (empty($item['label']) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="label"><?php echo $h($labelDisplay); ?>
                <?php if (!$isEnabled): ?>
                    <span data-kf-hidden-badge="1" style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Disabled</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field" style="flex:1.2;">
                    <label>Label <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="<?php echo $h($name); ?>[<?php echo $h($idx); ?>][label]" value="<?php echo $h($item['label'] ?? ''); ?>" placeholder="Link label" data-sync-summary="1">
                </div>
                <div class="kf-field" style="flex:2;">
                    <label>URL <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="<?php echo $h($name); ?>[<?php echo $h($idx); ?>][url]" value="<?php echo $h($item['url'] ?? ''); ?>" placeholder="/index.php?rp=/knowledgebase  or  https://example.com">
                </div>
                <div class="kf-field" style="flex:0 0 160px;">
                    <label>Open in</label>
                    <select name="<?php echo $h($name); ?>[<?php echo $h($idx); ?>][target]">
                        <option value=""        <?php echo empty($item['target']) ? 'selected' : ''; ?>>Same tab</option>
                        <option value="_blank"  <?php echo (($item['target'] ?? '') === '_blank') ? 'selected' : ''; ?>>New tab</option>
                    </select>
                </div>
                <div class="kf-field" style="flex:0 0 110px;">
                    <label>&nbsp;</label>
                    <label class="kf-toggle" style="margin-top:8px;white-space:nowrap;">
                        <input type="checkbox" name="<?php echo $h($name); ?>[<?php echo $h($idx); ?>][enabled]" value="1" <?php echo $isEnabled ? 'checked' : ''; ?> data-kf-visible-toggle>
                        Enabled
                    </label>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}


/**
 * Render one Primary Navbar (Row 1) editor row.
 *
 * @param int|string $idx
 * @param array      $item   {label, url, icon, icon_color, glow_color, visible, protected}
 * @return string HTML
 */
function kfRenderNav1Row($idx, array $item)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $labelDisplay = !empty($item['label']) ? $item['label'] : 'New nav item';
    // Default visible if 'visible' key absent (back-compat for older saves)
    $isVisible = !array_key_exists('visible', $item) || $item['visible'] !== '0';
    // Protected items are WHMCS defaults — label/URL locked, no delete button
    $isProtected = !empty($item['protected']) && $item['protected'] === '1';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : (($item['label'] === '' || $item['label'] === null) ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="label"><?php echo $h($labelDisplay); ?>
                <?php if (!empty($item['icon'])): ?>
                    <span style="color:#7a7268;font-weight:500;font-size:12px;margin-left:6px;"><?php echo $h($item['icon']); ?></span>
                <?php endif; ?>
                <?php if ($isProtected): ?>
                    <span style="background:#eef4ff;color:#1a6fff;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;" title="This is a WHMCS default item and can't be removed.">Default</span>
                <?php endif; ?>
                <?php if (!$isVisible): ?>
                    <span data-kf-hidden-badge="1" style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <?php if (!$isProtected): ?>
                    <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
                <?php endif; ?>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <?php if ($isProtected): ?>
                <div class="kf-row">
                    <div class="kf-field">
                        <label>Menu Label <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— WHMCS default, can't be changed</span></label>
                        <div style="padding:9px 12px;background:#f7f5f0;border:1.5px solid #e5e0d8;border-radius:6px;font-size:13px;color:#5a5249;font-family:inherit;"><?php echo $h($item['label']); ?></div>
                        <input type="hidden" name="nav1[<?php echo $h($idx); ?>][label]" value="<?php echo $h($item['label']); ?>">
                    </div>
                    <div class="kf-field">
                        <label>URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— WHMCS default route</span></label>
                        <div style="padding:9px 12px;background:#f7f5f0;border:1.5px solid #e5e0d8;border-radius:6px;font-size:13px;color:#5a5249;font-family:'SF Mono',Menlo,Consolas,monospace;"><?php echo $h($item['url'] ?? ''); ?></div>
                        <input type="hidden" name="nav1[<?php echo $h($idx); ?>][url]" value="<?php echo $h($item['url'] ?? ''); ?>">
                    </div>
                </div>
            <?php else: ?>
                <div class="kf-row">
                    <div class="kf-field">
                        <label>Menu Label <span style="color:#cc2828;">*</span> <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— must match WHMCS exactly</span></label>
                        <input type="text" name="nav1[<?php echo $h($idx); ?>][label]" value="<?php echo $h($item['label']); ?>" placeholder="Label as it appears in the navbar" data-sync-summary="1">
                    </div>
                    <div class="kf-field">
                        <label>URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— required to add missing items</span></label>
                        <input type="text" name="nav1[<?php echo $h($idx); ?>][url]" value="<?php echo $h($item['url'] ?? ''); ?>" placeholder="index.php?rp=/store">
                    </div>
                </div>
            <?php endif; ?>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Font Awesome Icon <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="text" name="nav1[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($item['icon']); ?>" placeholder="e.g. fas fa-home, far fa-envelope, fab fa-discord">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Icon Color</label>
                    <input type="color" name="nav1[<?php echo $h($idx); ?>][icon_color]" value="<?php echo $h(!empty($item['icon_color']) ? $item['icon_color'] : '#13110e'); ?>">
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Hover Glow Color</label>
                    <input type="color" name="nav1[<?php echo $h($idx); ?>][glow_color]" value="<?php echo $h(!empty($item['glow_color']) ? $item['glow_color'] : '#22a04a'); ?>">
                </div>
                <div class="kf-field" style="flex:1;">
                    <label>&nbsp;</label>
                    <label class="kf-toggle" style="margin-top:8px;">
                        <input type="checkbox" name="nav1[<?php echo $h($idx); ?>][visible]" value="1" <?php echo $isVisible ? 'checked' : ''; ?> data-kf-visible-toggle>
                        Visible in navbar
                    </label>
                    <p class="kf-help" style="margin-top:4px;">Uncheck to hide. When ON, the addon ensures the item exists in the navbar — adding it via WHMCS hook if missing (uses the URL above). When OFF, the addon removes the item from the navbar entirely.</p>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one homepage card editor row.
 *
 * @param int|string $idx     Numeric index or '__INDEX__' for the JS template
 * @param array      $card    Card data (enabled, title, subtitle, description, link, bullet1-3, accent, image)
 * @return string HTML
 */
function kfRenderCardRow($idx, array $card)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $accent = !empty($card['accent']) ? $card['accent'] : '#22a04a';
    $isTemplate = $idx === '__INDEX__';
    $titleDisplay = $card['title'] !== '' ? $card['title'] : 'Untitled card';

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($card['title'] === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Use ↑/↓ buttons to reorder">⋮⋮</span>
            <span class="kf-card-row-toggle">
                <input type="checkbox" name="cards[<?php echo $h($idx); ?>][enabled]" value="1" <?php echo (!empty($card['enabled']) && $card['enabled'] !== '0') ? 'checked' : ''; ?> onclick="event.stopPropagation();">
            </span>
            <span class="kf-card-row-title" data-bind-from="title"><?php echo $h($titleDisplay); ?></span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn" data-action="duplicate" title="Duplicate this card">❐</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete this card">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>Title <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][title]" value="<?php echo $h($card['title']); ?>" placeholder="Service name" data-sync-summary="1">
                </div>
                <div class="kf-field">
                    <label>Subtitle <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— small caps under title</span></label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][subtitle]" value="<?php echo $h($card['subtitle']); ?>" placeholder="Short tagline">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Description <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional, shown above bullets</span></label>
                    <textarea name="cards[<?php echo $h($idx); ?>][description]" style="min-height:62px;font-family:inherit;font-size:13px;" placeholder="Optional short paragraph above the bullet list."><?php echo $h($card['description']); ?></textarea>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Button Link <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][link]" value="<?php echo $h($card['link']); ?>" placeholder="/clientarea.php?action=services  or  https://example.com/your-page">
                </div>
                <div class="kf-field">
                    <label>Image URL <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional, local upload recommended</span></label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][image]" value="<?php echo $h($card['image']); ?>" placeholder="/templates/kwickflix/img/homepagecards/my-card.jpg">
                </div>
            </div>

            <p class="kf-help" style="margin:0 0 12px;">Image URL: upload images to <code>/templates/kwickflix/img/homepagecards/</code> on your server and reference them as <code>/templates/kwickflix/img/homepagecards/filename.jpg</code> — or paste any full external URL. ~600×400 PNG/JPG works well.</p>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Bullet 1</label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][bullet1]" value="<?php echo $h($card['bullet1']); ?>" placeholder="First feature">
                </div>
                <div class="kf-field">
                    <label>Bullet 2</label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][bullet2]" value="<?php echo $h($card['bullet2']); ?>" placeholder="Second feature">
                </div>
                <div class="kf-field">
                    <label>Bullet 3</label>
                    <input type="text" name="cards[<?php echo $h($idx); ?>][bullet3]" value="<?php echo $h($card['bullet3']); ?>" placeholder="Third feature">
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 200px;">
                    <label>Accent Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— bullets + button</span></label>
                    <input type="color" name="cards[<?php echo $h($idx); ?>][accent]" value="<?php echo $h($accent); ?>">
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * Render one editor row for a payment gateway entry under the
 * Cart/Checkout → Payment Gateways section. Modeled on
 * kfRenderStatTileRow — same drag handle, up/down/delete buttons,
 * collapsible details summary.
 *
 * Each row's data structure (also used at render time on checkout.tpl):
 *   gateway          — WHMCS gateway sysname (the dropdown selection)
 *   title            — display title on the payment card
 *   subtext          — description below the title (HTML allowed)
 *   icon             — free-form HTML / emoji / image URL (auto-detected)
 *   preferred        — '1' or '0', shows a corner ribbon when '1'
 *   preferred_label  — text for the ribbon (default "PREFERRED")
 *   visible          — '1' or '0' (mirrors stat tile pattern)
 */
function kfRenderPaymentGatewayRow($idx, array $row, array $activeGateways)
{
    $h = function ($v) { return htmlspecialchars((string) $v, ENT_QUOTES); };
    $isTemplate = $idx === '__INDEX__';
    $title      = $row['title']           ?? '';
    $gateway    = $row['gateway']         ?? '';
    $subtext    = $row['subtext']         ?? '';
    $icon       = $row['icon']            ?? '';
    $preferred  = ($row['preferred']      ?? '0') === '1';
    $prefLabel  = $row['preferred_label'] ?? 'PREFERRED';
    $accent     = $row['accent']          ?? '';
    $isVisible  = !array_key_exists('visible', $row) || $row['visible'] !== '0';

    // Friendly label for the summary line — show the chosen gateway
    // sysname alongside the title so the admin can scan the list.
    $summaryLabel = $title !== '' ? $title : ($gateway !== '' ? $gateway : 'New payment gateway');

    ob_start();
    ?>
    <details class="kf-card-row" data-idx="<?php echo $h($idx); ?>" <?php echo $isTemplate ? 'open' : ($title === '' ? 'open' : ''); ?>>
        <summary class="kf-card-row-header">
            <span class="kf-card-row-grip" title="Drag to reorder (or use ↑/↓)">⋮⋮</span>
            <span class="kf-card-row-title" data-bind-from="title"><?php echo $h($summaryLabel); ?>
                <?php if ($preferred): ?>
                    <span style="background:#fff7df;color:#7a4a00;font-weight:700;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">★ Preferred</span>
                <?php endif; ?>
                <?php if (!$isVisible): ?>
                    <span data-kf-hidden-badge="1" style="background:#fef2f2;color:#cc2828;font-weight:600;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:8px;letter-spacing:.04em;text-transform:uppercase;">Hidden</span>
                <?php endif; ?>
            </span>
            <span class="kf-card-row-actions" onclick="event.preventDefault();event.stopPropagation();">
                <button type="button" class="kf-card-mini-btn" data-action="up"   title="Move up">↑</button>
                <button type="button" class="kf-card-mini-btn" data-action="down" title="Move down">↓</button>
                <button type="button" class="kf-card-mini-btn kf-card-mini-btn-delete" data-action="delete" title="Delete">✕</button>
            </span>
        </summary>

        <div class="kf-card-row-body">
            <div class="kf-row">
                <div class="kf-field">
                    <label>WHMCS Gateway <span style="color:#cc2828;">*</span></label>
                    <select name="payment_gateways[<?php echo $h($idx); ?>][gateway]">
                        <?php foreach ($activeGateways as $sys => $name): ?>
                            <option value="<?php echo $h($sys); ?>" <?php echo $gateway === $sys ? 'selected' : ''; ?>>
                                <?php echo $h($name); ?><?php echo $sys !== '' ? ' (' . $h($sys) . ')' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="kf-help">Pick the underlying WHMCS gateway this card represents. The dropdown lists all active gateways from Setup → Payments. Hidden/disabled gateways are excluded automatically.</p>
                </div>
                <div class="kf-field" style="flex:0 0 200px;">
                    <label class="kf-toggle" style="margin-top:24px;">
                        <input type="checkbox" name="payment_gateways[<?php echo $h($idx); ?>][visible]" value="1" data-kf-visible-toggle <?php echo $isVisible ? 'checked' : ''; ?>>
                        Show this gateway
                    </label>
                    <p class="kf-help">Quick hide without deleting the entry. Settings are kept for later.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Display Title <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="payment_gateways[<?php echo $h($idx); ?>][title]" value="<?php echo $h($title); ?>" placeholder="e.g. Moonpay (Debit / $15 min) (Automated)" data-sync-summary="1">
                    <p class="kf-help">Bold heading shown on the payment card. Overrides WHMCS's stored gateway name.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Subtext <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="payment_gateways[<?php echo $h($idx); ?>][subtext]" value="<?php echo $h($subtext); ?>" placeholder="e.g. Debit card via MoonPay. Verification required.">
                    <p class="kf-help">Smaller description under the title. HTML allowed — e.g. <code>&lt;b&gt;US &amp; UK only.&lt;/b&gt;</code></p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field">
                    <label>Icon / Emoji / Image <span style="color:#cc2828;">*</span></label>
                    <input type="text" name="payment_gateways[<?php echo $h($idx); ?>][icon]" value="<?php echo $h($icon); ?>" placeholder="💳 or /path/to/icon.png or &lt;i class=&quot;fab fa-cc-visa&quot;&gt;&lt;/i&gt;">
                    <p class="kf-help">Three formats work, auto-detected at render time:
                        <br>• <strong>Emoji</strong> — paste any emoji directly (e.g. <code>💳</code>, <code>🪙</code>, <code>💰</code>)
                        <br>• <strong>Image path or URL</strong> — anything starting with <code>/</code>, <code>http://</code>, or <code>https://</code> is rendered as <code>&lt;img&gt;</code>. Upload your icons anywhere on your server and reference them by absolute path (e.g. <code>/path/to/your-icons/venmo.png</code>).
                        <br>• <strong>Raw HTML</strong> — Font Awesome tags, inline SVG, or any custom markup (e.g. <code>&lt;i class="fab fa-cc-visa"&gt;&lt;/i&gt;</code>)</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 220px;">
                    <label class="kf-toggle">
                        <input type="checkbox" name="payment_gateways[<?php echo $h($idx); ?>][preferred]" value="1" <?php echo $preferred ? 'checked' : ''; ?>>
                        Mark as "Preferred"
                    </label>
                    <p class="kf-help">Adds a corner ribbon and applies the section-level Preferred Border/Glow color when selected (overrides this row's own color).</p>
                </div>
                <div class="kf-field">
                    <label>Ribbon Label</label>
                    <input type="text" name="payment_gateways[<?php echo $h($idx); ?>][preferred_label]" value="<?php echo $h($prefLabel); ?>" placeholder="PREFERRED">
                    <p class="kf-help">Text inside the ribbon. Only shown when "Preferred" is checked.</p>
                </div>
            </div>

            <div class="kf-row">
                <div class="kf-field" style="flex:0 0 220px;">
                    <label>Border / Glow Color <span style="color:#7a7268;font-weight:500;text-transform:none;letter-spacing:0;">— optional</span></label>
                    <input type="color" name="payment_gateways[<?php echo $h($idx); ?>][accent]" value="<?php echo $h($accent !== '' ? $accent : '#22a04a'); ?>">
                    <label class="kf-toggle" style="margin-top:6px;">
                        <input type="checkbox" name="payment_gateways[<?php echo $h($idx); ?>][accent_enabled]" value="1" <?php echo $accent !== '' ? 'checked' : ''; ?>>
                        Override master accent for this gateway
                    </label>
                    <p class="kf-help">When this gateway is the selected one on checkout, its thin border + inner glow use this color. Falls back to the site's master accent when off. If this gateway is also marked Preferred, the section-level Preferred color wins.</p>
                </div>
            </div>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

