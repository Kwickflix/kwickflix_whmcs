{if $checkout}

    {include file="orderforms/$carttpl/checkout.tpl"}

{else}

    <script>
        var statesTab = 10;
        var stateNotRequired = true;
    </script>
    {include file="orderforms/$carttpl/common.tpl"}
    <script type="text/javascript" src="{$BASE_PATH_JS}/StatesDropdown.js"></script>

    {* ════════════ CHECKOUT MARQUEE ════════════
       Addon-controlled (kwickflixstyle → Cart/Checkout tab). Renders a
       seamless horizontal scroll of logos defined in the admin, with
       optional greyscale + per-install speed control. Hidden entirely
       when the toggle is off or no items are configured. *}
    {if isset($kf_checkout_marquee_enabled) && $kf_checkout_marquee_enabled && $kf_checkout_marquee_items}
        <div class="kf-cart-marquee {if $kf_checkout_marquee_greyscale}kf-cart-marquee-greyscale{/if}"
             style="--kf-cart-mq-speed:{$kf_checkout_marquee_speed};">
            <div class="kf-cart-marquee-track" id="kfCartMarqueeTrack">
                {foreach $kf_checkout_marquee_items as $kf_cmq}
                    <div class="kf-cart-marquee-item"><img src="{$kf_cmq.url}" alt="{if $kf_cmq.alt}{$kf_cmq.alt}{/if}" loading="lazy"></div>
                {/foreach}
            </div>
        </div>
        {literal}
        <script>
        (function(){
            var track = document.getElementById('kfCartMarqueeTrack');
            if (!track) return;
            // Shuffle once per pageload for visual variety, then duplicate
            // the (now-shuffled) set so the -50% scroll loops seamlessly.
            var items = Array.from(track.children);
            for (var i = items.length - 1; i > 0; i--){
                var j = Math.floor(Math.random() * (i + 1));
                var tmp = items[i]; items[i] = items[j]; items[j] = tmp;
            }
            track.innerHTML = '';
            items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
            items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
        })();
        </script>
        {/literal}
    {/if}

    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    {literal}
    <style>
    /* ── WHMCS WRAPPER STRIP ── */
    .panel,.panel-default,.panel-body,.portlet,.portlet-body,
    .card,.card-body,.content-container,.content-panel{
      background:transparent !important;
      border:none !important;
      box-shadow:none !important;
    }

    :root{
      --vc-bg:#f5f3ef;
      --vc-surface:#fefdfb;
      --vc-surface2:#f7f5f0;
      --vc-surface3:#ede9e2;
      --vc-border:#d8d3cc;
      --vc-border2:#bfb8ae;
      --vc-text:#13110e;
      --vc-muted:#7a7268;
      --vc-muted2:#5a5249;
      --vc-accent:#22a04a;
      --vc-accent-dark:#167a36;
      --vc-accent-bg:rgba(34,160,74,.07);
      --vc-accent-border:rgba(34,160,74,.18);
      --vc-danger:#cc2828;
      --vc-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
      --vc-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
      --vc-shadow-lg:0 12px 40px rgba(19,17,14,.1),0 4px 12px rgba(19,17,14,.06);
      --vc-shadow-green:0 6px 24px rgba(34,160,74,.25),0 2px 8px rgba(34,160,74,.12);
    }

    /* ── CART MARQUEE (inline so it works even if the bridge CSS file isn't loaded) ── */
    .kf-cart-marquee{
      overflow:hidden;
      width:100%;
      margin:0 0 20px;
      -webkit-mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);
              mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);
    }
    .kf-cart-marquee-track{
      display:flex;
      align-items:center;
      gap:60px;
      width:max-content;
      padding-right:60px;
      animation:kfCartMarqueeScroll calc(35s / var(--kf-cart-mq-speed, 1)) linear infinite;
    }
    .kf-cart-marquee-item{
      flex-shrink:0;
      display:flex;
      align-items:center;
      transition:opacity .2s ease, filter .2s ease;
    }
    .kf-cart-marquee-item img{
      height:52px;
      width:auto;
      object-fit:contain;
      opacity:.85;
    }
    @keyframes kfCartMarqueeScroll{
      from{transform:translateX(0);}
      to  {transform:translateX(-50%);}
    }
    .kf-cart-marquee.kf-cart-marquee-greyscale .kf-cart-marquee-item{
      opacity:.4;
      filter:grayscale(1);
    }
    .kf-cart-marquee.kf-cart-marquee-greyscale .kf-cart-marquee-item:hover{
      opacity:.9;
      filter:grayscale(0);
    }

    /* ── CART WRAPPER ── */
    #order-standard_cart{
      font-family:'Outfit',sans-serif;
      color:var(--vc-text);
      max-width:1100px;
      margin:0 auto;
      padding:0 0 60px;
    }

    /* ── PAGE TITLE ── */
    #order-standard_cart .header-lined{
      margin-bottom:28px;
      padding-bottom:20px;
      border-bottom:1px solid var(--vc-border);
    }

    #order-standard_cart .header-lined h1{
      font-family:'Barlow Condensed',sans-serif;
      font-size:clamp(36px,6vw,56px);
      font-weight:900;
      letter-spacing:-.02em;
      line-height:1;
      color:var(--vc-text);
    }

    /* ── ALERTS ── */
    #order-standard_cart .alert{
      border-radius:10px;
      border:1px solid var(--vc-border);
      font-family:'Outfit',sans-serif;
      font-size:14px;
      padding:14px 18px;
      margin-bottom:20px;
    }
    #order-standard_cart .alert-warning{background:rgba(245,158,11,.07);border-color:rgba(245,158,11,.25);color:#92400e;}
    #order-standard_cart .alert-danger{background:rgba(204,40,40,.06);border-color:rgba(204,40,40,.2);color:var(--vc-danger);}
    #order-standard_cart .alert-success{background:var(--vc-accent-bg);border-color:var(--vc-accent-border);color:var(--vc-accent-dark);}
    #order-standard_cart .alert-info{background:rgba(26,111,255,.06);border-color:rgba(26,111,255,.2);color:#1a4fff;}

    /* ── CART ITEMS HEADER ── */
    #order-standard_cart .view-cart-items-header{
      background:var(--vc-surface2);
      border:1px solid var(--vc-border);
      border-radius:10px 10px 0 0;
      padding:12px 18px;
      font-size:11px;
      font-weight:800;
      text-transform:uppercase;
      letter-spacing:.14em;
      color:var(--vc-muted);
    }

    /* ── CART ITEMS LIST ── */
    #order-standard_cart .view-cart-items{
      border:1px solid var(--vc-border);
      border-top:none;
      border-radius:0 0 10px 10px;
      background:var(--vc-surface);
      margin-bottom:4px;
      overflow:hidden;
    }

    #order-standard_cart .view-cart-items .item{
      padding:16px 18px;
      border-bottom:1px solid var(--vc-border);
      transition:.15s ease;
    }

    #order-standard_cart .view-cart-items .item:last-child{border-bottom:none;}
    #order-standard_cart .view-cart-items .item:hover{background:var(--vc-surface2);}

    #order-standard_cart .item-title{
      font-size:15px;
      font-weight:600;
      color:var(--vc-text);
      display:block;
      margin-bottom:3px;
    }

    #order-standard_cart .item-group{
      font-size:12px;
      color:var(--vc-muted);
      font-weight:400;
      display:block;
    }

    #order-standard_cart .item-domain{
      font-size:12px;
      color:var(--vc-muted2);
      font-weight:500;
      display:block;
      font-style:italic;
    }

    #order-standard_cart .item-price{
      font-size:15px;
      font-weight:700;
      color:var(--vc-text);
      text-align:right;
    }

    #order-standard_cart .item-price .cycle{
      display:block;
      font-size:11px;
      font-weight:500;
      color:var(--vc-muted);
      margin-top:2px;
    }

    #order-standard_cart .view-cart-empty{
      padding:40px 24px;
      text-align:center;
      font-size:15px;
      color:var(--vc-muted);
      font-style:italic;
    }

    /* ── EDIT/REMOVE LINKS ── */
    #order-standard_cart .btn-link{
      color:var(--vc-muted) !important;
      font-size:12px !important;
      font-weight:500;
      padding:0 6px;
      text-decoration:none;
      transition:.15s;
    }
    #order-standard_cart .btn-link:hover{color:var(--vc-danger) !important;}

    /* ── EMPTY CART BTN ── */
    #order-standard_cart .empty-cart{
      margin-bottom:24px;
      text-align:right;
    }
    #order-standard_cart #btnEmptyCart{
      background:var(--vc-danger);
      color:#fff !important;
      border-radius:6px;
      padding:6px 14px;
      font-weight:600;
      font-size:13px;
      text-decoration:none;
    }
    #order-standard_cart #btnEmptyCart:hover{
      background:#a81f1f;
      color:#fff !important;
    }
    #order-standard_cart #btnEmptyCart i,
    #order-standard_cart #btnEmptyCart span{
      color:#fff !important;
    }

    /* ── TABS (promo / tax) ── */
    #order-standard_cart .view-cart-tabs{
      margin-top:16px;
    }

    #order-standard_cart .nav-tabs{
      border-bottom:1px solid var(--vc-border);
      margin-bottom:0;
    }

    #order-standard_cart .nav-tabs .nav-item .nav-link{
      font-family:'Outfit',sans-serif;
      font-size:13px;
      font-weight:600;
      color:var(--vc-muted);
      border:1px solid transparent;
      border-radius:8px 8px 0 0;
      padding:10px 18px;
      transition:.15s;
    }

    #order-standard_cart .nav-tabs .nav-item .nav-link:hover{color:var(--vc-text);}
    #order-standard_cart .nav-tabs .nav-item .nav-link.active{
      color:var(--vc-accent);
      background:var(--vc-surface);
      border-color:var(--vc-border) var(--vc-border) var(--vc-surface);
    }

    #order-standard_cart .tab-content{
      background:var(--vc-surface);
      border:1px solid var(--vc-border);
      border-top:none;
      border-radius:0 0 10px 10px;
      padding:20px 18px;
    }

    /* ── PROMO INPUT ── */
    #order-standard_cart .form-group .form-control{
      border:1.5px solid var(--vc-border);
      border-radius:8px;
      font-family:'Outfit',sans-serif;
      font-size:14px;
      padding:10px 14px;
      background:var(--vc-surface);
      color:var(--vc-text);
      transition:.15s;
    }

    #order-standard_cart .form-group .form-control:focus{
      border-color:var(--vc-accent);
      box-shadow:0 0 0 3px var(--vc-accent-bg);
      outline:none;
    }

    #order-standard_cart .prepend-icon .field-icon{
      color:var(--vc-muted);
    }
    #order-standard_cart .prepend-icon .form-control{
      padding-left:40px;
    }

    #order-standard_cart .btn-default{
      background:var(--vc-surface2);
      border:1.5px solid var(--vc-border);
      border-radius:8px;
      font-family:'Outfit',sans-serif;
      font-size:14px;
      font-weight:600;
      color:var(--vc-text);
      padding:10px 20px;
      transition:.18s ease;
    }

    #order-standard_cart .btn-default:hover{
      background:var(--vc-surface3);
      border-color:var(--vc-border2);
    }

    /* ── VIEW CART GATEWAY ── */
    #order-standard_cart .view-cart-gateway-checkout{
      margin:12px 0;
    }

    /* ── ORDER SUMMARY SIDEBAR ── */
    /* Kill stock .summary-container background (#f8f8f8 + padding +
       border-radius from css/style.css line 428) — it creates an inner
       box inside the order-summary card. The parent provides the chrome. */
    #order-standard_cart .summary-container,
    #order-standard_cart #producttotal,
    #order-standard_cart #producttotal .summary-container{
      background:transparent !important;
      border:none !important;
      border-radius:0 !important;
      padding:0 !important;
      min-height:0 !important;
      box-shadow:none !important;
      font-size:inherit !important;
    }

    #order-standard_cart .order-summary{
      background:var(--vc-surface);
      border:1px solid var(--vc-border);
      border-radius:14px;
      box-shadow:var(--vc-shadow-md);
      padding:24px 22px;
      position:sticky;
      top:24px;
    }

    #order-standard_cart .order-summary h2{
      font-family:'Barlow Condensed',sans-serif;
      font-size:28px;
      font-weight:900;
      letter-spacing:-.01em;
      color:var(--vc-text);
      margin-bottom:20px;
      line-height:1;
    }

    #order-standard_cart .summary-container .subtotal{
      display:flex;
      justify-content:space-between;
      align-items:center;
      font-size:14px;
      font-weight:500;
      color:var(--vc-muted);
      padding-bottom:12px;
      margin-bottom:12px;
      border-bottom:1px solid var(--vc-border);
    }

    #order-standard_cart .summary-container .bordered-totals{
      padding:10px 0;
      border-bottom:1px solid var(--vc-border);
      margin-bottom:10px;
    }

    #order-standard_cart .summary-container .bordered-totals .clearfix{
      display:flex;
      justify-content:space-between;
      font-size:13px;
      color:var(--vc-muted);
      margin-bottom:6px;
    }

    #order-standard_cart .recurring-totals{
      display:flex;
      justify-content:space-between;
      align-items:flex-start;
      font-size:14px;
      color:var(--vc-muted2);
      font-weight:500;
      padding-bottom:16px;
      margin-bottom:16px;
      border-bottom:1px solid var(--vc-border);
    }

    #order-standard_cart .recurring-charges{
      text-align:right;
      font-size:13px;
      color:var(--vc-muted);
    }

    #order-standard_cart .recurring-charges .cost{
      font-weight:700;
      color:var(--vc-text);
    }

    /* Total Due Today — flat centered typography, NOT a nested card.
       The order-summary parent already provides the card chrome; another
       boxed element inside it reads as box-in-box. The accent color on
       the price text gives it enough emphasis on its own. No top border
       either — the breathing room above is enough of a separator. */
    #order-standard_cart .total-due-today{
      background:transparent;
      border:none;
      padding:8px 0 4px;
      margin-bottom:12px;
      display:flex;
      flex-direction:column;
      align-items:center;
      text-align:center;
      gap:4px;
    }

    #order-standard_cart .total-due-today .amt{
      font-family:'Barlow Condensed',sans-serif;
      font-size:40px;
      font-weight:900;
      color:var(--vc-accent);
      line-height:1;
      letter-spacing:-.02em;
    }

    #order-standard_cart .total-due-today > span:last-child{
      font-size:11px;
      font-weight:700;
      text-transform:uppercase;
      letter-spacing:.12em;
      color:var(--vc-muted);
    }

    /* ── CHECKOUT BUTTON ── */
    #order-standard_cart .btn-checkout{
      display:block;
      width:100%;
      background:var(--vc-accent);
      color:#fff !important;
      border:none;
      border-radius:8px;
      padding:16px 24px;
      font-family:'Outfit',sans-serif;
      font-size:16px;
      font-weight:700;
      text-align:center;
      text-decoration:none !important;
      transition:.2s ease;
      box-shadow:var(--vc-shadow-green);
      margin-bottom:10px;
    }

    #order-standard_cart .btn-checkout:hover{
      background:var(--vc-accent-dark);
      transform:translateY(-1px);
      box-shadow:0 8px 32px rgba(34,160,74,.32);
      color:#fff !important;
    }

    #order-standard_cart .btn-checkout.disabled{
      opacity:.5;
      pointer-events:none;
    }

    #order-standard_cart .btn-continue-shopping{
      display:block;
      text-align:center;
      font-size:13px;
      font-weight:600;
      color:var(--vc-muted) !important;
      margin-top:6px;
      text-decoration:none;
    }

    #order-standard_cart .btn-continue-shopping:hover{color:var(--vc-text) !important;}

    /* ── PROMO CODE APPLIED ── */
    #order-standard_cart .view-cart-promotion-code{
      background:var(--vc-accent-bg);
      border:1px solid var(--vc-accent-border);
      border-radius:8px;
      padding:10px 14px;
      font-size:13px;
      font-weight:600;
      color:var(--vc-accent-dark);
      margin-bottom:12px;
    }

    /* ── MODAL ── */
    #order-standard_cart .modal-content{
      border-radius:14px;
      border:1px solid var(--vc-border);
      box-shadow:var(--vc-shadow-lg);
      font-family:'Outfit',sans-serif;
    }

    #order-standard_cart .modal-body{padding:28px 28px 20px;}
    #order-standard_cart .modal-footer{padding:16px 28px 24px;border-top:1px solid var(--vc-border);}

    #order-standard_cart .modal-title{
      font-family:'Barlow Condensed',sans-serif;
      font-size:24px;
      font-weight:800;
      color:var(--vc-text);
    }

    #order-standard_cart .modal-footer .btn-primary{
      background:var(--vc-danger);
      border:none;
      border-radius:8px;
      padding:10px 24px;
      font-weight:700;
      font-size:14px;
    }

    /* ── HIDE SIDEBAR, CENTER LAYOUT ── */
    #order-standard_cart .cart-sidebar{
      display:none !important;
    }
    #order-standard_cart .cart-body{
      width:100% !important;
      max-width:900px;
      margin:0 auto;
      float:none !important;
    }
    /* Also hide collapsed sidebar categories on mobile */
    #order-standard_cart .sidebar-categories-collapsed,
#order-standard_cart .sidebar-categories-collapsed *,
#order-standard_cart .cart-sidebar,
#order-standard_cart .cart-sidebar *,
#order-standard_cart .categories-collapsed,
#order-standard_cart .categories-collapsed *,
#order-standard_cart .panel-actions,
#order-standard_cart .panel-actions *,
#order-standard_cart .actions,
#order-standard_cart .actions *{
  display:none !important;
}

    /* ── RESPONSIVE ── */
    @media(max-width:767px){
      #order-standard_cart .order-summary{
        position:static;
        margin-top:24px;
      }
    }
    </style>
    {/literal}

    <div id="order-standard_cart">
        <div class="row">
            <div class="cart-sidebar">
                {include file="orderforms/$carttpl/sidebar-categories.tpl"}
            </div>
            <div class="cart-body">
                <div class="header-lined">
                    <h1 class="font-size-36">{$LANG.cartreviewcheckout}</h1>
                </div>

                {* {include file="orderforms/$carttpl/sidebar-categories-collapsed.tpl"} *}

                <div class="row">
                    <div class="secondary-cart-body">

                        {if $promoerrormessage}
                            <div class="alert alert-warning text-center" role="alert">{$promoerrormessage}</div>
                        {elseif $errormessage}
                            <div class="alert alert-danger" role="alert">
                                <p>{$LANG.orderForm.correctErrors}:</p>
                                <ul>{$errormessage}</ul>
                            </div>
                        {elseif $promotioncode && $rawdiscount eq "0.00"}
                            <div class="alert alert-info text-center" role="alert">{$LANG.promoappliedbutnodiscount}</div>
                        {elseif $promoaddedsuccess}
                            <div class="alert alert-success text-center" role="alert">{$LANG.orderForm.promotionAccepted}</div>
                        {/if}

                        {if $bundlewarnings}
                            <div class="alert alert-warning" role="alert">
                                <strong>{$LANG.bundlereqsnotmet}</strong><br />
                                <ul>
                                    {foreach from=$bundlewarnings item=warning}
                                        <li>{$warning}</li>
                                    {/foreach}
                                </ul>
                            </div>
                        {/if}

                        <form method="post" action="{$smarty.server.PHP_SELF}?a=view">

                            <div class="view-cart-items-header">
                                <div class="row">
                                    <div class="{if $showqtyoptions}col-sm-5{else}col-sm-7{/if} col-xs-7 col-7">
                                        {$LANG.orderForm.productOptions}
                                    </div>
                                    {if $showqtyoptions}
                                        <div class="col-sm-2 hidden-xs text-center d-none d-sm-block">
                                            {$LANG.orderForm.qty}
                                        </div>
                                    {/if}
                                    <div class="col-sm-4 col-xs-5 col-5 text-right">
                                        {$LANG.orderForm.priceCycle}
                                    </div>
                                </div>
                            </div>

                            <div class="view-cart-items">

                                {foreach $products as $num => $product}
                                    <div class="item">
                                        <div class="row">
                                            <div class="{if $showqtyoptions}col-sm-5{else}col-sm-7{/if}">
                                                <span class="item-title">
                                                    {$product.productinfo.name}
                                                    <a href="{$WEB_ROOT}/cart.php?a=confproduct&i={$num}" class="btn btn-link btn-xs">
                                                        <i class="fas fa-pencil-alt"></i> {$LANG.orderForm.edit}
                                                    </a>
                                                    <span class="visible-xs-inline d-inline d-sm-none">
                                                        <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('p','{$num}')">
                                                            <i class="fas fa-times"></i> {$LANG.orderForm.remove}
                                                        </button>
                                                    </span>
                                                </span>
                                                <span class="item-group">{$product.productinfo.groupname}</span>
                                                {if $product.domain}<span class="item-domain">{$product.domain}</span>{/if}
                                                {if $product.configoptions}
                                                    <small>
                                                        {foreach key=confnum item=configoption from=$product.configoptions}
                                                            &nbsp;&raquo; {$configoption.name}: {if $configoption.type eq 1 || $configoption.type eq 2}{$configoption.option}{elseif $configoption.type eq 3}{if $configoption.qty}{$configoption.option}{else}{$LANG.no}{/if}{elseif $configoption.type eq 4}{$configoption.qty} x {$configoption.option}{/if}<br />
                                                        {/foreach}
                                                    </small>
                                                {/if}
                                            </div>
                                            {if $showqtyoptions}
                                                <div class="col-sm-2 item-qty">
                                                    {if $product.allowqty}
                                                        <input type="number" name="qty[{$num}]" value="{$product.qty}" class="form-control text-center" min="0" />
                                                        <button type="submit" class="btn btn-xs">{$LANG.orderForm.update}</button>
                                                    {/if}
                                                </div>
                                            {/if}
                                            <div class="col-sm-4 item-price">
                                                <span>{$product.pricing.totalTodayExcludingTaxSetup}</span>
                                                <span class="cycle">{$product.billingcyclefriendly}</span>
                                                {if $product.pricing.productonlysetup}{$product.pricing.productonlysetup->toPrefixed()} {$LANG.ordersetupfee}{/if}
                                                {if $product.proratadate}<br />({$LANG.orderprorata} {$product.proratadate}){/if}
                                            </div>
                                            <div class="col-sm-1 hidden-xs d-none d-sm-block">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('p','{$num}')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                    {foreach $product.addons as $addonnum => $addon}
                                        <div class="item">
                                            <div class="row">
                                                <div class="{if $showAddonQtyOptions}col-sm-5{else}col-sm-7{/if}">
                                                    <span class="item-title">{$addon.name}</span>
                                                    <span class="item-group">{$LANG.orderaddon}</span>
                                                </div>
                                                {if $showAddonQtyOptions}
                                                    <div class="col-sm-2 item-qty">
                                                        {if $addon.allowqty === 2}
                                                            <input type="number" name="paddonqty[{$num}][{$addonnum}]" value="{$addon.qty}" class="form-control text-center" min="0" />
                                                            <button type="submit" class="btn btn-xs">{$LANG.orderForm.update}</button>
                                                        {/if}
                                                    </div>
                                                {/if}
                                                <div class="col-sm-4 item-price">
                                                    <span>{$addon.totaltoday}</span>
                                                    <span class="cycle">{$addon.billingcyclefriendly}</span>
                                                    {if $addon.setup}{$addon.setup->toPrefixed()} {$LANG.ordersetupfee}{/if}
                                                    {if $addon.isProrated}<br />({$LANG.orderprorata} {$addon.prorataDate}){/if}
                                                </div>
                                            </div>
                                        </div>
                                    {/foreach}
                                {/foreach}

                                {foreach $addons as $num => $addon}
                                    <div class="item">
                                        <div class="row">
                                            <div class="{if $showAddonQtyOptions}col-sm-5{else}col-sm-7{/if}">
                                                <span class="item-title">
                                                    {$addon.name}
                                                    <span class="visible-xs-inline d-inline d-sm-none">
                                                        <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('a','{$num}')">
                                                            <i class="fas fa-times"></i> {$LANG.orderForm.remove}
                                                        </button>
                                                    </span>
                                                </span>
                                                <span class="item-group">{$addon.productname}</span>
                                                {if $addon.domainname}<span class="item-domain">{$addon.domainname}</span>{/if}
                                            </div>
                                            {if $showAddonQtyOptions}
                                                <div class="col-sm-2 item-qty">
                                                    {if $addon.allowqty === 2}
                                                        <input type="number" name="addonqty[{$num}]" value="{$addon.qty}" class="form-control text-center" min="0" />
                                                        <button type="submit" class="btn btn-xs">{$LANG.orderForm.update}</button>
                                                    {/if}
                                                </div>
                                            {/if}
                                            <div class="col-sm-4 item-price">
                                                <span>{$addon.totaltoday}</span>
                                                <span class="cycle">{$addon.billingcyclefriendly}</span>
                                                {if $addon.setup}{$addon.setup->toPrefixed()} {$LANG.ordersetupfee}{/if}
                                                {if $addon.isProrated}<br />({$LANG.orderprorata} {$addon.prorataDate}){/if}
                                            </div>
                                            <div class="col-sm-1 hidden-xs d-none d-sm-block">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('a','{$num}')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}

                                {foreach $domains as $num => $domain}
                                    <div class="item">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <span class="item-title">
                                                    {if $domain.type eq "register"}{$LANG.orderdomainregistration}{else}{$LANG.orderdomaintransfer}{/if}
                                                    <a href="{$WEB_ROOT}/cart.php?a=confdomains" class="btn btn-link btn-xs">
                                                        <i class="fas fa-pencil-alt"></i> {$LANG.orderForm.edit}
                                                    </a>
                                                    <span class="visible-xs-inline d-inline d-sm-none">
                                                        <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('d','{$num}')">
                                                            <i class="fas fa-times"></i> {$LANG.orderForm.remove}
                                                        </button>
                                                    </span>
                                                </span>
                                                {if $domain.domain}<span class="item-domain">{$domain.domain}</span>{/if}
                                                {if $domain.dnsmanagement}&nbsp;&raquo; {$LANG.domaindnsmanagement}<br />{/if}
                                                {if $domain.emailforwarding}&nbsp;&raquo; {$LANG.domainemailforwarding}<br />{/if}
                                                {if $domain.idprotection}&nbsp;&raquo; {$LANG.domainidprotection}<br />{/if}
                                            </div>
                                            <div class="col-sm-4 item-price">
                                                {if count($domain.pricing) == 1 || $domain.type == 'transfer'}
                                                    <span name="{$domain.domain}Price">{$domain.price}</span>
                                                    <span class="cycle">{$domain.regperiod} {$domain.yearsLanguage}</span>
                                                    <span class="renewal cycle">
                                                        {if isset($domain.renewprice)}{lang key='domainrenewalprice'} <span class="renewal-price cycle">{$domain.renewprice->toPrefixed()}{$domain.shortRenewalYearsLanguage}</span>{/if}
                                                    </span>
                                                {else}
                                                    <span name="{$domain.domain}Price">{$domain.price}</span>
                                                    <div class="dropdown">
                                                        <button class="btn btn-default btn-xs dropdown-toggle" type="button" id="{$domain.domain}Pricing" name="{$domain.domain}Pricing" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                            {$domain.regperiod} {$domain.yearsLanguage} <span class="caret"></span>
                                                        </button>
                                                        <ul class="dropdown-menu" aria-labelledby="{$domain.domain}Pricing">
                                                            {foreach $domain.pricing as $years => $price}
                                                                <li class="dropdown-item">
                                                                    <a href="#" onclick="selectDomainPeriodInCart('{$domain.domain}', '{$price.register}', {$years}, '{if $years == 1}{lang key='orderForm.year'}{else}{lang key='orderForm.years'}{/if}');return false;">
                                                                        {$years} {if $years == 1}{lang key='orderForm.year'}{else}{lang key='orderForm.years'}{/if} @ {$price.register}
                                                                    </a>
                                                                </li>
                                                            {/foreach}
                                                        </ul>
                                                    </div>
                                                    <span class="renewal cycle">
                                                        {lang key='domainrenewalprice'} <span class="renewal-price cycle">{if isset($domain.renewprice)}{$domain.renewprice->toPrefixed()}{$domain.shortRenewalYearsLanguage}{/if}</span>
                                                    </span>
                                                {/if}
                                            </div>
                                            <div class="col-sm-1 hidden-xs d-none d-sm-block">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('d','{$num}')">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}

                                {foreach $renewalsByType['services'] as $num => $service}
                                    <div class="item">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <span class="item-title">{lang key='renewService.titleAltSingular'}</span>
                                                <span class="item-group">{$service.name}</span>
                                                <span class="item-domain">{$service.domainName}</span>
                                            </div>
                                            <div class="col-sm-4 item-price">
                                                <span>{$service.recurringBeforeTax}</span>
                                                <span class="cycle">{$service.billingCycle}</span>
                                            </div>
                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('r','{$num}','service')">
                                                    <i class="fas fa-times"></i>
                                                    <span class="visible-xs d-block d-sm-none">{lang key='orderForm.remove'}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}

                                {foreach $renewalsByType['addons'] as $num => $service}
                                    <div class="item">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <span class="item-title">{lang key='renewServiceAddon.titleAltSingular'}</span>
                                                <span class="item-group">{$service.name}</span>
                                                <span class="item-domain">{$service.domainName}</span>
                                            </div>
                                            <div class="col-sm-4 item-price">
                                                <span>{$service.recurringBeforeTax}</span>
                                                <span class="cycle">{$service.billingCycle}</span>
                                            </div>
                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('r','{$num}','addon')">
                                                    <i class="fas fa-times"></i>
                                                    <span class="visible-xs d-block d-sm-none">{lang key='orderForm.remove'}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}

                                {foreach $renewalsByType['domains'] as $num => $domain}
                                    <div class="item">
                                        <div class="row">
                                            <div class="col-sm-7">
                                                <span class="item-title">{$LANG.domainrenewal}</span>
                                                <span class="item-domain">{$domain.domain}</span>
                                                {if $domain.dnsmanagement}&nbsp;&raquo; {$LANG.domaindnsmanagement}<br />{/if}
                                                {if $domain.emailforwarding}&nbsp;&raquo; {$LANG.domainemailforwarding}<br />{/if}
                                                {if $domain.idprotection}&nbsp;&raquo; {$LANG.domainidprotection}<br />{/if}
                                            </div>
                                            <div class="col-sm-4 item-price">
                                                <span>{$domain.price}</span>
                                                <span class="cycle">{$domain.regperiod} {$LANG.orderyears}</span>
                                            </div>
                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('r','{$num}','domain')">
                                                    <i class="fas fa-times"></i>
                                                    <span class="visible-xs d-block d-sm-none">{$LANG.orderForm.remove}</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}

                                {foreach $upgrades as $num => $upgrade}
                                    <div class="item">
                                        <div class="row">
                                            <div class="{if $showUpgradeQtyOptions}col-sm-5{else}col-sm-7{/if}">
                                                <span class="item-title">{$LANG.upgrade}</span>
                                                <span class="item-group">
                                                    {if $upgrade->type == 'service'}{$upgrade->originalProduct->productGroup->name}<br>{$upgrade->originalProduct->name} => {$upgrade->newProduct->name}
                                                    {elseif $upgrade->type == 'addon'}{$upgrade->originalAddon->name} => {$upgrade->newAddon->name}{/if}
                                                </span>
                                                <span class="item-domain">{if $upgrade->type == 'service'}{$upgrade->service->domain}{/if}</span>
                                            </div>
                                            {if $showUpgradeQtyOptions}
                                                <div class="col-sm-2 item-qty">
                                                    {if $upgrade->allowMultipleQuantities}
                                                        <input type="number" name="upgradeqty[{$num}]" value="{$upgrade->qty}" class="form-control text-center" min="{$upgrade->minimumQuantity}" />
                                                        <button type="submit" class="btn btn-xs">{$LANG.orderForm.update}</button>
                                                    {/if}
                                                </div>
                                            {/if}
                                            <div class="col-sm-4 item-price">
                                                <span>{$upgrade->newRecurringAmount}</span>
                                                <span class="cycle">{$upgrade->localisedNewCycle}</span>
                                            </div>
                                            <div class="col-sm-1">
                                                <button type="button" class="btn btn-link btn-xs btn-remove-from-cart" onclick="removeItem('u','{$num}')">
                                                    <i class="fas fa-times"></i>
                                                    <span class="visible-xs d-block d-sm-none">{$LANG.orderForm.remove}</span>
                                                </button>
                                            </div>
                                        </div>
                                        {if $upgrade->totalDaysInCycle > 0}
                                            <div class="row row-upgrade-credit">
                                                <div class="col-sm-7">
                                                    <span class="item-group">{$LANG.upgradeCredit}</span>
                                                    <div class="upgrade-calc-msg">{lang key="upgradeCreditDescription" daysRemaining=$upgrade->daysRemaining totalDays=$upgrade->totalDaysInCycle}</div>
                                                </div>
                                                <div class="col-sm-4 item-price"><span>-{$upgrade->creditAmount}</span></div>
                                            </div>
                                        {/if}
                                    </div>
                                {/foreach}

                                {if $cartitems == 0}
                                    <div class="view-cart-empty">{$LANG.cartempty}</div>
                                {/if}

                            </div>

                            {if $cartitems > 0}
                                <div class="empty-cart">
                                    <button type="button" class="btn btn-link btn-xs" id="btnEmptyCart">
                                        <i class="fas fa-trash-alt"></i> <span>{$LANG.emptycart}</span>
                                    </button>
                                </div>
                            {/if}

                        </form>

                        {foreach $hookOutput as $output}<div>{$output}</div>{/foreach}

                        {foreach $gatewaysoutput as $gatewayoutput}
                            <div class="view-cart-gateway-checkout">{$gatewayoutput}</div>
                        {/foreach}

                        <div class="view-cart-tabs">
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="nav-item active">
                                    <a href="#applyPromo" class="nav-link active" aria-controls="applyPromo" role="tab" data-toggle="tab"{if $template == 'twenty-one'} aria-selected="true"{else} aria-expanded="true"{/if}>
                                        {$LANG.orderForm.applyPromoCode}
                                    </a>
                                </li>
                                {if $taxenabled && !$loggedin}
                                    <li role="presentation" class="nav-item">
                                        <a href="#calcTaxes" class="nav-link" aria-controls="calcTaxes" role="tab" data-toggle="tab"{if $template == 'twenty-one'} aria-selected="false"{else} aria-expanded="false"{/if}>
                                            {$LANG.orderForm.estimateTaxes}
                                        </a>
                                    </li>
                                {/if}
                            </ul>
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active promo" id="applyPromo">
                                    {if $promotioncode}
                                        <div class="view-cart-promotion-code">{$promotioncode} — {$promotiondescription}</div>
                                        <div class="text-center">
                                            <a href="{$WEB_ROOT}/cart.php?a=removepromo" class="btn btn-default btn-xs">{$LANG.orderForm.removePromotionCode}</a>
                                        </div>
                                    {else}
                                        <form method="post" action="{$WEB_ROOT}/cart.php?a=view">
                                            <div class="form-group prepend-icon">
                                                <label for="cardno" class="field-icon"><i class="fas fa-ticket-alt"></i></label>
                                                <input type="text" name="promocode" id="inputPromotionCode" class="field form-control" placeholder="{lang key="orderPromoCodePlaceholder"}" required="required">
                                            </div>
                                            <button type="submit" name="validatepromo" class="btn btn-block btn-default" value="{$LANG.orderpromovalidatebutton}">
                                                {$LANG.orderpromovalidatebutton}
                                            </button>
                                        </form>
                                    {/if}
                                </div>
                                <div role="tabpanel" class="tab-pane" id="calcTaxes">
                                    <form method="post" action="{$WEB_ROOT}/cart.php?a=setstateandcountry">
                                        <div class="form-group row">
                                            <label for="inputState" class="pt-sm-2 col-sm-4 control-label text-sm-right">{$LANG.orderForm.state}</label>
                                            <div class="col-sm-7">
                                                <input type="text" name="state" id="inputState" value="{$clientsdetails.state}" class="form-control"{if $loggedin} disabled="disabled"{/if} />
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="inputCountry" class="pt-sm-2 col-sm-4 control-label text-sm-right">{$LANG.orderForm.country}</label>
                                            <div class="col-sm-7">
                                                <select name="country" id="inputCountry" class="form-control">
                                                    {foreach $countries as $countrycode => $countrylabel}
                                                        <option value="{$countrycode}"{if (!$country && $countrycode == $defaultcountry) || $countrycode eq $country} selected{/if}>{$countrylabel}</option>
                                                    {/foreach}
                                                </select>
                                            </div>
                                        </div>
                                        <div class="form-group text-center">
                                            <button type="submit" class="btn btn-default">{$LANG.orderForm.updateTotals}</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="secondary-cart-sidebar" id="scrollingPanelContainer">

                        <div class="order-summary" id="orderSummary">
                            <div class="loader w-hidden" id="orderSummaryLoader">
                                <i class="fas fa-fw fa-sync fa-spin"></i>
                            </div>
                            <h2 class="font-size-30">{$LANG.ordersummary}</h2>
                            <div class="summary-container">

                                <div class="subtotal clearfix">
                                    <span class="pull-left float-left">{$LANG.ordersubtotal}</span>
                                    <span id="subtotal" class="pull-right float-right">{$subtotal}</span>
                                </div>

                                {if $promotioncode || $taxrate || $taxrate2}
                                    <div class="bordered-totals">
                                        {if $promotioncode}
                                            <div class="clearfix">
                                                <span class="pull-left float-left">{$promotiondescription}</span>
                                                <span id="discount" class="pull-right float-right">{$discount}</span>
                                            </div>
                                        {/if}
                                        {if $taxrate}
                                            <div class="clearfix">
                                                <span class="pull-left float-left">{$taxname} @ {$taxrate}%</span>
                                                <span id="taxTotal1" class="pull-right float-right">{$taxtotal}</span>
                                            </div>
                                        {/if}
                                        {if $taxrate2}
                                            <div class="clearfix">
                                                <span class="pull-left float-left">{$taxname2} @ {$taxrate2}%</span>
                                                <span id="taxTotal2" class="pull-right float-right">{$taxtotal2}</span>
                                            </div>
                                        {/if}
                                    </div>
                                {/if}

                                <div class="recurring-totals clearfix">
                                    <span class="pull-left float-left">{$LANG.orderForm.totals}</span>
                                    <span id="recurring" class="pull-right float-right recurring-charges">
                                        <span id="recurringMonthly" {if !$totalrecurringmonthly}style="display:none;"{/if}><span class="cost">{$totalrecurringmonthly}</span> {$LANG.orderpaymenttermmonthly}<br /></span>
                                        <span id="recurringQuarterly" {if !$totalrecurringquarterly}style="display:none;"{/if}><span class="cost">{$totalrecurringquarterly}</span> {$LANG.orderpaymenttermquarterly}<br /></span>
                                        <span id="recurringSemiAnnually" {if !$totalrecurringsemiannually}style="display:none;"{/if}><span class="cost">{$totalrecurringsemiannually}</span> {$LANG.orderpaymenttermsemiannually}<br /></span>
                                        <span id="recurringAnnually" {if !$totalrecurringannually}style="display:none;"{/if}><span class="cost">{$totalrecurringannually}</span> {$LANG.orderpaymenttermannually}<br /></span>
                                        <span id="recurringBiennially" {if !$totalrecurringbiennially}style="display:none;"{/if}><span class="cost">{$totalrecurringbiennially}</span> {$LANG.orderpaymenttermbiennially}<br /></span>
                                        <span id="recurringTriennially" {if !$totalrecurringtriennially}style="display:none;"{/if}><span class="cost">{$totalrecurringtriennially}</span> {$LANG.orderpaymenttermtriennially}<br /></span>
                                    </span>
                                </div>

                                <div class="total-due-today total-due-today-padded">
                                    <span id="totalDueToday" class="amt">{$total}</span>
                                    <span>{$LANG.ordertotalduetoday}</span>
                                </div>

                                <div class="express-checkout-buttons">
                                    {foreach $expressCheckoutButtons as $checkoutButton}
                                        {$checkoutButton}
                                        <div class="separator">- {$LANG.or|strtoupper} -</div>
                                    {/foreach}
                                </div>

                                <div class="text-right">
                                    <a href="{$WEB_ROOT}/cart.php?a=checkout&e=false" class="btn btn-success btn-lg btn-checkout{if $cartitems == 0} disabled{/if}" id="checkout">
                                        {$LANG.orderForm.checkout} <i class="fas fa-arrow-right"></i>
                                    </a><br />
                                    <a href="{$WEB_ROOT}/cart.php" class="btn btn-link btn-continue-shopping" id="continueShopping">
                                        {$LANG.orderForm.continueShopping}
                                    </a>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

        <form method="post" action="{$WEB_ROOT}/cart.php">
            <input type="hidden" name="a" value="remove" />
            <input type="hidden" name="r" value="" id="inputRemoveItemType" />
            <input type="hidden" name="i" value="" id="inputRemoveItemRef" />
            <input type="hidden" name="rt" value="" id="inputRemoveItemRenewalType">
            <div class="modal fade modal-remove-item" id="modalRemoveItem" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="float-right">
                                <button type="button" class="close" data-dismiss="modal" aria-label="{lang key='orderForm.close'}"><span aria-hidden="true">&times;</span></button>
                            </div>
                            <h4 class="modal-title margin-bottom mb-3">
                                <i class="fas fa-times fa-3x"></i> <span>{lang key='orderForm.removeItem'}</span>
                            </h4>
                            {lang key='cartremoveitemconfirm'}
                        </div>
                        <div class="modal-footer justify-content-center">
                            <button type="button" class="btn btn-default" data-dismiss="modal">{lang key='no'}</button>
                            <button type="submit" class="btn btn-primary">{lang key='yes'}</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

        <form method="post" action="{$WEB_ROOT}/cart.php">
            <input type="hidden" name="a" value="empty" />
            <div class="modal fade modal-remove-item" id="modalEmptyCart" tabindex="-1" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="float-right">
                                <button type="button" class="close" data-dismiss="modal" aria-label="{$LANG.orderForm.close}"><span aria-hidden="true">&times;</span></button>
                            </div>
                            <h4 class="modal-title margin-bottom mb-3">
                                <i class="fas fa-trash-alt fa-3x"></i> <span>{$LANG.emptycart}</span>
                            </h4>
                            {$LANG.cartemptyconfirm}
                        </div>
                        <div class="modal-footer justify-content-center">
                            <button type="button" class="btn btn-default" data-dismiss="modal">{$LANG.no}</button>
                            <button type="submit" class="btn btn-primary">{$LANG.yes}</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    </div>
    {include file="orderforms/$carttpl/recommendations-modal.tpl"}
{/if}
