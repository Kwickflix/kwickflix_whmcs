{include file="orderforms/$carttpl/common.tpl"}

<style>
/* All colors below derive from kwickflix tokens (--ca-*) emitted by the
   main template's $kf_dynamic_css. The bridge CSS remaps --vc-* → --ca-*
   inside #order-standard_cart, so any of these variables resolve to the
   current master accent. Hardcoded RGB fallbacks keep things readable
   on a non-kwickflix install. */

/* Center all main content in the order body */
#order-standard_cart .cart-body {
    text-align: center;
}

/* Header */
#order-standard_cart .cart-body .header-lined {
    text-align: center;
}

/* Highlight Continue Button — uses the master accent for the glow ring */
#order-standard_cart .kf-glow-btn {
    background: var(--vc-surface, #ffffff) !important;
    box-shadow:
        0 0 15px var(--vc-accent-border, rgba(34,160,74,.55)),
        0 0 25px var(--vc-accent-border, rgba(34,160,74,.35));
    border: 2px solid var(--vc-accent, #22a04a) !important;
    color: var(--vc-accent, #22a04a) !important;
    font-family: 'Outfit', sans-serif;
    font-weight: 700;
    transition: .25s ease-in-out;
    border-radius: 12px;
    padding: 10px 24px;
}

#order-standard_cart .kf-glow-btn:hover {
    background: var(--vc-accent, #22a04a) !important;
    color: #fff !important;
    box-shadow:
        0 0 30px var(--vc-accent-border, rgba(34,160,74,.7)),
        0 0 50px var(--vc-accent-border, rgba(34,160,74,.45));
}

/* Order-number pill */
#order-standard_cart .order-confirmation {
    background: var(--vc-surface, #ffffff);
    border: 2px solid var(--vc-accent, #22a04a);
    padding: 6px 18px;
    border-radius: 12px;
    text-align: center;
    font-size: 15px;
    font-weight: 600;
    color: var(--vc-accent-dark, #167a36);
    font-family: 'Outfit', sans-serif;
    display: inline-block;
    margin-top: 8px;
    box-shadow:
        0 0 12px var(--vc-accent-border, rgba(34,160,74,.45)),
        0 0 22px var(--vc-accent-border, rgba(34,160,74,.25));
    transition: .25s ease-in-out;
}

#order-standard_cart .order-confirmation:hover {
    box-shadow:
        0 0 20px var(--vc-accent-border, rgba(34,160,74,.7)),
        0 0 35px var(--vc-accent-border, rgba(34,160,74,.5));
}

/* Optional secondary CTA (kept for later) — uses muted neutrals so it
   doesn't compete visually with the master-accent primary above */
#order-standard_cart .kf-service-btn {
    margin-top: 10px;
    background: var(--vc-surface2, #f7f5f0);
    color: var(--vc-text, #13110e) !important;
    border: 1.5px solid var(--vc-border, #d8d3cc);
    font-family: 'Outfit', sans-serif;
    font-weight: 600;
    border-radius: 12px;
    padding: 10px 20px;
    display: inline-block;
    transition: .2s ease-in-out;
}
#order-standard_cart .kf-service-btn:hover {
    background: var(--vc-surface3, #ede9e2);
    border-color: var(--vc-border2, #bfb8ae);
}
</style>

<div id="order-standard_cart">

    <div class="row">
        <div class="cart-sidebar">
            {include file="orderforms/$carttpl/sidebar-categories.tpl"}
        </div>

        <div class="cart-body">

            <div class="header-lined">
                <h1 class="font-size-36">{$LANG.orderconfirmation}</h1>
            </div>

            {include file="orderforms/$carttpl/sidebar-categories-collapsed.tpl"}

            <p>
                Thank you for your order.<br>
                You will also receive a confirmation email shortly.
            </p>

            <!-- RED BUTTON FIRST -->
            <div class="text-center" style="margin-top:15px; margin-bottom:10px;">
                <a href="{$WEB_ROOT}/clientarea.php" class="btn btn-default kf-glow-btn">
                    {$LANG.orderForm.continueToClientArea}
                    &nbsp;<i class="fas fa-arrow-circle-right"></i>
                </a>
            </div>

            <!-- BLUE ORDER NUMBER BANNER UNDERNEATH -->
            <div class="row">
                <div class="col-sm-12">
                    <div class="order-confirmation">
                        {$LANG.ordernumberis} <span>{$ordernumber}</span>
                    </div>
                </div>
            </div>

            {if $expressCheckoutInfo}
                <div class="alert alert-info text-center">
                    {$expressCheckoutInfo}
                </div>
            {elseif $expressCheckoutError}
                <div class="alert alert-danger text-center">
                    {$expressCheckoutError}
                </div>
            {elseif $invoiceid && !$ispaid}
                <div class="alert alert-warning text-center">
                    {$LANG.ordercompletebutnotpaid}
                    <br><br>
                    <a href="{$WEB_ROOT}/viewinvoice.php?id={$invoiceid}" target="_blank" class="alert-link">
                        {$LANG.invoicenumber}{$invoiceid}
                    </a>
                </div>
            {/if}

            {foreach $addons_html as $addon_html}
                <div class="order-confirmation-addon-output">
                    {$addon_html}
                </div>
            {/foreach}

            {if $ispaid}
                <!-- Place any tracking / conversion code here -->
            {/if}

            {if $hasRecommendations}
                {include file="orderforms/$carttpl/includes/product-recommendations.tpl"}
            {/if}

        </div>
    </div>
</div>
