{include file="orderforms/$carttpl/common.tpl"}
{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ── WHMCS WRAPPER STRIP ── */
.panel,.panel-default,.panel-body,.portlet,.portlet-body,
.card,.card-body,.content-container,.content-panel{
  background:transparent !important;
  border:none !important;
  box-shadow:none !important;
}

:root{
  --vc-surface:#fefdfb;
  --vc-surface2:#f7f5f0;
  --vc-surface3:#ede9e2;
  --vc-border:#d8d3cc;
  --vc-border2:#bfb8ae;
  --vc-text:#13110e;
  --vc-muted:#7a7268;
  --vc-muted2:#5a5249;
  --vc-accent:#22a04a;
  --vc-accent-dark:#167a36;
  --vc-accent-bg:rgba(34,160,74,.07);
  --vc-accent-border:rgba(34,160,74,.18);
  --vc-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --vc-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
  --vc-shadow-green:0 6px 24px rgba(34,160,74,.25),0 2px 8px rgba(34,160,74,.12);
}

/* ── HIDE SIDEBAR, CENTER LAYOUT ── */
#order-standard_cart .cart-sidebar,
#order-standard_cart .sidebar-categories-collapsed{display:none !important;}
#order-standard_cart .cart-body{
  width:100% !important;
  max-width:860px;
  margin:0 auto;
  float:none !important;
}

/* ── WRAPPER ── */
#order-standard_cart{
  font-family:'Outfit',sans-serif;
  color:var(--vc-text);
  max-width:1100px;
  margin:0 auto;
  padding:0 0 60px;
}

/* ── PAGE TITLE ── */
#order-standard_cart .header-lined{
  margin-bottom:28px;
  padding-bottom:20px;
  border-bottom:1px solid var(--vc-border);
}
#order-standard_cart .header-lined h1{
  font-family:'Barlow Condensed',sans-serif;
  font-size:clamp(36px,6vw,56px);
  font-weight:900;
  letter-spacing:-.02em;
  line-height:1;
  color:var(--vc-text);
}

/* ── PRODUCT INFO ── */
#order-standard_cart .product-info{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:12px;
  padding:18px 20px;
  margin-bottom:24px;
  box-shadow:var(--vc-shadow-sm);
}
#order-standard_cart .product-info .product-title{
  font-family:'Barlow Condensed',sans-serif;
  font-size:24px;
  font-weight:800;
  letter-spacing:-.01em;
  color:var(--vc-text);
  margin-bottom:6px;
  line-height:1;
}
#order-standard_cart .product-info p:last-child{
  font-size:14px;
  color:var(--vc-muted);
  margin:0;
  line-height:1.6;
}
#order-standard_cart > .row > .cart-body > form > .row > .secondary-cart-body > p:first-child{
  font-size:14px;
  color:var(--vc-muted);
  margin-bottom:16px;
}

/* ── SUB HEADINGS ── */
.sub-heading,
#order-standard_cart .sub-heading{
  background:transparent !important;
  background-image:none !important;
  border:none !important;
  box-shadow:none !important;
  padding:0 !important;
  margin:24px 0 16px !important;
  overflow:visible !important;
}
.sub-heading span,
.sub-heading .primary-bg-color,
#order-standard_cart .sub-heading span,
#order-standard_cart .sub-heading .primary-bg-color{
  display:block !important;
  background:transparent !important;
  background-image:none !important;
  border-top:none !important;
  border-left:none !important;
  border-right:none !important;
  border-bottom:1.5px solid var(--vc-border) !important;
  box-shadow:none !important;
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:20px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--vc-text) !important;
  padding:0 0 10px 0 !important;
  line-height:1.2 !important;
  width:100% !important;
  position:static !important;
}
.sub-heading::before,.sub-heading::after,
.sub-heading span::before,.sub-heading span::after,
.sub-heading .primary-bg-color::before,.sub-heading .primary-bg-color::after,
#order-standard_cart .sub-heading::before,#order-standard_cart .sub-heading::after,
#order-standard_cart .sub-heading span::before,#order-standard_cart .sub-heading span::after,
#order-standard_cart .sub-heading .primary-bg-color::before,
#order-standard_cart .sub-heading .primary-bg-color::after{
  display:none !important;
  content:none !important;
  width:0 !important;
  height:0 !important;
  border:none !important;
  background:none !important;
}

/* ── FORM INPUTS ── */
#order-standard_cart .form-control{
  border:1.5px solid var(--vc-border) !important;
  border-radius:8px !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  padding:10px 14px !important;
  background:var(--vc-surface) !important;
  color:var(--vc-text) !important;
  transition:.15s ease !important;
  height:auto !important;
}
#order-standard_cart .form-control:focus{
  border-color:var(--vc-accent) !important;
  box-shadow:0 0 0 3px var(--vc-accent-bg) !important;
  outline:none !important;
}
#order-standard_cart label{
  font-size:13px;
  font-weight:600;
  color:var(--vc-muted2);
  margin-bottom:6px;
  display:block;
}

/* ── DROPDOWN SELECT INDICATOR ── */
#order-standard_cart select.form-control,
#order-standard_cart select.custom-select {
  appearance: none !important;
  -webkit-appearance: none !important;
  -moz-appearance: none !important;

  padding-right: 42px !important;

  background-color: var(--vc-surface) !important;
  background-image:
    linear-gradient(45deg, transparent 50%, var(--vc-muted2) 50%),
    linear-gradient(135deg, var(--vc-muted2) 50%, transparent 50%) !important;
  background-position:
    calc(100% - 22px) 50%,
    calc(100% - 15px) 50% !important;
  background-size:
    7px 7px,
    7px 7px !important;
  background-repeat: no-repeat !important;

  cursor: pointer !important;
}

#order-standard_cart select.form-control:hover,
#order-standard_cart select.custom-select:hover {
  border-color: var(--vc-border2) !important;
}

#order-standard_cart select.form-control:focus,
#order-standard_cart select.custom-select:focus {
  border-color: var(--vc-accent) !important;
  box-shadow: 0 0 0 3px var(--vc-accent-bg) !important;

  background-image:
    linear-gradient(45deg, transparent 50%, var(--vc-accent) 50%),
    linear-gradient(135deg, var(--vc-accent) 50%, transparent 50%) !important;
}

/* ── BILLING CYCLE SELECT ── */
#order-standard_cart .select-inline{
  width:auto !important;
  min-width:200px;
}

/* ── FIELD CONTAINER ── */
#order-standard_cart .field-container{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:12px;
  padding:20px;
  margin-bottom:20px;
  box-shadow:var(--vc-shadow-sm);
}

/* ── CONFIGURABLE OPTIONS ── */
#order-standard_cart .product-configurable-options{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:12px;
  padding:20px;
  margin-bottom:20px;
  box-shadow:var(--vc-shadow-sm);
}

/* radio + checkbox options */
#order-standard_cart input[type="radio"],
#order-standard_cart input[type="checkbox"]{
  accent-color:var(--vc-accent);
  width:15px;height:15px;
  margin-right:6px;
  vertical-align:middle;
}

/* ── ADDON CARDS ── */
#order-standard_cart .panel-addon{
  background:var(--vc-surface) !important;
  border:1.5px solid var(--vc-border) !important;
  border-radius:12px !important;
  box-shadow:var(--vc-shadow-sm) !important;
  overflow:hidden !important;
  transition:.2s ease !important;
  margin-bottom:14px !important;
}
#order-standard_cart .panel-addon:hover{
  border-color:var(--vc-border2) !important;
  box-shadow:var(--vc-shadow-md) !important;
  transform:translateY(-2px);
}
#order-standard_cart .panel-addon-selected{
  border-color:var(--vc-accent) !important;
  box-shadow:0 4px 16px rgba(34,160,74,.15) !important;
}
#order-standard_cart .panel-addon .panel-body,
#order-standard_cart .panel-addon .card-body{
  padding:16px 18px !important;
  background:transparent !important;
  border:none !important;
  font-size:13px;
  color:var(--vc-muted);
}
#order-standard_cart .panel-addon .panel-body label,
#order-standard_cart .panel-addon .card-body label{
  font-size:15px !important;
  font-weight:700 !important;
  color:var(--vc-text) !important;
  cursor:pointer;
}
#order-standard_cart .panel-price{
  background:var(--vc-surface2);
  border-top:1px solid var(--vc-border);
  padding:10px 18px;
  font-size:14px;
  font-weight:600;
  color:var(--vc-accent);
}
#order-standard_cart .panel-add{
  background:var(--vc-accent);
  color:#fff;
  padding:10px 18px;
  font-size:13px;
  font-weight:700;
  text-align:center;
  cursor:pointer;
  transition:.18s ease;
}
#order-standard_cart .panel-add:hover{background:var(--vc-accent-dark);}

/* ── INFO ALERT ── */
#order-standard_cart .alert{
  border-radius:10px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  padding:14px 18px;
  margin-bottom:16px;
  border:1px solid var(--vc-border);
}
#order-standard_cart .alert-warning{
  background:rgba(245,158,11,.07);
  border-color:rgba(245,158,11,.25);
  color:#92400e;
}
#order-standard_cart .alert-danger{
  background:rgba(204,40,40,.06);
  border-color:rgba(204,40,40,.2);
  color:#cc2828;
}

/* ── ORDER SUMMARY SIDEBAR ── */
/* Mirror of viewcart.tpl's proven order-summary styling. Kills the stock
   .summary-container background (#f8f8f8 + padding + border-radius from
   style.css line 428) — that's the inner box that creates box-in-box.
   The parent .order-summary provides the card chrome. Internal dividers
   on .subtotal/.bordered-totals/.recurring-totals are kept INTACT
   because they're the section separators (subtotal vs totals vs
   recurring vs due-today) — they're features, not the box-in-box. */
/* Outer #orderSummary wrapper is just a layout container — must NOT
   have any card chrome (only the .order-summary inside it does).
   Some stock styles + WHMCS-injected wrappers can give #orderSummary,
   .loader, etc subtle borders/backgrounds; strip them all. */
#order-standard_cart #orderSummary,
#order-standard_cart #orderSummaryLoader,
#order-standard_cart .loader,
#order-standard_cart .summary-container,
#order-standard_cart #producttotal,
#order-standard_cart #producttotal > div:not(.total-due-today):not(.subtotal):not(.bordered-totals):not(.recurring-totals),
#order-standard_cart #producttotal .summary-container{
  background:transparent !important;
  background-color:transparent !important;
  background-image:none !important;
  border:none !important;
  border-radius:0 !important;
  padding:0 !important;
  min-height:0 !important;
  box-shadow:none !important;
  outline:none !important;
  font-size:inherit !important;
}

#order-standard_cart .order-summary .product-name{
  display:block;
  font-family:'Outfit',sans-serif;
  font-weight:700;
  color:var(--vc-text);
  font-size:16px;
  margin-bottom:2px;
}
#order-standard_cart .order-summary .product-group{
  display:block;
  font-style:italic;
  color:var(--vc-muted);
  font-size:11px;
  text-transform:uppercase;
  letter-spacing:.08em;
  margin-bottom:14px;
  padding-bottom:14px;
  border-bottom:1px solid var(--vc-border);
}

#order-standard_cart .summary-container .subtotal,
#order-standard_cart .order-summary .subtotal{
  display:flex;
  justify-content:space-between;
  align-items:center;
  font-size:14px;
  font-weight:500;
  color:var(--vc-muted);
  padding-bottom:12px;
  margin-bottom:12px;
  border-bottom:1px solid var(--vc-border);
}

#order-standard_cart .summary-container .bordered-totals,
#order-standard_cart .order-summary .bordered-totals{
  padding:10px 0;
  border-bottom:1px solid var(--vc-border);
  margin-bottom:10px;
}

#order-standard_cart .summary-container .bordered-totals .clearfix,
#order-standard_cart .order-summary .bordered-totals .clearfix{
  display:flex;
  justify-content:space-between;
  font-size:13px;
  color:var(--vc-muted);
  margin-bottom:6px;
}

#order-standard_cart .recurring-totals{
  display:flex;
  justify-content:space-between;
  align-items:flex-start;
  font-size:14px;
  color:var(--vc-muted2);
  font-weight:500;
  padding-bottom:16px;
  margin-bottom:16px;
  border-bottom:1px solid var(--vc-border);
}

#order-standard_cart .recurring-charges{
  text-align:right;
  font-size:13px;
  color:var(--vc-muted);
}

#order-standard_cart .recurring-charges .cost{
  font-weight:700;
  color:var(--vc-text);
}

/* Total Due Today — flat centered typography, NOT a nested card. */
#order-standard_cart .total-due-today{
  background:transparent !important;
  border:none !important;
  padding:8px 0 4px !important;
  margin-bottom:12px !important;
  display:flex !important;
  flex-direction:column !important;
  align-items:center !important;
  text-align:center !important;
  gap:4px !important;
}
#order-standard_cart .total-due-today .amt{
  font-family:'Barlow Condensed',sans-serif;
  font-size:40px;
  font-weight:900;
  color:var(--vc-accent);
  line-height:1;
  letter-spacing:-.02em;
}
#order-standard_cart .total-due-today > span:last-child{
  font-size:11px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.12em;
  color:var(--vc-muted);
}

#order-standard_cart #orderSummary .order-summary{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:14px;
  box-shadow:var(--vc-shadow-md);
  padding:24px 22px;
  margin-bottom:16px;
  position:sticky;
  top:24px;
}
#order-standard_cart #orderSummary .order-summary h2{
  font-family:'Barlow Condensed',sans-serif;
  font-size:26px;
  font-weight:900;
  letter-spacing:-.01em;
  color:var(--vc-text);
  margin-bottom:16px;
  line-height:1;
}

/* ── CONTINUE BUTTON ── */
#order-standard_cart #btnCompleteProductConfig{
  display:inline-flex;
  align-items:center;
  gap:10px;
  padding:16px 40px;
  background:var(--vc-accent);
  color:#fff !important;
  border:none;
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:16px;
  font-weight:700;
  box-shadow:var(--vc-shadow-green);
  transition:.22s ease;
  cursor:pointer;
  width:100%;
  justify-content:center;
}
#order-standard_cart #btnCompleteProductConfig:hover{
  background:var(--vc-accent-dark);
  transform:translateY(-2px);
  box-shadow:0 10px 32px rgba(34,160,74,.32);
}

/* ── RESPONSIVE ── */
@media(max-width:767px){
  #order-standard_cart #orderSummary .order-summary{position:static;}
  #order-standard_cart .secondary-cart-sidebar{margin-top:24px;}
}

/* Hide billing cycle everywhere */
#order-standard_cart label[for="inputBillingcycle"],
#order-standard_cart #inputBillingcycle,
#order-standard_cart #inputBillingcycle.closest,
#order-standard_cart .field-container:has(#inputBillingcycle) {
  display: none !important;
}

@media (max-width: 767px) {
  .mobile-categories-actions-hide {
    display: none !important;
  }
}

/* Hide Categories & Actions on mobile */
@media (max-width: 767px) {
  #order-standard_cart .cart-sidebar,
  #order-standard_cart .sidebar-categories-collapsed,
  #order-standard_cart .categories-collapsed,
  #order-standard_cart .secondary-cart-body > .panel,
  #order-standard_cart .secondary-cart-body > .panel-default,
  #order-standard_cart .secondary-cart-body > .card,
  #order-standard_cart .panel-sidebar,
  #order-standard_cart .panel-sidebar-categories,
  #order-standard_cart .panel-sidebar-actions {
    display: none !important;
  }
}

@media (max-width: 767px) {
  #order-standard_cart .additional-info-heading {
    margin: 34px 0 8px !important;
    padding-top: 8px !important;
  }

  #order-standard_cart .additional-info-heading .primary-bg-color {
    border-bottom: none !important;
    padding-bottom: 0 !important;
    font-size: 18px !important;
    line-height: 1.05 !important;
    text-align: center !important;
  }

  #order-standard_cart .additional-info-heading .additional-info-required {
    display: block !important;
    font-family: 'Outfit', sans-serif !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    line-height: 1.3 !important;
    margin-top: 5px !important;
    margin-bottom: 12px !important;
    text-align: center !important;
  }

  #order-standard_cart .field-container {
    padding-top: 22px !important;
  }
} 

#order-standard_cart .additional-info-box {
  padding-top: 18px !important;
}

#order-standard_cart .additional-info-title {
  font-family: 'Barlow Condensed', sans-serif !important;
  font-size: 22px !important;
  font-weight: 800 !important;
  line-height: 1.1 !important;
  text-align: center !important;
  margin-bottom: 4px !important;
  color: var(--vc-text) !important;
}

#order-standard_cart .additional-info-required {
  font-family: 'Outfit', sans-serif !important;
  font-size: 11px !important;
  font-weight: 700 !important;
  line-height: 1.3 !important;
  text-align: center !important;
  margin-bottom: 14px !important;
  color: var(--vc-text) !important;
}

@media (max-width: 767px) {
  #order-standard_cart .additional-info-title {
    font-size: 20px !important;
  }

  #order-standard_cart .additional-info-required {
    margin-bottom: 16px !important;
  }
}

@media (min-width: 768px) {
  #order-standard_cart .row {
    align-items: flex-start !important;
  }
  /* The "Configure your desired options..." subtitle is hoisted above
     the .row (out of the left column) so both columns share the same
     top edge. No margin-top fudge needed here. */
}
/* Style the hoisted subtitle to match its previous appearance — small
   muted intro line between the page heading and the column grid. */
#order-standard_cart .kf-configure-subtitle{
  margin:0 0 24px;
  color:var(--vc-muted);
  font-size:14px;
}

/* ── CART NOTICE BOX (inline so it always works) ── */
html body .kf-cart-notice{
  display:block !important;
  flex-direction:column !important;
  padding:16px 22px !important;
  margin:0 0 16px !important;
  border-radius:10px !important;
  border:1px solid var(--vc-border) !important;
  background:var(--vc-surface2) !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  line-height:1.5 !important;
  text-align:center !important;
  width:100% !important;
}
html body .kf-cart-notice > .kf-cart-notice-title{
  display:flex !important;
  flex-direction:row !important;
  align-items:center !important;
  justify-content:center !important;
  gap:12px !important;
  width:100% !important;
  flex-basis:100% !important;
  font-family:'Barlow Condensed','Outfit',sans-serif !important;
  font-weight:800 !important;
  font-size:18px !important;line-height:1.1 !important;
  letter-spacing:.02em !important;
  text-transform:uppercase !important;
  margin:0 !important;
}
html body .kf-cart-notice > .kf-cart-notice-title > i{font-size:16px !important;line-height:1 !important;flex:0 0 auto !important;}
html body .kf-cart-notice > .kf-cart-notice-body{
  display:block !important;
  width:100% !important;
  flex-basis:100% !important;
  text-align:center !important;
  margin:0 !important;
  clear:both !important;
}
.kf-cart-notice a,.kf-cart-notice .alert-link{font-weight:700;text-decoration:underline;}
.kf-cart-notice-success{background:var(--vc-accent-bg) !important;border-color:var(--vc-accent-border) !important;color:var(--vc-accent-dark);}
.kf-cart-notice-success .kf-cart-notice-title{color:var(--vc-accent);}
.kf-cart-notice-info{background:rgba(26,111,255,.06) !important;border-color:rgba(26,111,255,.2) !important;color:#1a4fff;}
.kf-cart-notice-info .kf-cart-notice-title{color:#1a4fff;}
.kf-cart-notice-warning{background:rgba(245,158,11,.07) !important;border-color:rgba(245,158,11,.25) !important;color:#92400e;}
.kf-cart-notice-warning .kf-cart-notice-title{color:#d97706;}
.kf-cart-notice-danger{background:rgba(204,40,40,.06) !important;border-color:rgba(204,40,40,.2) !important;color:var(--vc-danger);}
.kf-cart-notice-danger .kf-cart-notice-title{color:var(--vc-danger);}

/* (Earlier .total-due-today flatten removed — now defined once in the
   main order-summary block at the top of this style block, matching
   viewcart.tpl. Old version added a top border that the user flagged
   as a "straggler" horizontal line.) */
</style>
{/literal}
<script>
var _localLang = {
    'addToCart': '{$LANG.orderForm.addToCart|escape}',
    'addedToCartRemove': '{$LANG.orderForm.addedToCartRemove|escape}'
}
</script>

<div id="order-standard_cart">
    <div class="row">
        <div class="cart-sidebar">
            {include file="orderforms/$carttpl/sidebar-categories.tpl"}
        </div>
        <div class="cart-body">
            <div class="header-lined">
                <h1 class="font-size-36">{$LANG.orderconfigure}</h1>
            </div>

            <div class="mobile-categories-actions-hide">
    {include file="orderforms/$carttpl/sidebar-categories-collapsed.tpl"}
</div>

            <form id="frmConfigureProduct">
                <input type="hidden" name="configure" value="true" />
                <input type="hidden" name="i" value="{$i}" />

                {* Subtitle paragraph hoisted OUT of .secondary-cart-body and into
                   the .cart-body / above-the-row area so it sits ABOVE both columns.
                   Previously it lived inside the LEFT column, which pushed the product
                   card down by ~24px while the RIGHT column (order summary) started
                   immediately at the top — creating a misaligned-tops look that no
                   amount of fudged margin-top could solve reliably on different
                   viewports / font sizes. *}
                <p class="kf-configure-subtitle">{$LANG.orderForm.configureDesiredOptions}</p>

                <div class="row">
                    <div class="secondary-cart-body">

                        <div class="product-info">
                            <p class="product-title">{$productinfo.name}</p>
                            <p>{$productinfo.description}</p>
                        </div>

                        <div class="alert alert-danger w-hidden" role="alert" id="containerProductValidationErrors">
                            <p>{$LANG.orderForm.correctErrors}:</p>
                            <ul id="containerProductValidationErrorsList"></ul>
                        </div>

                        {if $pricing.type eq "recurring"}
                            <div class="field-container">
                                <div class="form-group">
                                    <label for="inputBillingcycle">{$LANG.cartchoosecycle}</label>
                                    <select name="billingcycle" id="inputBillingcycle" class="form-control select-inline custom-select" onchange="updateConfigurableOptions({$i}, this.value); return false">
                                        {if $pricing.monthly}<option value="monthly"{if $billingcycle eq "monthly"} selected{/if}>{$pricing.monthly}</option>{/if}
                                        {if $pricing.quarterly}<option value="quarterly"{if $billingcycle eq "quarterly"} selected{/if}>{$pricing.quarterly}</option>{/if}
                                        {if $pricing.semiannually}<option value="semiannually"{if $billingcycle eq "semiannually"} selected{/if}>{$pricing.semiannually}</option>{/if}
                                        {if $pricing.annually}<option value="annually"{if $billingcycle eq "annually"} selected{/if}>{$pricing.annually}</option>{/if}
                                        {if $pricing.biennially}<option value="biennially"{if $billingcycle eq "biennially"} selected{/if}>{$pricing.biennially}</option>{/if}
                                        {if $pricing.triennially}<option value="triennially"{if $billingcycle eq "triennially"} selected{/if}>{$pricing.triennially}</option>{/if}
                                    </select>
                                </div>
                            </div>
                        {/if}

                        {if count($metrics) > 0}
                            <div class="sub-heading">
                                <span class="primary-bg-color">{$LANG.metrics.title}</span>
                            </div>
                            <p>{$LANG.metrics.explanation}</p>
                            <ul>
                                {foreach $metrics as $metric}
                                    <li>
                                        {$metric.displayName} -
                                        {if count($metric.pricing) > 1}
                                            {$LANG.metrics.startingFrom} {$metric.lowestPrice} / {if $metric.unitName}{$metric.unitName}{else}{$LANG.metrics.unit}{/if}
                                            <button type="button" class="btn btn-default btn-sm" data-toggle="modal" data-target="#modalMetricPricing-{$metric.systemName}">{$LANG.metrics.viewPricing}</button>
                                        {elseif count($metric.pricing) == 1}
                                            {$metric.lowestPrice} / {if $metric.unitName}{$metric.unitName}{else}{$LANG.metrics.unit}{/if}
                                            {if $metric.includedQuantity > 0} ({$metric.includedQuantity} {$LANG.metrics.includedNotCounted}){/if}
                                        {/if}
                                        {include file="$template/usagebillingpricing.tpl"}
                                    </li>
                                {/foreach}
                            </ul><br>
                        {/if}

                        {if $productinfo.type eq "server"}
                            <div class="sub-heading">
                                <span class="primary-bg-color">{$LANG.cartconfigserver}</span>
                            </div>
                            <div class="field-container">
                                <div class="row">
                                    <div class="col-sm-6"><div class="form-group"><label for="inputHostname">{$LANG.serverhostname}</label><input type="text" name="hostname" class="form-control" id="inputHostname" value="{$server.hostname}" placeholder="servername.example.com"></div></div>
                                    <div class="col-sm-6"><div class="form-group"><label for="inputRootpw">{$LANG.serverrootpw}</label><input type="password" name="rootpw" class="form-control" id="inputRootpw" value="{$server.rootpw}"></div></div>
                                    <div class="col-sm-6"><div class="form-group"><label for="inputNs1prefix">{$LANG.serverns1prefix}</label><input type="text" name="ns1prefix" class="form-control" id="inputNs1prefix" value="{$server.ns1prefix}" placeholder="ns1"></div></div>
                                    <div class="col-sm-6"><div class="form-group"><label for="inputNs2prefix">{$LANG.serverns2prefix}</label><input type="text" name="ns2prefix" class="form-control" id="inputNs2prefix" value="{$server.ns2prefix}" placeholder="ns2"></div></div>
                                </div>
                            </div>
                        {/if}

                        {if $configurableoptions}
                            <div class="sub-heading">
                                <span class="primary-bg-color">{$LANG.orderconfigpackage}</span>
                            </div>
                            <div class="product-configurable-options" id="productConfigurableOptions">
                                <div class="row">
                                    {foreach $configurableoptions as $num => $configoption}
                                    {if $configoption.optiontype eq 1}
                                        <div class="col-sm-6"><div class="form-group"><label for="inputConfigOption{$configoption.id}">{$configoption.optionname}</label><select name="configoption[{$configoption.id}]" id="inputConfigOption{$configoption.id}" class="form-control">{foreach key=num2 item=options from=$configoption.options}<option value="{$options.id}"{if $configoption.selectedvalue eq $options.id} selected="selected"{/if}>{$options.name}</option>{/foreach}</select></div></div>
                                    {elseif $configoption.optiontype eq 2}
                                        <div class="col-sm-6"><div class="form-group"><label for="inputConfigOption{$configoption.id}">{$configoption.optionname}</label>{foreach key=num2 item=options from=$configoption.options}<br /><label><input type="radio" name="configoption[{$configoption.id}]" value="{$options.id}"{if $configoption.selectedvalue eq $options.id} checked="checked"{/if} />{if $options.name}{$options.name}{else}{$LANG.enable}{/if}</label>{/foreach}</div></div>
                                    {elseif $configoption.optiontype eq 3}
                                        <div class="col-sm-6"><div class="form-group"><label for="inputConfigOption{$configoption.id}">{$configoption.optionname}</label><br /><label><input type="checkbox" name="configoption[{$configoption.id}]" id="inputConfigOption{$configoption.id}" value="1"{if $configoption.selectedqty} checked{/if} />{if $configoption.options.0.name}{$configoption.options.0.name}{else}{$LANG.enable}{/if}</label></div></div>
                                    {elseif $configoption.optiontype eq 4}
                                        <div class="col-sm-12"><div class="form-group"><label for="inputConfigOption{$configoption.id}">{$configoption.optionname}</label>
                                            {if $configoption.qtymaximum}
                                                {if !$rangesliderincluded}<script type="text/javascript" src="{$BASE_PATH_JS}/ion.rangeSlider.min.js"></script><link href="{$BASE_PATH_CSS}/ion.rangeSlider.css" rel="stylesheet"><link href="{$BASE_PATH_CSS}/ion.rangeSlider.skinModern.css" rel="stylesheet">{assign var='rangesliderincluded' value=true}{/if}
                                                <input type="text" name="configoption[{$configoption.id}]" value="{if $configoption.selectedqty}{$configoption.selectedqty}{else}{$configoption.qtyminimum}{/if}" id="inputConfigOption{$configoption.id}" class="form-control" />
                                                <script>
{literal}
var sliderTimeoutId = null;
{/literal}

var sliderRangeDifference = {$configoption.qtymaximum} - {$configoption.qtyminimum};

{literal}
var sliderStepThreshold = 25;
var setLargerMarkers = sliderRangeDifference > sliderStepThreshold;

jQuery("{/literal}#inputConfigOption{$configoption.id}{literal}").ionRangeSlider({
    min: {/literal}{$configoption.qtyminimum}{literal},
    max: {/literal}{$configoption.qtymaximum}{literal},
    grid: true,
    grid_snap: setLargerMarkers ? false : true,
    onChange: function() {
        if (sliderTimeoutId) {
            clearTimeout(sliderTimeoutId);
        }

        sliderTimeoutId = setTimeout(function() {
            sliderTimeoutId = null;
            recalctotals();
        }, 250);
    }
});
{/literal}
</script>
                                            {else}
                                                <div><input type="number" name="configoption[{$configoption.id}]" value="{if $configoption.selectedqty}{$configoption.selectedqty}{else}{$configoption.qtyminimum}{/if}" id="inputConfigOption{$configoption.id}" min="{$configoption.qtyminimum}" onchange="recalctotals()" onkeyup="recalctotals()" class="form-control form-control-qty" /><span class="form-control-static form-control-static-inline">x {$configoption.options.0.name}</span></div>
                                            {/if}
                                        </div></div>
                                    {/if}
                                    {if $num % 2 != 0}</div><div class="row">{/if}
                                    {/foreach}
                                </div>
                            </div>
                        {/if}

                        {if $customfields}
    <div class="field-container additional-info-box">
        <div class="additional-info-title">{$LANG.orderadditionalrequiredinfo}</div>
        <div class="additional-info-required">{lang key='orderForm.requiredField'}</div>

        {foreach $customfields as $customfield}
            <div class="form-group">
                <label for="customfield{$customfield.id}">{$customfield.name} {$customfield.required}</label>
                {$customfield.input}
                {if $customfield.description}<span class="field-help-text">{$customfield.description}</span>{/if}
            </div>
        {/foreach}
    </div>
{/if}

                        {if $addons || count($addonsPromoOutput) > 0}
                            <div id="productAddonsContainer">
                                <div class="sub-heading">
                                    <span class="primary-bg-color">{$LANG.cartavailableaddons}</span>
                                </div>
                                {foreach $addonsPromoOutput as $output}<div>{$output}</div>{/foreach}
                                <div class="row addon-products">
                                    {foreach $addons as $addon}
                                        <div class="col-sm-{if count($addons) > 1}6{else}12{/if}">
                                            <div class="panel card panel-default panel-addon{if $addon.status} panel-addon-selected{/if}">
                                                <div class="panel-body card-body">
                                                    <label><input type="checkbox" name="addons[{$addon.id}]"{if $addon.status} checked{/if} />{$addon.name}</label><br />
                                                    {$addon.description}
                                                </div>
                                                <div class="panel-price">{$addon.pricing}</div>
                                                <div class="panel-add"><i class="fas fa-plus"></i> {$LANG.addtocart}</div>
                                            </div>
                                        </div>
                                    {/foreach}
                                </div>
                            </div>
                        {/if}

                        {* Cart/Checkout — Configure Product notice (kwickflixstyle → Cart/Checkout tab).
                           Rendering rules:
                           - Title row only shows when title is set, with icons flanking it
                           - Icons NEVER render without a title
                           - Body is always centered when present, renders HTML (nofilter)
                           - Empty body + no title = nothing renders even if enabled *}
                        {if isset($kf_cart_notice_cp_enabled) && $kf_cart_notice_cp_enabled && ($kf_cart_notice_cp_title || $kf_cart_notice_cp_html)}
                            <div class="kf-cart-notice kf-cart-notice-{$kf_cart_notice_cp_severity}">
                                {if $kf_cart_notice_cp_title}
                                    <div class="kf-cart-notice-title">
                                        {if $kf_cart_notice_cp_icon}<i class="{$kf_cart_notice_cp_icon}"></i>{/if}
                                        <span>{$kf_cart_notice_cp_title}</span>
                                        {if $kf_cart_notice_cp_icon}<i class="{$kf_cart_notice_cp_icon}"></i>{/if}
                                    </div>
                                {/if}
                                {if $kf_cart_notice_cp_html}
                                    <div class="kf-cart-notice-body">{$kf_cart_notice_cp_html|escape:"none" nofilter}</div>
                                {/if}
                            </div>
                        {/if}

                    </div>
                    <div class="secondary-cart-sidebar" id="scrollingPanelContainer">
                        <div id="orderSummary">
                            <div class="order-summary">
                                <div class="loader" id="orderSummaryLoader">
                                    <i class="fas fa-fw fa-sync fa-spin"></i>
                                </div>
                                <h2 class="font-size-30">{$LANG.ordersummary}</h2>
                                <div class="summary-container" id="producttotal"></div>
                            </div>
                            <div class="text-center">
                                <button type="submit" id="btnCompleteProductConfig" class="btn btn-primary btn-lg">
                                    {$LANG.continue} <i class="fas fa-arrow-circle-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>

{literal}
<script>
jQuery(document).ready(function() {
    recalctotals();
});
</script>
{/literal}
{include file="orderforms/$carttpl/recommendations-modal.tpl"}
