<link rel="stylesheet" type="text/css" href="{assetPath file='all.min.css'}?v={$versionHash}" />
{assetExists file="custom.css"}
<link rel="stylesheet" type="text/css" href="{$__assetPath__}?v={$versionHash}" />
{/assetExists}
{* KwickFlix bridge — must load AFTER style.css to win source order
   when remapping --vc-* tokens to the kwickflix --ca-* tokens that
   the main template emits via $kf_dynamic_css. *}
<link rel="stylesheet" type="text/css" href="{assetPath file='kwickflix.css'}?v={$versionHash}" />
<script type="text/javascript" src="{assetPath file='scripts.min.js'}?v={$versionHash}"></script>