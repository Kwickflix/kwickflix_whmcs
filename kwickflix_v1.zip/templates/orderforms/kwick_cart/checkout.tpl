{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ── WHMCS WRAPPER STRIP ── */
.panel,.panel-default,.panel-body,.portlet,.portlet-body,
.card,.card-body,.content-container,.content-panel{
  background:transparent !important;
  border:none !important;
  box-shadow:none !important;
}

:root{
  --vc-surface:#fefdfb;
  --vc-surface2:#f7f5f0;
  --vc-surface3:#ede9e2;
  --vc-border:#d8d3cc;
  --vc-border2:#bfb8ae;
  --vc-text:#13110e;
  --vc-muted:#7a7268;
  --vc-muted2:#5a5249;
  --vc-accent:#22a04a;
  --vc-accent-dark:#167a36;
  --vc-accent-bg:rgba(34,160,74,.07);
  --vc-accent-border:rgba(34,160,74,.18);
  --vc-danger:#cc2828;
  --vc-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --vc-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
  --vc-shadow-green:0 6px 24px rgba(34,160,74,.25),0 2px 8px rgba(34,160,74,.12);
}

/* ── CART MARQUEE (inline so it works even if the bridge CSS file isn't loaded) ── */
.kf-cart-marquee{
  overflow:hidden;width:100%;margin:0 0 20px;
  -webkit-mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);
          mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);
}
.kf-cart-marquee-track{
  display:flex;align-items:center;gap:60px;width:max-content;padding-right:60px;
  animation:kfCartMarqueeScroll calc(35s / var(--kf-cart-mq-speed, 1)) linear infinite;
}
.kf-cart-marquee-item{flex-shrink:0;display:flex;align-items:center;transition:opacity .2s ease, filter .2s ease;}
.kf-cart-marquee-item img{height:52px;width:auto;object-fit:contain;opacity:.85;}
@keyframes kfCartMarqueeScroll{from{transform:translateX(0);}to{transform:translateX(-50%);}}
.kf-cart-marquee.kf-cart-marquee-greyscale .kf-cart-marquee-item{opacity:.4;filter:grayscale(1);}
.kf-cart-marquee.kf-cart-marquee-greyscale .kf-cart-marquee-item:hover{opacity:.9;filter:grayscale(0);}

/* ── HIDE SIDEBAR, CENTER LAYOUT ── */
#order-standard_cart .cart-sidebar{display:none !important;}

#order-standard_cart .sidebar-categories-collapsed,
#order-standard_cart .nav-tabs,
#order-standard_cart .tab-content{
  display:none !important;
  border:none !important;
  background:transparent !important;
  box-shadow:none !important;
}

#order-standard_cart .cart-body{
  width:100% !important;
  max-width:860px;
  margin:0 auto;
  float:none !important;
}

/* ── CART WRAPPER ── */
#order-standard_cart{
  font-family:'Outfit',sans-serif;
  color:var(--vc-text);
  max-width:1100px;
  margin:0 auto;
  padding:0 0 60px;
}

/* ── PAGE TITLE ── */
#order-standard_cart .header-lined{
  margin-bottom:28px;
  padding-bottom:20px;
  border-bottom:1px solid var(--vc-border);
}
#order-standard_cart .header-lined h1{
  font-family:'Barlow Condensed',sans-serif;
  font-size:clamp(36px,6vw,56px);
  font-weight:900;
  letter-spacing:-.02em;
  line-height:1;
  color:var(--vc-text);
}

/* ── ALERTS ── */
#order-standard_cart .alert{
  border-radius:10px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  padding:14px 18px;
  margin-bottom:18px;
  border:1px solid var(--vc-border);
}
#order-standard_cart .alert-danger{background:rgba(204,40,40,.06);border-color:rgba(204,40,40,.2);color:var(--vc-danger);}
#order-standard_cart .alert-info{background:rgba(26,111,255,.06);border-color:rgba(26,111,255,.2);color:#1a4fff;}
#order-standard_cart .alert-warning{background:rgba(245,158,11,.07);border-color:rgba(245,158,11,.25);color:#92400e;}
#order-standard_cart .alert-success{
  background:var(--vc-accent-bg);
  border-color:var(--vc-accent-border);
  color:var(--vc-accent-dark);
}

/* total due today box */
#order-standard_cart #totalDueToday{
  background:var(--vc-accent-bg) !important;
  border:1px solid var(--vc-accent-border) !important;
  color:var(--vc-accent-dark) !important;
  border-radius:10px !important;
  padding:16px 24px !important;
  font-size:16px !important;
  font-weight:600 !important;
  margin:20px 0 !important;
}
#order-standard_cart #totalDueToday{
  display:flex !important;
  align-items:center;
  justify-content:center;
  gap:8px;
  flex-wrap:wrap;
}

#order-standard_cart #totalDueToday strong{
  font-family:'Barlow Condensed',sans-serif;
  font-size:32px;
  font-weight:900;
  color:var(--vc-accent);
  letter-spacing:-.01em;
  margin:0;
}

/* ── SUB HEADINGS — total WHMCS twenty-one override ── */
#order-standard_cart .sub-heading{
  margin:24px 0 16px !important;
  padding:0 !important;
  background:transparent !important;
  background-image:none !important;
  border-top:none !important;
  border-left:none !important;
  border-right:none !important;
  border-bottom:none !important;
  box-shadow:none !important;
  overflow:visible !important;
}
#order-standard_cart .sub-heading > *,
#order-standard_cart .sub-heading h1,
#order-standard_cart .sub-heading h2,
#order-standard_cart .sub-heading h3,
#order-standard_cart .sub-heading h4,
#order-standard_cart .sub-heading span{
  background:transparent !important;
  background-image:none !important;
  border:none !important;
  box-shadow:none !important;
}
#order-standard_cart .sub-heading::before,
#order-standard_cart .sub-heading::after{
  display:none !important;
  content:none !important;
}
#order-standard_cart .sub-heading > *::before,
#order-standard_cart .sub-heading > *::after,
#order-standard_cart .sub-heading span::before,
#order-standard_cart .sub-heading span::after,
#order-standard_cart .sub-heading .primary-bg-color::before,
#order-standard_cart .sub-heading .primary-bg-color::after{
  display:none !important;
  content:none !important;
  width:0 !important;
  height:0 !important;
  background:none !important;
  border:none !important;
  position:static !important;
}
#order-standard_cart .sub-heading .primary-bg-color{
  display:block !important;
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:20px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--vc-text) !important;
  padding:0 0 10px 0 !important;
  border-bottom:none !important;
  line-height:1.2 !important;
  width:100%;
}

/* ── FORM INPUTS ── */
#order-standard_cart .form-control,
#order-standard_cart .field{
  border:1.5px solid var(--vc-border) !important;
  border-radius:8px !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  padding:10px 14px !important;
  background:var(--vc-surface) !important;
  color:var(--vc-text) !important;
  transition:.15s ease !important;
  height:auto !important;
}
#order-standard_cart .form-control:focus,
#order-standard_cart .field:focus{
  border-color:var(--vc-accent) !important;
  box-shadow:0 0 0 3px var(--vc-accent-bg) !important;
  outline:none !important;
}
#order-standard_cart .prepend-icon .form-control,
#order-standard_cart .prepend-icon .field{
  padding-left:40px !important;
}
#order-standard_cart .prepend-icon .field-icon{
  color:var(--vc-muted);
}

/* ── BUTTONS ── */
#order-standard_cart .btn-default{
  background:var(--vc-surface2);
  border:1.5px solid var(--vc-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  color:var(--vc-text);
  padding:10px 20px;
  transition:.18s ease;
}
#order-standard_cart .btn-default:hover{
  background:var(--vc-surface3);
  border-color:var(--vc-border2);
}

#order-standard_cart .btn-info{
  background:#1a6fff;border:none;border-radius:8px;
  font-family:'Outfit',sans-serif;font-weight:600;font-size:14px;
  padding:10px 20px;transition:.18s ease;
}

#order-standard_cart .btn-warning{
  background:#d97706;border:none;border-radius:8px;color:#fff;
  font-family:'Outfit',sans-serif;font-weight:600;font-size:14px;
  padding:10px 20px;transition:.18s ease;
}

/* complete order button */
#order-standard_cart #btnCompleteOrder{
  display:inline-flex;
  align-items:center;
  gap:10px;
  padding:18px 52px;
  background:var(--vc-accent);
  color:#fff !important;
  border:none;
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:17px;
  font-weight:700;
  text-decoration:none;
  box-shadow:var(--vc-shadow-green);
  transition:.22s ease;
  cursor:pointer;
}
#order-standard_cart #btnCompleteOrder:hover:not([disabled]){
  background:var(--vc-accent-dark);
  transform:translateY(-2px);
  box-shadow:0 10px 32px rgba(34,160,74,.32);
}
#order-standard_cart #btnCompleteOrder[disabled]{opacity:.5;cursor:not-allowed;}

/* ── ALREADY REGISTERED ROW ── */
#order-standard_cart .already-registered{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:10px;
  padding:14px 18px;
  margin-bottom:24px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:16px;
  flex-wrap:wrap;
  box-shadow:var(--vc-shadow-sm);
}
#order-standard_cart .already-registered p{
  margin:0;
  font-size:14px;
  color:var(--vc-muted);
}

/* ── ACCOUNT SELECT CARDS ── */
#order-standard_cart #containerExistingAccountSelect{
  background:var(--vc-surface) !important;
  border:1.5px solid var(--vc-border) !important;
  border-radius:14px !important;
  padding:14px !important;
  margin:0 0 24px 0 !important;
  width:100% !important;
  display:block !important;
  box-shadow:var(--vc-shadow-md) !important;
  overflow:hidden !important;
  box-sizing:border-box !important;
}

#order-standard_cart #containerExistingAccountSelect > [class*="col"]{
  width:100% !important;
  max-width:100% !important;
  flex:0 0 100% !important;
  padding:0 !important;
  margin:0 0 10px 0 !important;
  background:transparent !important;
}

#order-standard_cart #containerExistingAccountSelect > [class*="col"]:last-child{
  margin-bottom:0 !important;
}

#order-standard_cart .account{
  background:var(--vc-surface) !important;
  border:1.5px solid var(--vc-border) !important;
  border-radius:10px !important;
  padding:14px 16px !important;
  margin:0 !important;
  transition:.15s ease !important;
  box-shadow:none !important;
  width:100% !important;
  box-sizing:border-box !important;
}
#order-standard_cart .account.active,
#order-standard_cart .account:has(input:checked){
  border-color:var(--vc-accent) !important;
  background:var(--vc-surface) !important;
}
#order-standard_cart .account.border-bottom{
  border-bottom:1.5px solid var(--vc-border) !important;
}
#order-standard_cart .account label{
  cursor:pointer;
  margin:0 !important;
  width:100% !important;
  max-width:100% !important;
  display:flex !important;
  align-items:center !important;
  gap:10px !important;
  overflow:hidden !important;
}

#order-standard_cart .account .address,
#order-standard_cart .account .small{
  max-width:100% !important;
  overflow:hidden !important;
  text-overflow:ellipsis !important;
  white-space:nowrap !important;
  display:block !important;
}

/* ── PASSWORD STRENGTH ── */
#order-standard_cart .password-strength-meter .progress{
  border-radius:6px;
  height:8px;
  background:var(--vc-surface3);
  border:1px solid var(--vc-border);
}
#order-standard_cart #passwordStrengthTextLabel{
  font-size:12px;
  color:var(--vc-muted);
  margin-top:4px;
}
#order-standard_cart .btn.generate-password{
  font-size:13px;
  font-weight:600;
  color:var(--vc-accent);
  border-color:var(--vc-accent-border);
  background:var(--vc-accent-bg);
  border-radius:6px;
  padding:6px 14px;
}

/* ── CREDIT APPLY ── */
#order-standard_cart .apply-credit-container{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:10px;
  padding:16px 18px;
  margin-bottom:20px;
  font-size:14px;
  color:var(--vc-muted);
}

/* ── PAYMENT METHODS BOX ── */
.kf-payment-box{
  background:var(--vc-surface) !important;
  border:1.5px solid var(--vc-border) !important;
  border-radius:14px !important;
  margin:0 0 20px !important;
  box-shadow:var(--vc-shadow-md) !important;
  overflow:hidden !important;
}
.kf-payment-box-header{
  background:var(--vc-surface2) !important;
  border-bottom:1px solid var(--vc-border) !important;
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:18px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--vc-text) !important;
  padding:16px 20px !important;
  text-align:left !important;
}
/* single-column list — no grid border mess. The padding gives each
   card breathing room from the .kf-payment-box rounded corners and
   stops the first card's radio button from being clipped by the
   container's overflow:hidden. */
/* single-column list — no grid border mess. Spacing between cards
   uses explicit margin-bottom (not flex `gap`) because `gap` interacts
   inconsistently with children that have overflow:hidden + absolutely-
   positioned descendants (the preferred ribbon scenario was causing
   uneven visual spacing). Padding gives breathing room from the
   .kf-payment-box rounded corners and stops the first card's radio
   from being clipped by the container's overflow:hidden. */
.kf-payment-methods{
  display:flex !important;
  flex-direction:column !important;
  padding:12px !important;
}
.kf-payment-method{
  border:1px solid var(--vc-border) !important;
  border-radius:10px !important;
  background:var(--vc-surface) !important;
  transition:.18s ease !important;
  position:relative !important;
  margin:0 0 14px 0 !important;
  box-sizing:border-box !important;
}
.kf-payment-method:last-child{
  margin-bottom:0 !important;
}
.kf-payment-method:hover{background:var(--vc-surface2) !important;}
/* Selected state — hairline accent border + soft inset glow halo.
   Cascade priority for the color values:
     1. Per-row override via inline style="--kf-pmt-row-accent:…"
        (admin set "Border / Glow Color" on this gateway in the addon)
     2. Master accent (--vc-accent) as a fallback when no per-row override
   The border itself is just 1px so the line stays as thin as possible
   while the inset glow gives the "selected" visual punch. */
.kf-payment-method:has(input:checked){
  background:var(--vc-accent-bg) !important;
  border-color:var(--kf-pmt-row-accent, var(--vc-accent)) !important;
  box-shadow:inset 0 0 14px 1px var(--kf-pmt-row-glow, var(--vc-accent-border)) !important;
}
/* PREFERRED + selected — overrides the regular selected styling with
   a warm gold border + glow. Premium treatment for the gateway the
   admin marked preferred. Specificity beats the rule above because
   .kf-payment-method.kf-payment-method-preferred chains two classes.
   The per-row accent picker is intentionally ignored here — preferred
   ALWAYS uses the section-level Preferred Border/Glow color (default
   rich gold). The ribbon color picker applies separately. */
.kf-payment-method.kf-payment-method-preferred:has(input:checked){
  background:rgba(253,200,88,.07) !important;
  border-color:var(--kf-pmt-preferred, #d97706) !important;
  box-shadow:inset 0 0 16px 1px var(--kf-pmt-preferred-glow, rgba(217,119,6,.28)) !important;
}

/* ── PREFERRED RIBBON (corner banner) ──
   Top-right corner ribbon shown when admin marks a gateway as "Preferred"
   in the kwickflixstyle addon (Cart/Checkout → Payment Gateways). Uses
   transform:rotate to angle the ribbon diagonally. overflow:hidden on
   the parent .kf-payment-method-preferred clips the rotated ribbon
   ends to the rounded card corners. The radio button has 18px of
   left-padding inside its label so the clip doesn't reach it. */
.kf-payment-method-preferred{
  overflow:hidden !important;
}
.kf-payment-method-ribbon{
  position:absolute !important;
  top:14px !important;
  right:-36px !important;
  transform:rotate(35deg) !important;
  background:var(--kf-pmt-ribbon, linear-gradient(135deg,#fff7df 0%,#fdc858 50%,#e69400 100%)) !important;
  color:#6b3a00 !important;
  font-family:'Barlow Condensed',sans-serif !important;
  font-weight:800 !important;
  font-size:10px !important;
  letter-spacing:.08em !important;
  text-transform:uppercase !important;
  padding:3px 40px !important;
  z-index:2 !important;
  box-shadow:0 2px 4px rgba(0,0,0,.18) !important;
  pointer-events:none !important;
  white-space:nowrap !important;
}

/* ── EMPTY STATE — no payment options available ──
   Shown when the admin hasn't configured any payment-gateway rows in
   the kwickflixstyle addon (or none of the configured rows match a
   currently-active WHMCS gateway). Soft warning palette, centered. */
.kf-payment-empty{
  display:flex !important;
  flex-direction:column !important;
  align-items:center !important;
  justify-content:center !important;
  gap:6px !important;
  padding:32px 24px !important;
  text-align:center !important;
  color:var(--vc-muted2) !important;
  font-family:'Outfit',sans-serif !important;
}
.kf-payment-empty i{
  font-size:32px !important;
  color:var(--vc-muted) !important;
  margin-bottom:8px !important;
}
.kf-payment-empty strong{
  font-family:'Barlow Condensed',sans-serif !important;
  font-weight:800 !important;
  font-size:17px !important;
  letter-spacing:.02em !important;
  text-transform:uppercase !important;
  color:var(--vc-text) !important;
}
.kf-payment-empty span{
  font-size:13px !important;
  max-width:360px !important;
  line-height:1.5 !important;
}

/* ── DEFENSIVE: ensure WHMCS modals stay hidden ──
   The checkout page includes several Bootstrap modal dialogs (recommendations,
   language picker, loading indicator, password strength, etc.) that should be
   hidden until JS activates them. Bootstrap normally handles this via
   `.modal { display: none }`, but a missing/cached/overridden Bootstrap CSS
   load can leave them rendering as visible blocks below the footer. This
   rule pins them shut regardless of what else is in the cascade. */
body .modal:not(.show){
  display:none !important;
}
.kf-payment-method label{
  padding:14px 18px !important;
  display:flex !important;
  align-items:center !important;
  gap:14px !important;
  cursor:pointer !important;
}
.kf-payment-method input[type="radio"]{
  flex-shrink:0;
  width:16px;height:16px;
  margin:0 !important;
  accent-color:var(--vc-accent);
}
.kf-payment-method-content{
  display:flex !important;
  align-items:center !important;
  gap:10px !important;
  flex:1;
}
.kf-payment-method-icon{
  font-size:20px;
  flex-shrink:0;
  line-height:1;
  width:24px;
  text-align:center;
}
.kf-payment-method-text{
  display:flex;
  flex-direction:column;
  gap:2px;
  flex:1;
  min-width:0;
}
.kf-payment-method-title{
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  font-weight:600 !important;
  color:var(--vc-text) !important;
  line-height:1.2;
}
.kf-payment-method-desc{
  font-size:12px !important;
  color:var(--vc-muted) !important;
  line-height:1.4;
  padding-left:0 !important;
}
.kf-payment-method-title{
  font-family:'Outfit',sans-serif !important;
  font-size:15px !important;
  font-weight:600 !important;
  color:var(--vc-text) !important;
}
.kf-payment-method-desc{
  font-size:12px !important;
  color:var(--vc-muted) !important;
}

/* (Dead rules removed: .kf-warning-bar, .kf-warning-title, .kf-warning-text,
   .checkout-security-msg, .kf-news-alert-amazon — the hardcoded boxes
   they targeted are gone now, replaced by the addon-driven .kf-cart-notice
   system.) */

/* ── CART NOTICE BOXES (inline so they always work) ── */
/* Specificity: `html body` prefix beats any conflicting rule that might
   try to set display:flex on this. The flex-direction:column failsafe
   means even if some other CSS DOES flip the container to flex, the
   children still stack vertically. The children get width:100% +
   flex-basis:100% so they always take full width regardless. */
html body .kf-cart-notice{
  display:block !important;
  flex-direction:column !important;
  padding:16px 22px !important;
  margin:0 0 16px !important;
  border-radius:10px !important;
  border:1px solid var(--vc-border) !important;
  background:var(--vc-surface2) !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  line-height:1.5 !important;
  text-align:center !important;
  width:100% !important;
}
html body .kf-cart-notice > .kf-cart-notice-title{
  display:flex !important;
  flex-direction:row !important;
  align-items:center !important;
  justify-content:center !important;
  gap:12px !important;
  width:100% !important;
  flex-basis:100% !important;
  font-family:'Barlow Condensed','Outfit',sans-serif !important;
  font-weight:800 !important;
  font-size:18px !important;line-height:1.1 !important;
  letter-spacing:.02em !important;
  text-transform:uppercase !important;
  margin:0 !important;
}
html body .kf-cart-notice > .kf-cart-notice-title > i{font-size:16px !important;line-height:1 !important;flex:0 0 auto !important;}
html body .kf-cart-notice > .kf-cart-notice-body{
  display:block !important;
  width:100% !important;
  flex-basis:100% !important;
  text-align:center !important;
  margin:0 !important;
  clear:both !important;
}
.kf-cart-notice a,.kf-cart-notice .alert-link{font-weight:700;text-decoration:underline;}
.kf-cart-notice-success{background:var(--vc-accent-bg) !important;border-color:var(--vc-accent-border) !important;color:var(--vc-accent-dark);}
.kf-cart-notice-success .kf-cart-notice-title{color:var(--vc-accent);}
.kf-cart-notice-info{background:rgba(26,111,255,.06) !important;border-color:rgba(26,111,255,.2) !important;color:#1a4fff;}
.kf-cart-notice-info .kf-cart-notice-title{color:#1a4fff;}
.kf-cart-notice-warning{background:rgba(245,158,11,.07) !important;border-color:rgba(245,158,11,.25) !important;color:#92400e;}
.kf-cart-notice-warning .kf-cart-notice-title{color:#d97706;}
.kf-cart-notice-danger{background:rgba(204,40,40,.06) !important;border-color:rgba(204,40,40,.2) !important;color:var(--vc-danger);}
.kf-cart-notice-danger .kf-cart-notice-title{color:var(--vc-danger);}

/* ── TOS CHECKBOX ── */
#order-standard_cart #accepttos{margin-right:8px;}
#order-standard_cart .text-center p label{
  font-size:14px;
  color:var(--vc-muted);
}
#order-standard_cart .text-center p label a{
  color:var(--vc-accent);
  text-decoration:underline;
}

/* ── CC INPUT FIELDS ── */
#order-standard_cart .cc-input-container{
  background:var(--vc-surface);
  border:1px solid var(--vc-border);
  border-radius:12px;
  padding:20px;
  margin-bottom:20px;
}

/* ── RESPONSIVE ── */
@media(max-width:767px){
  #order-standard_cart #btnCompleteOrder{
    width:100%;max-width:380px;padding:15px 24px;font-size:16px;justify-content:center;
  }
  .kf-payment-methods{grid-template-columns:1fr !important;}
  .kf-payment-method{border-right:none !important;}
}

.kf-checkout-box{
  background:var(--vc-surface) !important;
  border:1.5px solid var(--vc-border) !important;
  border-radius:14px !important;
  padding:20px !important;
  margin:0 0 24px !important;
  box-shadow:var(--vc-shadow-md) !important;
}

/* space between generate button and strength meter */
#order-standard_cart .btn.generate-password{
  margin-bottom:10px !important;
}

/* extra spacing for strength meter on mobile */
#order-standard_cart .password-strength-meter{
  margin-top:10px !important;
}

/* ── FIX: sub-heading layout — kill all positioning tricks ── */
#order-standard_cart .sub-heading {
  position: static !important;
  height: auto !important;
  min-height: 0 !important;
  overflow: visible !important;
}

#order-standard_cart .sub-heading .primary-bg-color {
  position: static !important;
  display: block !important;
  width: 100% !important;
  height: auto !important;
  min-height: 0 !important;
  font-family: 'Barlow Condensed', sans-serif !important;
  font-size: 20px !important;
  font-weight: 800 !important;
  letter-spacing: .02em !important;
  color: var(--vc-text) !important;
  padding: 0 0 10px 0 !important;
  line-height: 1.4 !important;
  white-space: normal !important;
  overflow: visible !important;
  background: transparent !important;
  background-image: none !important;
  border: none !important;
  box-shadow: none !important;
  transform: none !important;
  top: auto !important;
  left: auto !important;
  right: auto !important;
  bottom: auto !important;
}

#order-standard_cart .sub-heading .primary-bg-color i,
#order-standard_cart .sub-heading .primary-bg-color small {
  position: static !important;
  display: block !important;
  font-family: 'Outfit', sans-serif !important;
  font-size: 12px !important;
  font-weight: 400 !important;
  font-style: normal !important;
  color: var(--vc-muted) !important;
  letter-spacing: 0 !important;
  line-height: 1.5 !important;
  margin-top: 3px !important;
  transform: none !important;
}

</style>
{/literal}

{* Cart/Checkout — admin-picked SECTION-LEVEL colors for ribbon + the
   preferred-card border/glow. Lives OUTSIDE the {literal} block above
   so Smarty {$var} interpolation runs. The values become CSS custom
   properties scoped to #order-standard_cart; the rules inside the
   literal block pick them up via var(--kf-pmt-*, fallback).
   PER-ROW accent colors are injected separately via inline style
   attribute on each .kf-payment-method element (see the foreach loop
   that renders the cards). *}
{if isset($kf_payment_ribbon_color) && $kf_payment_ribbon_color}<style>#order-standard_cart{ldelim}--kf-pmt-ribbon:{$kf_payment_ribbon_color};{rdelim}</style>{/if}
{if isset($kf_payment_preferred_color) && $kf_payment_preferred_color}<style>#order-standard_cart{ldelim}--kf-pmt-preferred:{$kf_payment_preferred_color};--kf-pmt-preferred-glow:{$kf_payment_preferred_glow};{rdelim}</style>{/if}

<script>
    var statesTab = 10;
    var stateNotRequired = true;
</script>
{include file="orderforms/$carttpl/common.tpl"}
<script type="text/javascript" src="{$BASE_PATH_JS}/StatesDropdown.js"></script>
<script type="text/javascript" src="{$BASE_PATH_JS}/PasswordStrength.js"></script>
{literal}
<script>
    window.langPasswordStrength = "{/literal}{$LANG.pwstrength}{literal}";
    window.langPasswordWeak = "{/literal}{$LANG.pwstrengthweak}{literal}";
    window.langPasswordModerate = "{/literal}{$LANG.pwstrengthmoderate}{literal}";
    window.langPasswordStrong = "{/literal}{$LANG.pwstrengthstrong}{literal}";
</script>
{/literal}

{* ════════════ CHECKOUT MARQUEE — addon-controlled (kwickflixstyle → Cart/Checkout tab) ════════════ *}
{if isset($kf_checkout_marquee_enabled) && $kf_checkout_marquee_enabled && $kf_checkout_marquee_items}
    <div class="kf-cart-marquee {if $kf_checkout_marquee_greyscale}kf-cart-marquee-greyscale{/if}"
         style="--kf-cart-mq-speed:{$kf_checkout_marquee_speed};">
        <div class="kf-cart-marquee-track" id="kfCartMarqueeTrack">
            {foreach $kf_checkout_marquee_items as $kf_cmq}
                <div class="kf-cart-marquee-item"><img src="{$kf_cmq.url}" alt="{if $kf_cmq.alt}{$kf_cmq.alt}{/if}" loading="lazy"></div>
            {/foreach}
        </div>
    </div>
    {literal}
    <script>
    (function(){
        var track = document.getElementById('kfCartMarqueeTrack');
        if (!track) return;
        var items = Array.from(track.children);
        for (var i = items.length - 1; i > 0; i--){
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = items[i]; items[i] = items[j]; items[j] = tmp;
        }
        track.innerHTML = '';
        items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
        items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
    })();
    </script>
    {/literal}
{/if}

<div id="order-standard_cart">
    <div class="row">
        <div class="cart-sidebar">
            {include file="orderforms/$carttpl/sidebar-categories.tpl"}
        </div>
        <div class="cart-body">
            <div class="header-lined">
                <h1 class="font-size-36">{$LANG.orderForm.checkout}</h1>
            </div>

            {* {include file="orderforms/$carttpl/sidebar-categories-collapsed.tpl"} *}

            {if !$loggedin}
<div class="already-registered clearfix">
                <div class="pull-right float-right">
                    <button type="button" class="btn btn-info{if $loggedin || !$loggedin && $custtype eq "existing"} w-hidden{/if}" id="btnAlreadyRegistered">
                        {$LANG.orderForm.alreadyRegistered}
                    </button>
                    <button type="button" class="btn btn-warning{if $loggedin || $custtype neq "existing"} w-hidden{/if}" id="btnNewUserSignup">
                        {$LANG.orderForm.createAccount}
                    </button>
                </div>
                <p class="text-sm-left overflow-hidden">{lang key='orderForm.enterPersonalDetails'}</p>
            </div>
            {/if}

            {if $errormessage}
                <div class="alert alert-danger checkout-error-feedback" role="alert">
                    <p>{$LANG.orderForm.correctErrors}:</p>
                    <ul>{$errormessage}</ul>
                </div>
                <div class="clearfix"></div>
            {/if}

            <form method="post" action="{$smarty.server.PHP_SELF}?a=checkout" name="orderfrm" id="frmCheckout">
                <input type="hidden" name="checkout" value="true" />
                <input type="hidden" name="custtype" id="inputCustType" value="{$custtype}" />

                {if $custtype neq "new" && $loggedin && false}
                    <div class="sub-heading">
                        <span class="primary-bg-color">{lang key='switchAccount.title'}</span>
                    </div>
                    <div id="containerExistingAccountSelect" class="row account-select-container">
                        {foreach $accounts as $account}
                            <div class="col-sm-{if $accounts->count() == 1}12{else}6{/if}">
                                <div class="account{if $selectedAccountId == $account->id} active{/if}">
                                    <label class="radio-inline" for="account{$account->id}">
                                        <input id="account{$account->id}" class="account-select{if $account->isClosed || $account->noPermission || $inExpressCheckout} disabled{/if}" type="radio" name="account_id" value="{$account->id}"{if $account->isClosed || $account->noPermission || $inExpressCheckout} disabled="disabled"{/if}{if $selectedAccountId == $account->id} checked="checked"{/if}>
                                        <span class="address">
                                            <strong>{if $account->company}{$account->company}{else}{$account->fullName}{/if}</strong>
                                            {if $account->isClosed || $account->noPermission}
                                                <span class="label label-default">{if $account->isClosed}{lang key='closed'}{else}{lang key='noPermission'}{/if}</span>
                                            {elseif $account->currencyCode}
                                                <span class="label label-info">{$account->currencyCode}</span>
                                            {/if}
                                            <br>
                                            <span class="small">
                                                {$account->address1}{if $account->address2}, {$account->address2}{/if}<br>
                                                {if $account->city}{$account->city},{/if}
                                                {if $account->state} {$account->state},{/if}
                                                {if $account->postcode} {$account->postcode},{/if}
                                                {$account->countryName}
                                            </span>
                                        </span>
                                    </label>
                                </div>
                            </div>
                        {/foreach}
                        <div class="col-sm-12">
                            <div class="account border-bottom{if !$selectedAccountId || !is_numeric($selectedAccountId)} active{/if}">
                                <label class="radio-inline">
                                    <input class="account-select" type="radio" name="account_id" value="new"{if !$selectedAccountId || !is_numeric($selectedAccountId)} checked="checked"{/if}{if $inExpressCheckout} disabled="disabled" class="disabled"{/if}>
                                    {lang key='orderForm.createAccount'}
                                </label>
                            </div>
                        </div>
                    </div>
                {/if}

                <div id="containerExistingUserSignin"{if $loggedin || $custtype neq "existing"} class="w-hidden{/if}">
                <div class="kf-checkout-box">
                    <div class="sub-heading">
                        <span class="primary-bg-color">{$LANG.orderForm.existingCustomerLogin}</span>
                    </div>
                    <div class="alert alert-danger w-hidden" id="existingLoginMessage"></div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputLoginEmail" class="field-icon"><i class="fas fa-envelope"></i></label>
                                <input type="text" name="loginemail" id="inputLoginEmail" class="field form-control" placeholder="{$LANG.orderForm.emailAddress}" value="{$loginemail}">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputLoginPassword" class="field-icon"><i class="fas fa-lock"></i></label>
                                <input type="password" name="loginpassword" id="inputLoginPassword" class="field form-control" placeholder="{$LANG.clientareapassword}">
                            </div>
                        </div>
                    </div>
                    <div class="text-center">
                        <button type="button" id="btnExistingLogin" class="btn btn-primary btn-md">
                            <span id="existingLoginButton">{lang key='login'}</span>
                            <span id="existingLoginPleaseWait" class="w-hidden">{lang key='pleasewait'}</span>
                        </button>
                    </div>
                    {include file="orderforms/$carttpl/linkedaccounts.tpl" linkContext="checkout-existing"}
                    </div>
                </div>

                <div id="containerNewUserSignup"
                    {if $custtype === 'existing' || (is_numeric($selectedAccountId) && $selectedAccountId > 0) || ($loggedin && $selectedAccountId !== 'new' && $custtype !== 'add')}
                        class="w-hidden"
                    {/if}
                >
                <div class="kf-checkout-box">
                    <div{if $loggedin} class="w-hidden"{/if}>
                        {include file="orderforms/$carttpl/linkedaccounts.tpl" linkContext="checkout-new"}
                    </div>

                    <div class="sub-heading">
                        <span class="primary-bg-color">{$LANG.orderForm.personalInformation}</span>
                    </div>

                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputFirstName" class="field-icon"><i class="fas fa-user"></i></label>
                                <input type="text" name="firstname" id="inputFirstName" class="field form-control" placeholder="{$LANG.orderForm.firstName} (Required)" value="{$clientsdetails.firstname}" autofocus>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputLastName" class="field-icon"><i class="fas fa-user"></i></label>
                                <input type="text" name="lastname" id="inputLastName" class="field form-control" placeholder="{$LANG.orderForm.lastName} (Required)" value="{$clientsdetails.lastname}">
                            </div>
                        </div>
                    </div>

                    {* BILLING ADDRESS HIDDEN *}
                    <div class="sub-heading" style="display:none;">
                        <span class="primary-bg-color">{$LANG.orderForm.billingAddress}</span>
                    </div>
                    <div class="row" style="display:none;">
                        <div class="col-sm-12">
                            <div class="form-group prepend-icon">
                                <label for="inputAddress1" class="field-icon"><i class="far fa-building"></i></label>
                                <input type="text" name="address1" id="inputAddress1" class="field form-control" placeholder="{$LANG.orderForm.streetAddress}" value="{$clientsdetails.address1}">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group prepend-icon">
                                <label for="inputAddress2" class="field-icon"><i class="fas fa-map-marker-alt"></i></label>
                                <input type="text" name="address2" id="inputAddress2" class="field form-control" placeholder="{$LANG.orderForm.streetAddress2}" value="{$clientsdetails.address2}">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group prepend-icon">
                                <label for="inputCity" class="field-icon"><i class="far fa-building"></i></label>
                                <input type="text" name="city" id="inputCity" class="field form-control" placeholder="{$LANG.orderForm.city}" value="{$clientsdetails.city}">
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group prepend-icon">
                                <label for="state" class="field-icon" id="inputStateIcon"><i class="fas fa-map-signs"></i></label>
                                <label for="stateinput" class="field-icon" id="inputStateIcon"><i class="fas fa-map-signs"></i></label>
                                <input type="text" name="state" id="inputState" class="field form-control" placeholder="{$LANG.orderForm.state}" value="{$clientsdetails.state}">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group prepend-icon">
                                <label for="inputPostcode" class="field-icon"><i class="fas fa-certificate"></i></label>
                                <input type="text" name="postcode" id="inputPostcode" class="field form-control" placeholder="{$LANG.orderForm.postcode}" value="{$clientsdetails.postcode}">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group prepend-icon">
                                <label for="inputCountry" class="field-icon" id="inputCountryIcon"><i class="fas fa-globe"></i></label>
                                <select name="country" id="inputCountry" class="field form-control">
                                    {foreach $countries as $countrycode => $countrylabel}
                                        <option value="{$countrycode}"{if (!$country && $countrycode == $defaultcountry) || $countrycode eq $country} selected{/if}>{$countrylabel}</option>
                                    {/foreach}
                                </select>
                            </div>
                        </div>
                        {if $showTaxIdField}
                            <div class="col-sm-12">
                                <div class="form-group prepend-icon">
                                    <label for="inputTaxId" class="field-icon"><i class="fas fa-building"></i></label>
                                    <input type="text" name="tax_id" id="inputTaxId" class="field form-control" placeholder="{$taxLabel} ({$LANG.orderForm.optional})" value="{$clientsdetails.tax_id}">
                                </div>
                            </div>
                        {/if}
                    </div>

                    {if $customfields}
                        <div class="sub-heading">
                            <span class="primary-bg-color">{$LANG.orderadditionalrequiredinfo}<br><i><small>{lang key='orderForm.requiredField'}</small></i></span>
                        </div>
                        <div class="field-container">
                            <div class="row">
                                {foreach $customfields as $customfield}
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="customfield{$customfield.id}">{$customfield.name} {$customfield.required}</label>
                                            {$customfield.input}
                                            {if $customfield.description}<span class="field-help-text">{$customfield.description}</span>{/if}
                                        </div>
                                    </div>
                                {/foreach}
                            </div>
                        </div>
                    {/if}
</div> <!-- kf-checkout-box -->
                </div>

                {if $domainsinorder}
                    <div class="sub-heading">
                        <span class="primary-bg-color">{$LANG.domainregistrantinfo}</span>
                    </div>
                    <p class="small text-muted">{$LANG.orderForm.domainAlternativeContact}</p>
                    <div class="row margin-bottom">
                        <div class="col-sm-6 col-sm-offset-3 offset-sm-3">
                            <select name="contact" id="inputDomainContact" class="field form-control">
                                <option value="">{$LANG.usedefaultcontact}</option>
                                {foreach $domaincontacts as $domcontact}
                                    <option value="{$domcontact.id}"{if $contact == $domcontact.id} selected{/if}>{$domcontact.name}</option>
                                {/foreach}
                                <option value="addingnew"{if $contact == "addingnew"} selected{/if}>{$LANG.clientareanavaddcontact}...</option>
                            </select>
                        </div>
                    </div>
                    <div{if $contact neq "addingnew"} class="w-hidden"{/if}>
                        <div class="row" id="domainRegistrantInputFields">
                            <div class="col-sm-6"><div class="form-group prepend-icon"><label for="inputDCFirstName" class="field-icon"><i class="fas fa-user"></i></label><input type="text" name="domaincontactfirstname" id="inputDCFirstName" class="field form-control" placeholder="{$LANG.orderForm.firstName}" value="{$domaincontact.firstname}"></div></div>
                            <div class="col-sm-6"><div class="form-group prepend-icon"><label for="inputDCLastName" class="field-icon"><i class="fas fa-user"></i></label><input type="text" name="domaincontactlastname" id="inputDCLastName" class="field form-control" placeholder="{$LANG.orderForm.lastName}" value="{$domaincontact.lastname}"></div></div>
                            <div class="col-sm-6"><div class="form-group prepend-icon"><label for="inputDCEmail" class="field-icon"><i class="fas fa-envelope"></i></label><input type="email" name="domaincontactemail" id="inputDCEmail" class="field form-control" placeholder="{$LANG.orderForm.emailAddress}" value="{$domaincontact.email}"></div></div>
                            <div class="col-sm-6"><div class="form-group prepend-icon"><label for="inputDCPhone" class="field-icon"><i class="fas fa-phone"></i></label><input type="tel" name="domaincontactphonenumber" id="inputDCPhone" class="field form-control" placeholder="{$LANG.orderForm.phoneNumber}" value="{$domaincontact.phonenumber}"></div></div>
                            <div class="col-sm-12"><div class="form-group prepend-icon"><label for="inputDCAddress1" class="field-icon"><i class="far fa-building"></i></label><input type="text" name="domaincontactaddress1" id="inputDCAddress1" class="field form-control" placeholder="{$LANG.orderForm.streetAddress}" value="{$domaincontact.address1}"></div></div>
                            <div class="col-sm-4"><div class="form-group prepend-icon"><label for="inputDCCity" class="field-icon"><i class="far fa-building"></i></label><input type="text" name="domaincontactcity" id="inputDCCity" class="field form-control" placeholder="{$LANG.orderForm.city}" value="{$domaincontact.city}"></div></div>
                            <div class="col-sm-5"><div class="form-group prepend-icon"><label for="inputDCState" class="field-icon"><i class="fas fa-map-signs"></i></label><input type="text" name="domaincontactstate" id="inputDCState" class="field form-control" placeholder="{$LANG.orderForm.state}" value="{$domaincontact.state}"></div></div>
                            <div class="col-sm-3"><div class="form-group prepend-icon"><label for="inputDCPostcode" class="field-icon"><i class="fas fa-certificate"></i></label><input type="text" name="domaincontactpostcode" id="inputDCPostcode" class="field form-control" placeholder="{$LANG.orderForm.postcode}" value="{$domaincontact.postcode}"></div></div>
                            <div class="col-sm-12"><div class="form-group prepend-icon"><label for="inputDCCountry" class="field-icon"><i class="fas fa-globe"></i></label><select name="domaincontactcountry" id="inputDCCountry" class="field form-control">{foreach $countries as $countrycode => $countrylabel}<option value="{$countrycode}"{if (!$domaincontact.country && $countrycode == $defaultcountry) || $countrycode eq $domaincontact.country} selected{/if}>{$countrylabel}</option>{/foreach}</select></div></div>
                        </div>
                    </div>
                {/if}

                {if !$loggedin}
                    <div id="containerNewUserSecurity"{if (!$loggedin && $custtype eq "existing") || ($remote_auth_prelinked && !$securityquestions)} class="w-hidden"{/if}>
                    <div class="kf-checkout-box">
                        <div class="sub-heading">
                            <span class="primary-bg-color">Account Details</span>
                        </div>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group prepend-icon">
                                    <label for="inputEmail" class="field-icon"><i class="fas fa-envelope"></i></label>
                                    <input type="email" name="email" id="inputEmail" class="field form-control" placeholder="{$LANG.orderForm.emailAddress} - ! USE A REAL EMAIL !" value="{$clientsdetails.email}">
                                </div>
                            </div>
                        </div>
                        <div id="containerPassword" class="row{if $remote_auth_prelinked && $securityquestions} w-hidden{/if}">
                            <div id="passwdFeedback" class="alert alert-info text-center col-sm-12 w-hidden"></div>
                            <div class="col-sm-6">
                                <div class="form-group prepend-icon">
                                    <label for="inputNewPassword1" class="field-icon"><i class="fas fa-lock"></i></label>
                                    <input type="password" name="password" id="inputNewPassword1" data-error-threshold="{$pwStrengthErrorThreshold}" data-warning-threshold="{$pwStrengthWarningThreshold}" class="field form-control" placeholder="{$LANG.clientareapassword}"{if $remote_auth_prelinked} value="{$password}"{/if}>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group prepend-icon">
                                    <label for="inputNewPassword2" class="field-icon"><i class="fas fa-lock"></i></label>
                                    <input type="password" name="password2" id="inputNewPassword2" class="field form-control" placeholder="{$LANG.clientareaconfirmpassword}"{if $remote_auth_prelinked} value="{$password}"{/if}>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <button type="button" class="btn btn-default btn-sm generate-password" data-targetfields="inputNewPassword1,inputNewPassword2">{$LANG.generatePassword.btnLabel}</button>
                            </div>
                            <div class="col-sm-6">
                                <div class="password-strength-meter">
                                    <div class="progress">
                                        <div class="progress-bar progress-bar-success progress-bar-striped" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="passwordStrengthMeterBar"></div>
                                    </div>
                                    <p class="text-center small text-muted" id="passwordStrengthTextLabel">{$LANG.pwstrength}: {$LANG.pwstrengthenter}</p>
                                </div>
                            </div>
                        </div>
                        {if $securityquestions}
                            <div class="row">
                                <div class="col-sm-6">
                                    <select name="securityqid" id="inputSecurityQId" class="field form-control">
                                        <option value="">{$LANG.clientareasecurityquestion}</option>
                                        {foreach $securityquestions as $question}
                                            <option value="{$question.id}"{if $question.id eq $securityqid} selected{/if}>{$question.question}</option>
                                        {/foreach}
                                    </select>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group prepend-icon">
                                        <label for="inputSecurityQAns" class="field-icon"><i class="fas fa-lock"></i></label>
                                        <input type="password" name="securityqans" id="inputSecurityQAns" class="field form-control" placeholder="{$LANG.clientareasecurityanswer}">
                                    </div>
                                </div>
                            </div>
                        {/if}
                       </div> 
                    </div>
                {/if}

                {foreach $hookOutput as $output}<div>{$output}</div>{/foreach}

                {if $captcha && $captcha->isEnabled() && $captcha->isEnabledForForm($captchaForm)}
                    {if !$captcha->isInvisible()}
                        <div class="sub-heading"><span class="primary-bg-color">{$LANG.captchatitle}</span></div>
                    {/if}
                    <div class="text-center">
                        <div class="text-center margin-bottom">{include file="$template/includes/captcha.tpl"}</div>
                    </div>
                {/if}

                <div class="sub-heading">
                    <span class="primary-bg-color">{$LANG.orderForm.paymentDetails}</span>
                </div>

                <div id="applyCreditContainer" class="apply-credit-container{if !$canUseCreditOnCheckout} w-hidden{/if}" data-apply-credit="{$applyCredit}">
                    <p>{lang key='cart.availableCreditBalance' amount=$creditBalance}</p>
                    <label class="radio">
                        <input id="useCreditOnCheckout" type="radio" name="applycredit" value="1"{if $applyCredit} checked{/if}>
                        <span id="spanFullCredit"{if !($creditBalance->toNumeric() >= $total->toNumeric())} class="w-hidden"{/if}>{lang key='cart.applyCreditAmountNoFurtherPayment' amount=$total}</span>
                        <span id="spanUseCredit"{if $creditBalance->toNumeric() >= $total->toNumeric()} class="w-hidden"{/if}>{lang key='cart.applyCreditAmount' amount=$creditBalance}</span>
                    </label>
                    <label class="radio">
                        <input id="skipCreditOnCheckout" type="radio" name="applycredit" value="0"{if !$applyCredit} checked{/if}>
                        {lang key='cart.applyCreditSkip' amount=$creditBalance}
                    </label>
                </div>

                {* Cart/Checkout — Checkout Top notice (kwickflixstyle → Cart/Checkout tab).
                   Renders BETWEEN credit-balance options and the payment gateway list —
                   the previous hardcoded "Amazon is now a payment option" gold box used
                   to live here. Disabled by default. *}
                {if isset($kf_cart_notice_co_top_enabled) && $kf_cart_notice_co_top_enabled && ($kf_cart_notice_co_top_title || $kf_cart_notice_co_top_html)}
                    <div class="kf-cart-notice kf-cart-notice-{$kf_cart_notice_co_top_severity}">
                        {if $kf_cart_notice_co_top_title}
                            <div class="kf-cart-notice-title">
                                {if $kf_cart_notice_co_top_icon}<i class="{$kf_cart_notice_co_top_icon}"></i>{/if}
                                <span>{$kf_cart_notice_co_top_title}</span>
                                {if $kf_cart_notice_co_top_icon}<i class="{$kf_cart_notice_co_top_icon}"></i>{/if}
                            </div>
                        {/if}
                        {if $kf_cart_notice_co_top_html}
                            <div class="kf-cart-notice-body">{$kf_cart_notice_co_top_html|escape:"none" nofilter}</div>
                        {/if}
                    </div>
                {/if}

                {if !$inExpressCheckout}
                    <div id="paymentGatewaysContainer" class="kf-payment-box">
                        <div class="kf-payment-methods">

                            {* Cart/Checkout — Payment Gateway rendering.

                               Loop $kf_payment_gateways (admin-defined order from the
                               kwickflixstyle addon, Cart/Checkout → Payment Gateways).
                               For each admin row, find the matching $gateway in the
                               WHMCS-provided $gateways array (by sysname) so the radio
                               input keeps its WHMCS data attributes (payment_type /
                               show_local_cards / uses_remote_inputs — required for
                               WHMCS's gateway picker JS to attach CC fields etc).

                               If no admin rows are configured (or none match active
                               WHMCS gateways), show an empty-state notice instead of
                               rendering nothing or falling back to a hardcoded list. *}

                            {assign var=kfRenderedCount value=0}

                            {if isset($kf_payment_gateways) && $kf_payment_gateways}
                                {foreach $kf_payment_gateways as $kfPg}
                                    {foreach $gateways as $kfGw}
                                        {if $kfGw.sysname eq $kfPg.gateway}
                                            {assign var=kfRenderedCount value=$kfRenderedCount+1}
                                            <div class="kf-payment-method{if $kfPg.preferred} kf-payment-method-preferred{/if}"{if $kfPg.accent} style="--kf-pmt-row-accent:{$kfPg.accent};--kf-pmt-row-glow:{$kfPg.accent_glow};"{/if}>
                                                {if $kfPg.preferred && $kfPg.preferred_label}
                                                    <span class="kf-payment-method-ribbon">★ {$kfPg.preferred_label}</span>
                                                {/if}
                                                <label>
                                                    <input type="radio" name="paymentmethod" value="{$kfGw.sysname}" data-payment-type="{$kfGw.payment_type}" data-show-local="{$kfGw.show_local_cards}" data-remote-inputs="{$kfGw.uses_remote_inputs}" class="payment-methods{if $kfGw.type eq "CC"} is-credit-card{/if}" {if $kf_preferred_gateway && $kf_preferred_gateway eq $kfGw.sysname}checked{elseif !$kf_preferred_gateway && $selectedgateway eq $kfGw.sysname}checked{/if} />
                                                    <div class="kf-payment-method-content">
                                                        <span class="kf-payment-method-icon">{$kfPg.icon_html nofilter}</span>
                                                        <div class="kf-payment-method-text">
                                                            <span class="kf-payment-method-title">{$kfPg.title}</span>
                                                            <span class="kf-payment-method-desc">{$kfPg.subtext|escape:'none' nofilter}</span>
                                                        </div>
                                                    </div>
                                                </label>
                                            </div>
                                        {/if}
                                    {/foreach}
                                {/foreach}
                            {/if}

                            {if $kfRenderedCount eq 0}
                                <div class="kf-payment-empty">
                                    <i class="fas fa-info-circle"></i>
                                    <strong>No payment options are currently available.</strong>
                                    <span>Please contact support — there are no payment methods set up at the moment.</span>
                                </div>
                            {/if}

                        </div>
                    </div>

                    <div class="alert alert-danger text-center gateway-errors w-hidden"></div>
                    <div class="clearfix"></div>
                    <div id="paymentGatewayInput"></div>

                    <div class="cc-input-container{if $selectedgatewaytype neq "CC"} w-hidden{/if}" id="creditCardInputFields">
                        {if $client}
                            <div id="existingCardsContainer" class="existing-cc-grid">
                                {include file="orderforms/$carttpl/includes/existing-paymethods.tpl"}
                            </div>
                        {/if}
                        <div class="row cvv-input" id="existingCardInfo">
                            <div class="col-lg-3 col-sm-4">
                                <div class="form-group prepend-icon">
                                    <label for="inputCardCVV2" class="field-icon"><i class="fas fa-barcode"></i></label>
                                    <div class="input-group">
                                        <input type="tel" name="cccvv" id="inputCardCVV2" class="field form-control" placeholder="{$LANG.creditcardcvvnumbershort}" autocomplete="cc-cvc">
                                        <span class="input-group-btn input-group-append"><button type="button" class="btn btn-default" data-toggle="popover" data-placement="bottom" data-content="<img src='{$BASE_PATH_IMG}/ccv.gif' width='210' />">?</button></span>
                                    </div>
                                    <span class="field-error-msg">{lang key="paymentMethodsManage.cvcNumberNotValid"}</span>
                                </div>
                            </div>
                        </div>
                        <ul>
                            <li>
                                <label class="radio-inline">
                                    <input type="radio" name="ccinfo" value="new" id="new" {if !$client || $client->payMethods->count() === 0} checked="checked"{/if} />
                                    &nbsp;{lang key='creditcardenternewcard'}
                                </label>
                            </li>
                        </ul>
                        <div class="row" id="newCardInfo">
                            <div id="cardNumberContainer" class="col-sm-6 new-card-container">
                                <div class="form-group prepend-icon">
                                    <label for="inputCardNumber" class="field-icon"><i class="fas fa-credit-card"></i></label>
                                    <input type="tel" name="ccnumber" id="inputCardNumber" class="field form-control cc-number-field" placeholder="{$LANG.orderForm.cardNumber}" autocomplete="cc-number" data-message-unsupported="{lang key='paymentMethodsManage.unsupportedCardType'}" data-message-invalid="{lang key='paymentMethodsManage.cardNumberNotValid'}" data-supported-cards="{$supportedCardTypes}" />
                                    <span class="field-error-msg"></span>
                                </div>
                            </div>
                            <div class="col-sm-3 new-card-container">
                                <div class="form-group prepend-icon">
                                    <label for="inputCardExpiry" class="field-icon"><i class="fas fa-calendar-alt"></i></label>
                                    <input type="tel" name="ccexpirydate" id="inputCardExpiry" class="field form-control" placeholder="MM / YY{if $showccissuestart} ({$LANG.creditcardcardexpires}){/if}" autocomplete="cc-exp">
                                    <span class="field-error-msg">{lang key="paymentMethodsManage.expiryDateNotValid"}</span>
                                </div>
                            </div>
                            <div class="col-sm-3" id="cvv-field-container">
                                <div class="form-group prepend-icon">
                                    <label for="inputCardCVV" class="field-icon"><i class="fas fa-barcode"></i></label>
                                    <div class="input-group">
                                        <input type="tel" name="cccvv" id="inputCardCVV" class="field form-control" placeholder="{$LANG.creditcardcvvnumbershort}" autocomplete="cc-cvc">
                                        <span class="input-group-btn input-group-append"><button type="button" class="btn btn-default" data-toggle="popover" data-placement="bottom" data-content="<img src='{$BASE_PATH_IMG}/ccv.gif' width='210' />">?</button></span>
                                    </div>
                                    <span class="field-error-msg">{lang key="paymentMethodsManage.cvcNumberNotValid"}</span>
                                </div>
                            </div>
                        </div>
                        <div id="newCardSaveSettings">
                            <div class="row form-group new-card-container">
                                <div id="inputDescriptionContainer" class="col-md-6">
                                    <div class="prepend-icon">
                                        <label for="inputDescription" class="field-icon"><i class="fas fa-pencil"></i></label>
                                        <input type="text" class="field form-control" id="inputDescription" name="ccdescription" autocomplete="off" value="" placeholder="{$LANG.paymentMethods.descriptionInput} {$LANG.paymentMethodsManage.optional}" />
                                    </div>
                                </div>
                                {if $allowClientsToRemoveCards}
                                    <div id="inputNoStoreContainer" class="col-md-6" style="line-height:32px;">
                                        <input type="hidden" name="nostore" value="1">
                                        <input type="checkbox" class="toggle-switch-success no-icheck" data-size="mini" checked="checked" name="nostore" id="inputNoStore" value="0" data-on-text="{lang key='yes'}" data-off-text="{lang key='no'}">
                                        <label for="inputNoStore" class="checkbox-inline no-padding">&nbsp;&nbsp;{$LANG.creditCardStore}</label>
                                    </div>
                                {/if}
                            </div>
                        </div>
                    </div>
                {else}
                    {if $expressCheckoutOutput}
                        {$expressCheckoutOutput}
                    {else}
                        <p align="center">{lang key='paymentPreApproved' gateway=$expressCheckoutGateway}</p>
                    {/if}
                {/if}

                {if $showMarketingEmailOptIn}
                    <div class="marketing-email-optin">
                        <h4 class="font-size-18">{lang key='emailMarketing.joinOurMailingList'}</h4>
                        <p>{$marketingEmailOptInMessage}</p>
                        <input type="checkbox" name="marketingoptin" value="1"{if $marketingEmailOptIn} checked{/if} class="no-icheck toggle-switch-success" data-size="small" data-on-text="{lang key='yes'}" data-off-text="{lang key='no'}">
                    </div>
                {/if}

                <div class="alert alert-success text-center large-text" role="alert" id="totalDueToday">
                    {$LANG.ordertotalduetoday}: &nbsp; <strong id="totalCartPrice">{$total}</strong>
                </div>

                {* Cart/Checkout — Checkout Bottom notice (kwickflixstyle → Cart/Checkout tab).
                   Replaces both the stock "Your store login details" alert AND the
                   previously-hardcoded red "Important Notice — Crypto payments require
                   confirmation time" box. Whatever the admin configures here is the
                   ONLY notice that renders in this spot. *}
                {if isset($kf_cart_notice_co_bot_enabled) && $kf_cart_notice_co_bot_enabled && ($kf_cart_notice_co_bot_title || $kf_cart_notice_co_bot_html)}
                    <div class="kf-cart-notice kf-cart-notice-{$kf_cart_notice_co_bot_severity}">
                        {if $kf_cart_notice_co_bot_title}
                            <div class="kf-cart-notice-title">
                                {if $kf_cart_notice_co_bot_icon}<i class="{$kf_cart_notice_co_bot_icon}"></i>{/if}
                                <span>{$kf_cart_notice_co_bot_title}</span>
                                {if $kf_cart_notice_co_bot_icon}<i class="{$kf_cart_notice_co_bot_icon}"></i>{/if}
                            </div>
                        {/if}
                        {if $kf_cart_notice_co_bot_html}
                            <div class="kf-cart-notice-body">{$kf_cart_notice_co_bot_html|escape:"none" nofilter}</div>
                        {/if}
                    </div>
                {/if}

                <div class="text-center">
                    {if $accepttos}
                        <p>
                            <label class="checkbox-inline">
                                <input type="checkbox" name="accepttos" id="accepttos" />
                                &nbsp;{$LANG.ordertosagreement}
                                <a href="{$tosurl}" target="_blank">{$LANG.ordertos}</a>
                            </label>
                        </p>
                    {/if}
                    <button type="submit" id="btnCompleteOrder" class="btn btn-primary btn-lg disable-on-click spinner-on-click{if $captcha}{$captcha->getButtonClass($captchaForm)}{/if}" {if $cartitems==0}disabled="disabled"{/if}>
                        {if $inExpressCheckout}{$LANG.confirmAndPay}{else}{$LANG.completeorder}{/if}
                        &nbsp;<i class="fas fa-arrow-circle-right"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript" src="{$BASE_PATH_JS}/jquery.payment.js"></script>
{literal}
<script>
    var hideCvcOnCheckoutForExistingCard = '{/literal}{if $canUseCreditOnCheckout && $applyCredit && ($creditBalance->toNumeric() >= $total->toNumeric())}1{else}0{/if}{literal}';
</script>
{/literal}
{include file="orderforms/$carttpl/recommendations-modal.tpl"}
