{literal}
<style>
.kf-login-wrap{
  max-width:480px;
  margin:0 auto;
  padding:40px 16px 60px;
  font-family:'Outfit',sans-serif;
}
.kf-login-card{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  box-shadow:var(--ca-shadow-md);
  overflow:hidden;
}
.kf-login-card-header{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:22px 28px 18px;
}
.kf-login-card-header h6{
  font-family:'Barlow Condensed',sans-serif;
  font-size:28px;
  font-weight:900;
  letter-spacing:-.01em;
  margin:0 0 4px;
}
.kf-login-card-header p{
  margin:0;font-size:13px;color:var(--ca-muted);
}
.kf-login-card-body{padding:28px;}
.kf-login-card-body .form-control-label{
  font-size:12px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--ca-muted);
  margin-bottom:6px;
}
.kf-login-card-footer{
  background:var(--ca-surface2);
  border-top:1px solid var(--ca-border);
  padding:14px 28px;
  font-size:13px;
  color:var(--ca-muted);
  text-align:center;
}
.kf-login-card-footer a{color:var(--ca-accent);font-weight:700;}

/* ──────────────────────────────────────────────────────────────
   Merged input pill — icon + input + (optional) eye toggle all
   inside ONE rounded pill, separated by thin vertical lines.
   Overrides Bootstrap's default .input-group rendering which
   leaves each segment as its own bordered box.
   ────────────────────────────────────────────────────────────── */
.kf-login-card-body .input-group{
  background:var(--ca-surface) !important;
  border:1.5px solid var(--ca-border) !important;
  border-radius:10px !important;
  overflow:hidden !important;
  transition:border-color .15s ease, box-shadow .15s ease !important;
  flex-wrap:nowrap !important;
}
.kf-login-card-body .input-group:focus-within{
  border-color:var(--ca-accent) !important;
  box-shadow:0 0 0 3px rgba(34,160,74,.12) !important;
}
.kf-login-card-body .input-group > .input-group-prepend{margin-right:0 !important;}
.kf-login-card-body .input-group > .input-group-prepend .input-group-text{
  background:transparent !important;
  border:none !important;
  border-right:1px solid var(--ca-border) !important;  /* the | divider */
  border-radius:0 !important;
  padding:0 14px !important;
  color:var(--ca-muted) !important;
  font-size:14px !important;
}
.kf-login-card-body .input-group > .form-control{
  background:transparent !important;
  border:none !important;
  border-radius:0 !important;
  box-shadow:none !important;
  padding:12px 14px !important;
  font-size:14px !important;
  height:auto !important;
  min-height:44px !important;
}
.kf-login-card-body .input-group > .form-control:focus{
  box-shadow:none !important;
  outline:none !important;
}
.kf-login-card-body .input-group > .input-group-append{margin-left:0 !important;}
.kf-login-card-body .input-group > .input-group-append .btn{
  background:transparent !important;
  border:none !important;
  border-left:1px solid var(--ca-border) !important;  /* | divider for eye toggle */
  border-radius:0 !important;
  color:var(--ca-muted) !important;
  padding:0 14px !important;
  cursor:pointer !important;
  box-shadow:none !important;
}
.kf-login-card-body .input-group > .input-group-append .btn:hover{
  color:var(--ca-text) !important;
  background:var(--ca-surface2) !important;
}

/* ──────────────────────────────────────────────────────────────
   Actions — full-width Login button, Remember Me on its own line
   centered below. The original Bootstrap layout puts the button
   left and Remember Me right with space-between, which looks
   undersized and asymmetric vs. the reference design.
   ────────────────────────────────────────────────────────────── */
.kf-login-actions{
  display:flex !important;
  flex-direction:column !important;
  align-items:stretch !important;
  gap:12px !important;
  margin-top:14px !important;
}
.kf-login-actions .kf-login-submit{
  width:100% !important;
  padding:13px 20px !important;
  font-size:15px !important;
  font-weight:700 !important;
  border-radius:10px !important;
  display:inline-flex !important;
  align-items:center !important;
  justify-content:center !important;
  gap:8px !important;
}
.kf-login-actions .kf-login-remember{
  align-self:center !important;
  margin:0 !important;
  font-size:13px !important;
  color:var(--ca-muted) !important;
}

.kf-forgot{font-size:13px;}
</style>
{/literal}

<div class="kf-login-wrap">
    <div class="providerLinkingFeedback"></div>

    <form method="post" action="{routePath('login-validate')}" class="login-form" role="form">
        <div class="kf-login-card">
            <div class="kf-login-card-header">
                <h6>{lang key='loginbutton'}</h6>
                <p>{lang key='userLogin.signInToContinue'}</p>
            </div>

            <div class="kf-login-card-body">
                {include file="$template/includes/flashmessage.tpl"}

                <div class="form-group">
                    <label for="inputEmail" class="form-control-label">{lang key='clientareaemail'}</label>
                    <div class="input-group input-group-merge">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-user"></i></span>
                        </div>
                        <input type="email" class="form-control" name="username" id="inputEmail" placeholder="name@example.com" autofocus>
                    </div>
                </div>

                <div class="form-group focused">
                    <div class="d-flex align-items-center justify-content-between">
                        <label for="inputPassword" class="form-control-label">{lang key='clientareapassword'}</label>
                        <a href="{routePath('password-reset-begin')}" class="kf-forgot" tabindex="-1">{lang key='forgotpw'}</a>
                    </div>
                    <div class="input-group input-group-merge">
                        <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-key"></i></span>
                        </div>
                        <input type="password" class="form-control pw-input" name="password" id="inputPassword" placeholder="{lang key='clientareapassword'}" autocomplete="off">
                        <div class="input-group-append">
                            <button class="btn btn-default btn-reveal-pw" type="button" tabindex="-1">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                    </div>
                </div>

                {if $captcha->isEnabled()}
                    {include file="$template/includes/captcha.tpl"}
                {/if}

                <div class="kf-login-actions">
                    <button id="login" type="submit" class="btn btn-primary kf-login-submit{$captcha->getButtonClass($captchaForm)}">
                        {lang key='loginbutton'} <span aria-hidden="true">→</span>
                    </button>
                    <label class="kf-login-remember">
                        <input type="checkbox" class="form-check-input" name="rememberme" />
                        {lang key='loginrememberme'}
                    </label>
                </div>
            </div>

            <div class="kf-login-card-footer">
                {lang key='userLogin.notRegistered'}
                <a href="{$WEB_ROOT}/register.php">{lang key='userLogin.createAccount'}</a>
            </div>
        </div>
    </form>

    {include file="$template/includes/linkedaccounts.tpl" linkContext="login" customFeedback=true}
</div>
