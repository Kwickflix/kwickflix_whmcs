{if in_array('state', $optionalFields)}
    <script>
        var statesTab = 10,
            stateNotRequired = true;
    </script>
{/if}

<script src="{$BASE_PATH_JS}/StatesDropdown.js"></script>
<script src="{$BASE_PATH_JS}/PasswordStrength.js"></script>
<script>
    window.langPasswordStrength = "{lang key='pwstrength'}";
    window.langPasswordWeak = "{lang key='pwstrengthweak'}";
    window.langPasswordModerate = "{lang key='pwstrengthmoderate'}";
    window.langPasswordStrong = "{lang key='pwstrengthstrong'}";
    jQuery(document).ready(function() {
        jQuery("#inputNewPassword1").keyup(registerFormPasswordStrengthFeedback);
    });
</script>

{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --ca-surface:#fefdfb;
  --ca-surface2:#f7f5f0;
  --ca-surface3:#ede9e2;
  --ca-border:#d8d3cc;
  --ca-border2:#bfb8ae;
  --ca-text:#13110e;
  --ca-muted:#7a7268;
  --ca-muted2:#5a5249;
  --ca-accent:#22a04a;
  --ca-accent-dark:#167a36;
  --ca-accent-bg:rgba(34,160,74,.07);
  --ca-accent-border:rgba(34,160,74,.18);
  --ca-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --ca-shadow-md:0 8px 32px rgba(19,17,14,.1),0 2px 8px rgba(19,17,14,.05);
  --ca-shadow-green:0 6px 24px rgba(34,160,74,.25),0 2px 8px rgba(34,160,74,.12);
}

/* ── WRAPPER ── */
.kf-reg-wrap{
  max-width:640px;
  margin:0 auto;
  padding:40px 16px 60px;
  font-family:'Outfit',sans-serif;
}

/* ── SECTION CARDS ── */
.kf-reg-card{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  box-shadow:var(--ca-shadow-sm);
  overflow:hidden;
  margin-bottom:16px;
}

.kf-reg-card-header{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:16px 24px;
}

.kf-reg-card-header h3{
  font-family:'Barlow Condensed',sans-serif;
  font-size:20px;
  font-weight:800;
  letter-spacing:.02em;
  color:var(--ca-text);
  margin:0;
  line-height:1;
}

.kf-reg-card-body{
  padding:22px 24px;
}

/* ── FORM INPUTS ── */
.kf-reg-wrap .form-group{
  margin-bottom:16px;
}

.kf-reg-wrap .form-group label:not(.field-icon):not(.form-check):not(.radio-inline){
  font-size:12px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--ca-muted2);
  margin-bottom:6px;
  display:block;
}

.kf-reg-wrap .form-control,
.kf-reg-wrap .field.form-control,
.kf-reg-wrap input.field,
.kf-reg-wrap select.field{
  border:1.5px solid var(--ca-border) !important;
  border-radius:8px !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  padding:10px 14px !important;
  background:var(--ca-surface) !important;
  color:var(--ca-text) !important;
  transition:.15s ease !important;
  height:auto !important;
  width:100%;
}

.kf-reg-wrap .form-control:focus,
.kf-reg-wrap .field.form-control:focus,
.kf-reg-wrap input.field:focus,
.kf-reg-wrap select.field:focus{
  border-color:var(--ca-accent) !important;
  box-shadow:0 0 0 3px var(--ca-accent-bg) !important;
  outline:none !important;
}

/* prepend-icon padding */
.kf-reg-wrap .prepend-icon .form-control,
.kf-reg-wrap .prepend-icon input.field,
.kf-reg-wrap .prepend-icon select.field{
  padding-left:40px !important;
}

.kf-reg-wrap .prepend-icon .field-icon{
  color:var(--ca-muted);
  position:absolute;
  left:12px;
  top:50%;
  transform:translateY(-50%);
  pointer-events:none;
  z-index:2;
  line-height:1;
}

.kf-reg-wrap .prepend-icon{
  position:relative;
}

/* ── ALERTS ── */
.kf-reg-wrap .alert{
  border-radius:10px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  padding:14px 18px;
  margin-bottom:16px;
  border:1px solid var(--ca-border);
}
.kf-reg-wrap .alert-danger{background:rgba(204,40,40,.06);border-color:rgba(204,40,40,.2);color:#cc2828;}
.kf-reg-wrap .alert-info{background:var(--ca-accent-bg);border-color:var(--ca-accent-border);color:var(--ca-accent-dark);}

/* ── PASSWORD STRENGTH ── */
.kf-reg-wrap .password-strength-meter .progress{
  border-radius:6px;
  height:8px;
  background:var(--ca-surface3);
  border:1px solid var(--ca-border);
  margin-bottom:4px;
}
.kf-reg-wrap #passwordStrengthTextLabel{
  font-size:12px;
  color:var(--ca-muted);
}

/* ── GENERATE PASSWORD BTN ── */
.kf-reg-wrap .generate-password{
  font-size:13px;
  font-weight:600;
  color:var(--ca-accent);
  border:1.5px solid var(--ca-accent-border);
  background:var(--ca-accent-bg);
  border-radius:6px;
  padding:7px 14px;
  transition:.15s ease;
}
.kf-reg-wrap .generate-password:hover{
  background:var(--ca-accent);
  color:#fff;
  border-color:var(--ca-accent);
}

/* ── TOS CHECKBOX ── */
.kf-reg-wrap .form-check,
.kf-reg-wrap p.text-center label{
  font-size:14px;
  color:var(--ca-muted);
}
.kf-reg-wrap .form-check a,
.kf-reg-wrap p.text-center a{
  color:var(--ca-accent);
  text-decoration:underline;
}

/* ── SUBMIT BUTTON ── */
.kf-reg-wrap .btn-primary{
  display:inline-flex !important;
  align-items:center !important;
  gap:8px !important;
  padding:14px 40px !important;
  background:var(--ca-accent) !important;
  color:#fff !important;
  border:none !important;
  border-radius:8px !important;
  font-family:'Outfit',sans-serif !important;
  font-size:16px !important;
  font-weight:700 !important;
  box-shadow:var(--ca-shadow-green) !important;
  transition:.2s ease !important;
  cursor:pointer !important;
}
.kf-reg-wrap .btn-primary:hover{
  background:var(--ca-accent-dark) !important;
  transform:translateY(-1px) !important;
  box-shadow:0 8px 28px rgba(34,160,74,.3) !important;
}

/* ── FIELD HELP TEXT ── */
.kf-reg-wrap .field-help-text{
  display:block;
  font-size:12px;
  color:var(--ca-muted);
  margin-top:5px;
}

/* ── MARKETING TOGGLE ── */
.kf-reg-wrap .toggle-switch-success{accent-color:var(--ca-accent);}

@media(max-width:520px){
  .kf-reg-card-body{padding:16px;}
  .kf-reg-card-header{padding:14px 16px;}
}
</style>
{/literal}

{if $registrationDisabled}
    {include file="$template/includes/alert.tpl" type="error" msg="{lang key='registerCreateAccount'}"|cat:' <strong><a href="'|cat:"$WEB_ROOT"|cat:'/cart.php" class="alert-link">'|cat:"{lang key='registerCreateAccountOrder'}"|cat:'</a></strong>'}
{/if}

{if $errormessage}
    {include file="$template/includes/alert.tpl" type="error" errorshtml=$errormessage}
{/if}

{if !$registrationDisabled}
<div class="kf-reg-wrap">
    <form method="post" class="using-password-strength" action="{$smarty.server.PHP_SELF}" role="form" name="orderfrm" id="frmCheckout">
        <input type="hidden" name="register" value="true"/>

        <div id="containerNewUserSignup">

            {* ── Personal Information ── *}
            <div class="kf-reg-card">
                <div class="kf-reg-card-header">
                    <h3>{lang key='orderForm.personalInformation'}</h3>
                </div>
                <div class="kf-reg-card-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputFirstName" class="field-icon"><i class="fas fa-user"></i></label>
                                <input type="text" name="firstname" id="inputFirstName" class="field form-control" placeholder="{lang key='orderForm.firstName'}" value="{$clientfirstname}" {if !in_array('firstname', $optionalFields)}required{/if} autofocus>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputLastName" class="field-icon"><i class="fas fa-user"></i></label>
                                <input type="text" name="lastname" id="inputLastName" class="field form-control" placeholder="{lang key='orderForm.lastName'}" value="{$clientlastname}" {if !in_array('lastname', $optionalFields)}required{/if}>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group prepend-icon">
                                <label for="inputEmail" class="field-icon"><i class="fas fa-envelope"></i></label>
                                <input type="email" name="email" id="inputEmail" class="field form-control" placeholder="{lang key='orderForm.emailAddress'}" value="{$clientemail}">
                            </div>
                            <div style="background:rgba(204,40,40,.06);border:1px solid rgba(204,40,40,.2);border-radius:8px;padding:10px 14px;margin-top:-8px;margin-bottom:4px;font-family:'Outfit',sans-serif;font-size:13px;font-weight:600;color:#cc2828;display:flex;align-items:center;gap:8px;">
                                <i class="fas fa-exclamation-triangle"></i>
                                Use a real, valid email address — your login and service details will be sent here.
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {* ── Billing Address HIDDEN — fields kept for WHMCS submission, visually removed ── *}
            <div style="display:none;">
                <input type="hidden" name="companyname" value="">
                <input type="hidden" name="address1" value="N/A">
                <input type="hidden" name="address2" value="">
                <input type="hidden" name="city" value="N/A">
                <input type="hidden" name="state" value="N/A">
                <input type="hidden" name="postcode" value="00000">
                <select name="country" style="display:none;">
                    {foreach $clientcountries as $countryCode => $countryName}
                        <option value="{$countryCode}"{if (!$clientcountry && $countryCode eq $defaultCountry) || ($countryCode eq $clientcountry)} selected="selected"{/if}>{$countryName}</option>
                    {/foreach}
                </select>
                {if $showTaxIdField}<input type="hidden" name="tax_id" value="">{/if}
            </div>

            {* ── Additional Info / Currency ── *}
            {if $customfields || $currencies}
                <div class="kf-reg-card">
                    <div class="kf-reg-card-header">
                        <h3>{lang key='orderadditionalrequiredinfo'}</h3>
                    </div>
                    <div class="kf-reg-card-body">
                        <div class="row">
                            {if $customfields}
                                {foreach $customfields as $customfield}
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label for="customfield{$customfield.id}">{$customfield.name} {$customfield.required}</label>
                                            <div class="control">
                                                {$customfield.input}
                                                {if $customfield.description}<span class="field-help-text">{$customfield.description}</span>{/if}
                                            </div>
                                        </div>
                                    </div>
                                {/foreach}
                            {/if}
                            {if $currencies}
                                <div class="col-sm-6">
                                    <div class="form-group prepend-icon">
                                        <label for="inputCurrency" class="field-icon"><i class="far fa-money-bill-alt"></i></label>
                                        <select id="inputCurrency" name="currency" class="field form-control">
                                            {foreach $currencies as $curr}
                                                <option value="{$curr.id}"{if !$smarty.post.currency && $curr.default || $smarty.post.currency eq $curr.id} selected{/if}>{$curr.code}</option>
                                            {/foreach}
                                        </select>
                                    </div>
                                </div>
                            {/if}
                        </div>
                    </div>
                </div>
            {/if}

        </div>

        {* ── Account Security ── *}
        <div id="containerNewUserSecurity" {if $remote_auth_prelinked && !$securityquestions}class="w-hidden"{/if}>
            <div class="kf-reg-card">
                <div class="kf-reg-card-header">
                    <h3>{lang key='orderForm.accountSecurity'}</h3>
                </div>
                <div class="kf-reg-card-body">
                    <div id="containerPassword" class="row{if $remote_auth_prelinked && $securityquestions} hidden{/if}">
                        <div id="passwdFeedback" class="alert alert-info text-center col-sm-12 w-hidden"></div>
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputNewPassword1" class="field-icon"><i class="fas fa-lock"></i></label>
                                <input type="password" name="password" id="inputNewPassword1" data-error-threshold="{$pwStrengthErrorThreshold}" data-warning-threshold="{$pwStrengthWarningThreshold}" class="field form-control" placeholder="{lang key='clientareapassword'}" autocomplete="off"{if $remote_auth_prelinked} value="{$password}"{/if}>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group prepend-icon">
                                <label for="inputNewPassword2" class="field-icon"><i class="fas fa-lock"></i></label>
                                <input type="password" name="password2" id="inputNewPassword2" class="field form-control" placeholder="{lang key='clientareaconfirmpassword'}" autocomplete="off"{if $remote_auth_prelinked} value="{$password}"{/if}>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <button type="button" class="btn btn-default btn-sm generate-password" data-targetfields="inputNewPassword1,inputNewPassword2">
                                    {lang key='generatePassword.btnLabel'}
                                </button>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="password-strength-meter">
                                <div class="progress">
                                    <div class="progress-bar bg-success bg-striped" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" id="passwordStrengthMeterBar"></div>
                                </div>
                                <p class="text-center small text-muted" id="passwordStrengthTextLabel">{lang key='pwstrength'}: {lang key='pwstrengthenter'}</p>
                            </div>
                        </div>
                    </div>
                    {if $securityquestions}
                        <div class="row">
                            <div class="form-group col-sm-6">
                                <select name="securityqid" id="inputSecurityQId" class="field form-control">
                                    <option value="">{lang key='clientareasecurityquestion'}</option>
                                    {foreach $securityquestions as $question}
                                        <option value="{$question.id}"{if $question.id eq $securityqid} selected{/if}>{$question.question}</option>
                                    {/foreach}
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group prepend-icon">
                                    <label for="inputSecurityQAns" class="field-icon"><i class="fas fa-lock"></i></label>
                                    <input type="password" name="securityqans" id="inputSecurityQAns" class="field form-control" placeholder="{lang key='clientareasecurityanswer'}" autocomplete="off">
                                </div>
                            </div>
                        </div>
                    {/if}
                </div>
            </div>
        </div>

        {* ── Marketing Opt-In ── *}
        {if $showMarketingEmailOptIn}
            <div class="kf-reg-card">
                <div class="kf-reg-card-header">
                    <h3>{lang key='emailMarketing.joinOurMailingList'}</h3>
                </div>
                <div class="kf-reg-card-body">
                    <p style="font-size:14px;color:var(--ca-muted);margin-bottom:12px;">{$marketingEmailOptInMessage}</p>
                    <input type="checkbox" name="marketingoptin" value="1"{if $marketingEmailOptIn} checked{/if} class="no-icheck toggle-switch-success" data-size="small" data-on-text="{lang key='yes'}" data-off-text="{lang key='no'}">
                </div>
            </div>
        {/if}

        {include file="$template/includes/captcha.tpl"}

        {if $accepttos}
            <p class="text-center" style="margin-bottom:16px;">
                <label class="form-check">
                    <input type="checkbox" name="accepttos" class="form-check-input accepttos">
                    {lang key='ordertosagreement'} <a href="{$tosurl}" target="_blank">{lang key='ordertos'}</a>
                </label>
            </p>
        {/if}

        <div class="text-center mb-3">
            <button class="btn btn-lg btn-primary{$captcha->getButtonClass($captchaForm)}" type="submit">
                {lang key='clientregistertitle'} &nbsp;<i class="fas fa-arrow-right"></i>
            </button>
            {if isset($discordButton)}
                <span style="display:inline-block;margin-left:10px;">{$discordButton nofilter}</span>
            {/if}
        </div>

    </form>
</div>
{/if}
