<!doctype html>
<html lang="en">
<head>
    <meta charset="{$charset}" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{if $kbarticle.title}{$kbarticle.title} - {/if}{$pagetitle} - {$companyname}</title>
    {include file="$template/includes/head.tpl"}
    {$headoutput}

    {* Favicon — emit only if the addon has a URL configured. The type
       attribute is auto-derived from the file extension by the hook. *}
    {if isset($kf_favicon_url) && $kf_favicon_url}
    <link rel="icon" type="{$kf_favicon_type}" href="{$kf_favicon_url}">
    <link rel="shortcut icon" href="{$kf_favicon_url}">
    {/if}

    {* Open Graph / social-sharing meta tags. Each tag is independent —
       missing values just skip the tag instead of emitting blank ones. *}
    {if isset($kf_og_title) && $kf_og_title}<meta property="og:title" content="{$kf_og_title|escape:'html'}">
    <meta name="twitter:title" content="{$kf_og_title|escape:'html'}">{/if}
    {if isset($kf_og_description) && $kf_og_description}<meta property="og:description" content="{$kf_og_description|escape:'html'}">
    <meta name="description" content="{$kf_og_description|escape:'html'}">
    <meta name="twitter:description" content="{$kf_og_description|escape:'html'}">{/if}
    {if isset($kf_og_image) && $kf_og_image}<meta property="og:image" content="{$kf_og_image|escape:'html'}">
    <meta name="twitter:image" content="{$kf_og_image|escape:'html'}">
    <meta name="twitter:card" content="summary_large_image">{/if}
    <meta property="og:type" content="website">

    {* Admin's custom HEAD HTML — analytics tags, schema markup, etc.
       Rendered as-is with nofilter because the admin is trusted. *}
    {if isset($kf_custom_head_html) && $kf_custom_head_html}{$kf_custom_head_html nofilter}{/if}

{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
/* ============================================================
   KWICKFLIX GLOBAL DESIGN SYSTEM
   Lives in header.tpl — loads on every page.
   No custom.css. All dynamic settings injected by the
   kwickflixstyle addon via the head hook below this block.
   ============================================================ */

:root{
  --ca-surface:#fefdfb;
  --ca-surface2:#f7f5f0;
  --ca-surface3:#ede9e2;
  --ca-border:#d8d3cc;
  --ca-border2:#bfb8ae;
  --ca-text:#13110e;
  --ca-muted:#7a7268;
  --ca-muted2:#5a5249;

  --ca-accent:#22a04a;
  --ca-accent-dark:#167a36;
  --ca-accent-bg:rgba(34,160,74,.07);
  --ca-accent-border:rgba(34,160,74,.18);

  --ca-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --ca-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
  --ca-shadow-lg:0 8px 32px rgba(19,17,14,.10),0 2px 8px rgba(19,17,14,.05);
  --ca-shadow-green:0 6px 24px rgba(34,160,74,.22),0 2px 8px rgba(34,160,74,.10);

  --kf-display:'Barlow Condensed',sans-serif;
  --kf-body:'Outfit',sans-serif;
}

/* ── BODY / GLOBAL ─────────────────────────────────────── */
html,body{
  height:100%;
  margin:0;
  display:flex;
  flex-direction:column;
  font-family:var(--kf-body);
  color:var(--ca-text);
}
#main-body{flex:1 0 auto;}
#footer{flex-shrink:0;}

/* Background layers (only render when addon emits them) */
.kf-bg-video,
.kf-bg-image{
  position:fixed;
  inset:0;
  width:100vw;
  height:100vh;
  object-fit:cover;
  z-index:-2;
  pointer-events:none;
}
.kf-bg-image{background-size:cover;background-position:center;background-repeat:no-repeat;}
.kf-bg-overlay{
  position:fixed;
  inset:0;
  z-index:-1;
  pointer-events:none;
  background:rgba(254,253,251,.55);
}

/* Top centered hero logo (optional) */
.kf-top-logo-bar{
  text-align:center;
  padding:24px 16px 8px;
}
.kf-top-logo-bar img{
  max-height:120px;
  width:auto;
  filter:drop-shadow(0 6px 18px rgba(0,0,0,.18));
}

/* ── HEADER / NAVBAR ───────────────────────────────────── */
#header.header{
  background:transparent !important;
  border-bottom:none !important;
  box-shadow:none !important;
  position:relative;
  z-index:5;
}
#header .navbar-brand img,
#header .logo-img{
  max-height:58px !important;
  width:auto !important;
  filter:drop-shadow(0 4px 12px rgba(0,0,0,.18)) !important;
}
.master-breadcrumb{display:none !important;}

/* Desktop: 3-column grid centers the logo */
@media (min-width:1200px){
  .navbar.navbar-light .container{
    display:grid !important;
    grid-template-columns:1fr auto 1fr !important;
    align-items:center !important;
    width:100% !important;
  }
  .navbar.navbar-light .navbar-brand{
    grid-column:2 !important;
    justify-self:center !important;
    margin:0 !important;padding:0 !important;
    position:static !important;transform:none !important;
  }
  .navbar.navbar-light .navbar-nav.toolbar{
    grid-column:3 !important;
    justify-self:end !important;
    margin:0 !important;
  }
  .navbar.navbar-light .navbar-brand img{
    max-height:64px !important;
    width:auto !important;display:block !important;
  }
}

/* Mobile: stack centered */
@media (max-width:1199px){
  .navbar.navbar-light .container{
    flex-direction:column;align-items:center;text-align:center;
    padding-left:0 !important;padding-right:0 !important;
  }
  .navbar-brand{margin:0 0 15px 0 !important;padding:0 !important;}
  .navbar-brand img{margin:0 auto;display:block;}
  .navbar-nav.toolbar{margin:0 !important;display:flex;justify-content:center;}
  .navbar-nav.toolbar .nav-item{margin:0 10px !important;}
}

/* ── NAV PILL BUTTONS (rows 1 + 2 + account + cart + notifications) ──── */
#mainNavbar ul#nav > li > a,
#mainNavbar ul.kf-nav-row2 > li > a,
#mainNavbar ul.navbar-nav.ml-auto > li > a,
#mainNavbar a.cart-btn,
#mainNavbar a.notif-btn{
  display:inline-flex !important;
  align-items:center !important;
  justify-content:center !important;
  min-height:26px !important;
  padding:3px 11px !important;
  font-family:var(--kf-body) !important;
  font-size:12px !important;
  font-weight:700 !important;
  line-height:1 !important;
  text-decoration:none !important;
  color:#13110e !important;
  background:rgba(255,255,255,.82) !important;
  border:1.5px solid rgba(0,0,0,.12) !important;
  border-radius:100px !important;
  box-sizing:border-box !important;
  transition:box-shadow .18s ease, transform .18s ease, border-color .18s ease, background .18s ease !important;
}

/* gap between pills */
#mainNavbar ul#nav > li,
#mainNavbar ul.kf-nav-row2 > li,
#mainNavbar ul.navbar-nav.ml-auto > li{
  margin:0 6px 0 0 !important;
  padding:0 !important;
}
#mainNavbar ul#nav > li:last-child,
#mainNavbar ul.kf-nav-row2 > li:last-child,
#mainNavbar ul.navbar-nav.ml-auto > li:last-child{margin-right:0 !important;}

#mainNavbar ul#nav > li > a:hover,
#mainNavbar ul.kf-nav-row2 > li > a:hover,
#mainNavbar ul.navbar-nav.ml-auto > li > a:hover,
#mainNavbar a.cart-btn:hover,
#mainNavbar a.notif-btn:hover{
  background:#fff !important;
  border-color:rgba(0,0,0,.22) !important;
  color:#13110e !important;
  box-shadow:0 4px 14px rgba(0,0,0,.12), 0 0 18px var(--kf-glow, rgba(34,160,74,.30)) !important;
  transform:translateY(-1px) !important;
  text-decoration:none !important;
}

#mainNavbar ul#nav > li.active > a,
#mainNavbar ul#nav > li > a.active{
  background:linear-gradient(135deg,var(--ca-accent),var(--ca-accent-dark)) !important;
  color:#fff !important;
  border-color:transparent !important;
}

#mainNavbar a.cart-btn .badge,
#mainNavbar a.cart-btn .badge-info,
.navbar-nav.toolbar a.cart-btn .badge-info,
#mainNavbar a.notif-btn .badge,
#mainNavbar a.notif-btn .badge-info,
.navbar-nav.toolbar a.notif-btn .badge-info{
  background-color:#00b4b4 !important;
  color:#fff !important;
  border-color:#00b4b4 !important;
  border-radius:100px !important;
  font-size:11px !important;
  font-weight:700 !important;
  padding:2px 6px !important;
  margin-left:4px !important;
}

#mainNavbar ul#nav > li > a,
#mainNavbar ul.kf-nav-row2 > li > a,
#mainNavbar ul.navbar-nav.ml-auto > li > a{--kf-glow:rgba(34,160,74,.30);}
#mainNavbar a.cart-btn{--kf-glow:rgba(0,180,180,.65);}
#mainNavbar a.notif-btn{--kf-glow:rgba(255,165,0,.55);}
#mainNavbar ul.navbar-nav.ml-auto > li > a.dropdown-toggle{--kf-glow:rgba(0,0,0,.55);}

/* Two-row layout */
@media (max-width:1199px){
  #mainNavbar.collapse:not(.show){display:none;}
  #mainNavbar.collapse.show{display:block;}
}
#mainNavbar > ul.kf-nav-row2{
  list-style:none !important;
  padding-left:0 !important;
  margin:8px 0 14px 0 !important;
  width:100% !important;
}
#mainNavbar > ul.kf-nav-row2 > li{margin:0 4px 4px 0 !important;padding:0 !important;}

@media (min-width:1200px){
  #mainNavbar.collapse{display:flex !important;flex-wrap:wrap !important;align-items:center !important;}
  #mainNavbar > ul#nav{flex:1 1 auto !important;width:auto !important;order:1 !important;}
  #mainNavbar > ul.navbar-nav.ml-auto{flex:0 0 auto !important;width:auto !important;order:2 !important;margin-left:auto !important;}
  #mainNavbar > ul.kf-nav-row2{
    display:flex !important;
    flex:0 0 100% !important;
    width:100% !important;
    order:3 !important;
    flex-wrap:wrap !important;
    gap:6px !important;
    margin:8px 0 14px 0 !important;
    padding-top:0 !important;
    border-top:none !important;
  }
}

/* Hide WHMCS overflow "More" */
#mainNavbar a#navbarDropdownMenu{display:none !important;}
#mainNavbar ul#nav > li:has(> a#navbarDropdownMenu){display:none !important;}

/* Mobile hamburger / cart */
.navbar.navbar-light .navbar-nav.toolbar .btn,
.navbar.navbar-light .navbar-nav.toolbar .nav-link{
  background:rgba(255,255,255,.82) !important;
  border:1.5px solid rgba(0,0,0,.12) !important;
  border-radius:100px !important;
  color:#13110e !important;
}

/* Topbar (logged in) */
.topbar{
  background:rgba(255,255,255,.45) !important;
  border-bottom:1px solid rgba(0,0,0,.06) !important;
  backdrop-filter:blur(6px);
}
.topbar .btn,
.topbar .input-group-text{
  background:transparent !important;
  border:1px solid rgba(0,0,0,.10) !important;
  color:#13110e !important;
  border-radius:8px !important;
  font-family:var(--kf-body);
  font-size:13px;
  font-weight:600;
}

/* ── GLOBAL CARD STYLE ─────────────────────────────────── */
.card{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  overflow:hidden;
  transition:.2s ease;
}
.card-header{
  background:var(--ca-surface2) !important;
  border-bottom:1px solid var(--ca-border) !important;
  padding:16px 24px !important;
}
.card-header .card-title,
.card-header h3{
  font-family:var(--kf-display);
  font-weight:800;
  letter-spacing:.02em;
  color:var(--ca-text);
  margin:0;
}
.card-body{padding:22px 24px;}

.card-columns.home .card{
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  transition:.2s ease;
}
.card-columns.home .card:hover{
  transform:translateY(-3px);
  box-shadow:var(--ca-shadow-md) !important;
  border-color:var(--ca-border2) !important;
}

/* ── BUTTONS ───────────────────────────────────────────── */
.btn-primary,.btn.btn-primary{
  background:var(--ca-accent) !important;
  border:1.5px solid var(--ca-accent) !important;
  color:#fff !important;
  border-radius:8px !important;
  font-family:var(--kf-body) !important;
  font-weight:700 !important;
  padding:10px 22px !important;
  box-shadow:var(--ca-shadow-green) !important;
  transition:.18s ease !important;
}
.btn-primary:hover,.btn.btn-primary:hover{
  background:var(--ca-accent-dark) !important;
  border-color:var(--ca-accent-dark) !important;
  transform:translateY(-1px);
  box-shadow:0 8px 28px rgba(34,160,74,.30) !important;
}
.btn-default,.btn.btn-default{
  background:var(--ca-surface2) !important;
  border:1.5px solid var(--ca-border) !important;
  color:var(--ca-text) !important;
  border-radius:8px !important;
  font-family:var(--kf-body) !important;
  font-weight:600 !important;
}
.btn-default:hover,.btn.btn-default:hover{
  background:#fff !important;
  border-color:var(--ca-border2) !important;
}
.btn-outline-primary{
  border:1.5px solid var(--ca-accent) !important;
  color:var(--ca-accent) !important;
  background:transparent !important;
  border-radius:8px !important;
  font-weight:700 !important;
}
.btn-outline-primary:hover{background:var(--ca-accent) !important;color:#fff !important;}

/* ── FORMS ─────────────────────────────────────────────── */
.form-control,
input.form-control,
select.form-control,
textarea.form-control{
  border:1.5px solid var(--ca-border) !important;
  border-radius:8px !important;
  font-family:var(--kf-body) !important;
  font-size:14px !important;
  padding:10px 14px !important;
  background:var(--ca-surface) !important;
  color:var(--ca-text) !important;
  transition:.15s ease !important;
  height:auto !important;
}
.form-control:focus{
  border-color:var(--ca-accent) !important;
  box-shadow:0 0 0 3px var(--ca-accent-bg) !important;
  outline:none !important;
}
.input-group-text{
  background:var(--ca-surface2) !important;
  border:1.5px solid var(--ca-border) !important;
  color:var(--ca-muted) !important;
  border-radius:8px !important;
}

/* ── ALERTS ────────────────────────────────────────────── */
.alert{
  border-radius:10px !important;
  font-family:var(--kf-body);
  font-size:14px;
  padding:14px 18px;
  border:1px solid var(--ca-border);
}
.alert-success{background:var(--ca-accent-bg) !important;border-color:var(--ca-accent-border) !important;color:var(--ca-accent-dark) !important;}
.alert-danger{background:rgba(204,40,40,.06) !important;border-color:rgba(204,40,40,.20) !important;color:#cc2828 !important;}
.alert-info{background:var(--ca-surface2) !important;border-color:var(--ca-border) !important;color:var(--ca-muted2) !important;}
.alert-warning{background:rgba(243,156,18,.08) !important;border-color:rgba(243,156,18,.25) !important;color:#9a6303 !important;}

/* ── TABLES ────────────────────────────────────────────── */
.table{background:var(--ca-surface) !important;border-radius:10px;overflow:hidden;}
.table thead th{
  background:var(--ca-surface2) !important;
  color:var(--ca-text) !important;
  border-bottom:1px solid var(--ca-border) !important;
  font-family:var(--kf-display);
  font-weight:800;
  letter-spacing:.02em;
  font-size:13px;
  text-transform:uppercase;
}
.table tbody td{border-color:var(--ca-border) !important;color:var(--ca-text) !important;}
.table-striped tbody tr:nth-of-type(odd){background:var(--ca-surface2) !important;}

/* ── HEADINGS ──────────────────────────────────────────── */
h1,h2,h3,h4,h5,.h1,.h2,.h3,.h4,.h5{
  font-family:var(--kf-display);
  font-weight:800;
  letter-spacing:-.01em;
  color:var(--ca-text);
}

/* ── HOMEPAGE ACTION TILES ─────────────────────────────── */
.row.my-5.action-icon-btns > div > a{
  display:block;
  border-radius:14px !important;
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  box-shadow:var(--ca-shadow-sm) !important;
  transition:.2s ease;
  color:var(--ca-text) !important;
  text-decoration:none !important;
}
.row.my-5.action-icon-btns > div > a:hover{
  transform:translateY(-3px);
  box-shadow:var(--ca-shadow-md) !important;
  border-color:var(--ca-accent-border) !important;
}
.row.my-5.action-icon-btns .ico-container i{color:var(--ca-accent) !important;}

/* ── SIDEBAR ───────────────────────────────────────────── */
.sidebar .list-group{border-radius:14px;overflow:hidden;border:1px solid var(--ca-border);}
.sidebar .list-group-item{
  background:var(--ca-surface) !important;
  border-color:var(--ca-border) !important;
  color:var(--ca-text) !important;
  font-family:var(--kf-body);
  font-weight:600;
}
.sidebar .list-group-item:hover{background:var(--ca-surface2) !important;color:var(--ca-text) !important;}
.sidebar .list-group-item.active{
  background:var(--ca-accent) !important;
  border-color:var(--ca-accent) !important;
  color:#fff !important;
}

/* ── LINKS ─────────────────────────────────────────────── */
a{color:var(--ca-accent);}
a:hover{color:var(--ca-accent-dark);}

/* ── DROPDOWNS ─────────────────────────────────────────── */
.dropdown-menu{
  border:1px solid var(--ca-border) !important;
  border-radius:10px !important;
  box-shadow:var(--ca-shadow-md) !important;
  background:var(--ca-surface) !important;
}
.dropdown-item{font-family:var(--kf-body);font-weight:600;color:var(--ca-text);}
.dropdown-item:hover{background:var(--ca-surface2);color:var(--ca-text);}

/* ── POPOVERS (notification pill dropdown, plus any other
       data-toggle="popover" usage) ─────────────────────── */
/* Bootstrap renders the notification panel as a .popover (not a
   .dropdown-menu) because the button uses data-toggle="popover".
   Mirror the dropdown look so the two trigger types feel consistent. */
.popover{
  border:1px solid var(--ca-border) !important;
  border-radius:10px !important;
  box-shadow:var(--ca-shadow-md) !important;
  background:var(--ca-surface) !important;
  font-family:var(--kf-body) !important;
  max-width:380px !important;
  padding:0 !important;
}
.popover .popover-header,
.popover .popover-title{
  background:var(--ca-surface2) !important;
  border-bottom:1px solid var(--ca-border) !important;
  border-radius:10px 10px 0 0 !important;
  font-family:'Barlow Condensed',sans-serif !important;
  font-weight:800 !important;
  font-size:15px !important;
  letter-spacing:.02em !important;
  text-transform:uppercase !important;
  color:var(--ca-text) !important;
  padding:12px 16px !important;
  margin:0 !important;
}
.popover .popover-body,
.popover .popover-content{
  padding:12px 16px !important;
  color:var(--ca-text) !important;
  font-size:13px !important;
}
.popover .popover-body a,
.popover .popover-content a{
  color:var(--ca-accent) !important;
  font-weight:600;
}
.popover .popover-body a:hover,
.popover .popover-content a:hover{
  color:var(--ca-accent-dark) !important;
}
/* Popover arrow — match the popover border color (Bootstrap 4 places
   the arrow via .arrow::before/::after pseudo-elements) */
.popover .arrow::before{border-bottom-color:var(--ca-border) !important;}
.popover .arrow::after{border-bottom-color:var(--ca-surface) !important;}
.popover.bs-popover-bottom .arrow::after{border-bottom-color:var(--ca-surface2) !important;}
.popover.bs-popover-top .arrow::before{border-top-color:var(--ca-border) !important;}
.popover.bs-popover-top .arrow::after{border-top-color:var(--ca-surface) !important;}

/* ── BADGES ────────────────────────────────────────────── */
.badge{
  border-radius:100px !important;
  font-family:var(--kf-body) !important;
  font-weight:700 !important;
  font-size:11px !important;
  padding:3px 10px !important;
}
.badge-info,.badge-primary{
  background:var(--ca-accent-bg) !important;
  color:var(--ca-accent-dark) !important;
  border:1px solid var(--ca-accent-border) !important;
}

/* ── BREADCRUMB (in-content) ───────────────────────────── */
.breadcrumb{background:transparent !important;font-family:var(--kf-body);font-size:13px;padding:8px 0;}
.breadcrumb-item.active{color:var(--ca-muted);}
.breadcrumb-item a{color:var(--ca-accent);}

/* ── PAGINATION ────────────────────────────────────────── */
.pagination .page-link{
  font-family:var(--kf-body);
  font-weight:600;
  padding:8px 14px;
  border:1.5px solid var(--ca-border);
  background:var(--ca-surface);
  color:var(--ca-muted);
  border-radius:8px !important;
  margin:0 2px;
}
.pagination .page-link:hover{background:var(--ca-surface2);border-color:var(--ca-border2);color:var(--ca-text);}
.pagination .page-item.active .page-link{background:var(--ca-accent);border-color:var(--ca-accent);color:#fff;}

/* ── TILES (clientarea quick stats) ────────────────────── */
.tiles .tile{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  margin:6px;
  padding:18px;
  text-decoration:none !important;
  color:var(--ca-text) !important;
  transition:.2s ease;
  display:block;
  position:relative;
  overflow:hidden;
}
.tiles .tile:hover{
  transform:translateY(-3px);
  box-shadow:var(--ca-shadow-md) !important;
  border-color:var(--ca-accent-border) !important;
}
.tiles .tile .stat{font-family:var(--kf-display);font-size:32px;font-weight:900;color:var(--ca-text);}
.tiles .tile .title{font-family:var(--kf-body);font-size:13px;font-weight:600;color:var(--ca-muted);text-transform:uppercase;letter-spacing:.08em;}
.tiles .tile i{color:var(--ca-accent);font-size:24px;margin-bottom:8px;}
.tiles .tile .highlight{display:none !important;}
</style>
{/literal}

{* Optional: addon-injected dynamic styles (logo paths, glow colors per item, custom background, accent override).
   IMPORTANT: The dynamic CSS is rendered at the END of footer.tpl (just before </body>) so it wins
   the cascade against page-specific :root blocks defined inside individual page templates
   (announcements.tpl, knowledgebase.tpl, etc.). Don't move this to head — page templates would override it. *}

</head>
<body class="primary-bg-color" data-phone-cc-input="{$phoneNumberInputStyle}">

    {* ===== Sitewide Announcement Bar — runs above EVERYTHING ===== *}
    {* Renders only when admin enabled the toggle AND set a message. The
       inline style attribute carries admin-picked bg + text colors so
       there's no per-render dynamic CSS injection just for this bar.
       Dismissable variant adds an × button; dismissal is persisted in
       localStorage under a key tied to the message hash so changing the
       message text auto-resets visitors who dismissed the old one. *}
    {if isset($kf_announcement_enabled) && $kf_announcement_enabled}
    <div class="kf-announcement-bar" data-key="kf-ann-{$kf_announcement_key}" style="background:{$kf_announcement_bg};color:{$kf_announcement_text};">
        <div class="kf-announcement-inner">
            <span class="kf-announcement-msg">{$kf_announcement_message nofilter}</span>
            {if $kf_announcement_dismissable}
            <button type="button" class="kf-announcement-close" aria-label="Dismiss announcement" style="color:{$kf_announcement_text};">×</button>
            {/if}
        </div>
    </div>
    {literal}
    <style>
    .kf-announcement-bar{position:relative;z-index:1050;font-family:'Outfit',sans-serif;font-size:13px;font-weight:500;text-align:center;padding:9px 16px;line-height:1.5;}
    .kf-announcement-bar.is-dismissed{display:none;}
    .kf-announcement-inner{max-width:1280px;margin:0 auto;display:flex;align-items:center;justify-content:center;gap:14px;position:relative;}
    .kf-announcement-msg{flex:0 1 auto;}
    .kf-announcement-msg a{color:inherit;text-decoration:underline;font-weight:700;}
    .kf-announcement-msg a:hover{opacity:.85;}
    .kf-announcement-close{position:absolute;right:0;top:50%;transform:translateY(-50%);background:transparent;border:0;font-size:22px;line-height:1;cursor:pointer;padding:0 6px;opacity:.7;font-weight:300;}
    .kf-announcement-close:hover{opacity:1;}
    @media (max-width:600px){.kf-announcement-bar{font-size:12px;padding:8px 38px 8px 14px;}.kf-announcement-close{right:6px;}}
    </style>
    <script>
    (function(){
      var bar = document.querySelector('.kf-announcement-bar');
      if (!bar) return;
      var key = bar.getAttribute('data-key');
      // Check localStorage on load — was this exact message already dismissed?
      try { if (key && localStorage.getItem(key) === '1') { bar.classList.add('is-dismissed'); return; } } catch(e){}
      var btn = bar.querySelector('.kf-announcement-close');
      if (!btn) return;
      btn.addEventListener('click', function(){
        bar.classList.add('is-dismissed');
        try { if (key) localStorage.setItem(key, '1'); } catch(e){}
      });
    })();
    </script>
    {/literal}
    {/if}

    {* ===== Background layer (set by addon: video / image / color / blank) ===== *}
    {if isset($kf_bg_type) && $kf_bg_type eq 'video' && $kf_bg_video}
        <video class="kf-bg-video"
               autoplay muted loop playsinline preload="auto"
               disablepictureinpicture
               controlslist="nodownload noplaybackrate noremoteplayback"
               tabindex="-1"
               aria-hidden="true">
            <source src="{$kf_bg_video}" type="video/mp4">
        </video>
        <div class="kf-bg-overlay"></div>
    {elseif isset($kf_bg_type) && $kf_bg_type eq 'image' && $kf_bg_image}
        <div class="kf-bg-image" style="background-image:url('{$kf_bg_image}');"></div>
        <div class="kf-bg-overlay"></div>
    {/if}

    {if $captcha}{$captcha->getMarkup()}{/if}
    {$headeroutput}

    {* ===== Optional centered top logo (set by addon) ===== *}
    {if isset($kf_top_logo) && $kf_top_logo}
        <div class="kf-top-logo-bar">
            <a href="{$WEB_ROOT}/index.php"><img src="{$kf_top_logo}" alt="{$companyname}"></a>
        </div>
    {/if}

    <header id="header" class="header">
        {* ===== Topbar removed =====
           Previously rendered the "1 Notifications" button + "Logged in as: X"
           bar above the logo when a client was logged in. The notification
           pill now lives inside the primary navbar (left of the cart) so it
           visually matches the rest of the nav and saves the vertical real
           estate. The "Return to admin area" link that lived here for admin
           masquerade is dropped — WHMCS still renders its own vertical
           "Return to admin area" tab on the right edge of the page in
           that scenario, which is a clearer indicator anyway.
        *}

        {* ===== Logo bar ===== *}
        {* When kf_logo_show is OFF, the entire <a class="navbar-brand">
           is suppressed — no logo image, no text, nothing. When ON,
           render the configured logo image, falling back to the
           WHMCS-assigned logo, then to the company name as text. *}
        <div class="navbar navbar-light">
            <div class="container">
                {if !isset($kf_logo_show) || $kf_logo_show}
                <a class="navbar-brand mr-3" href="{$WEB_ROOT}/index.php">
                    {if isset($kf_logo) && $kf_logo}
                        <img src="{$kf_logo}" alt="{$companyname}" class="logo-img">
                    {elseif $assetLogoPath}
                        <img src="{$assetLogoPath}" alt="{$companyname}" class="logo-img">
                    {else}
                        {$companyname}
                    {/if}
                </a>
                {/if}

                <ul class="navbar-nav toolbar">
                    {* Notifications (mobile) — separate ID so it doesn't
                       clash with the desktop popover initializer. Mobile
                       acts as a direct link to clientarea (popover would
                       be cramped on tiny screens); the same client alerts
                       are reachable from the account page. *}
                    {if $loggedin && (!isset($kf_notif_enabled) || $kf_notif_enabled)}
                        <li class="nav-item ml-3 d-xl-none">
                            <a class="btn nav-link notif-btn" href="{$WEB_ROOT}/clientarea.php" id="accountNotificationsMobile">
                                <i class="far fa-flag fa-fw"></i>
                                {if count($clientAlerts) > 0}
                                    <span class="badge badge-info">{count($clientAlerts)}</span>
                                {/if}
                                <span class="sr-only">{lang key='notifications'}</span>
                            </a>
                        </li>
                    {/if}
                    {* Cart (mobile only) *}
                    <li class="nav-item ml-3 d-xl-none">
                        <a class="btn nav-link cart-btn" href="{$WEB_ROOT}/cart.php?a=view">
                            <i class="far fa-shopping-cart fa-fw"></i>
                            <span id="cartItemCountMobile" class="badge badge-info">{$cartitemcount}</span>
                            <span class="sr-only">{lang key="carttitle"}</span>
                        </a>
                    </li>
                    {* Hamburger (mobile only) *}
                    <li class="nav-item ml-3 d-xl-none">
                        <button class="btn nav-link" type="button" data-toggle="collapse" data-target="#mainNavbar">
                            <span class="fas fa-bars fa-fw"></span>
                        </button>
                    </li>
                </ul>
            </div>
        </div>

        {* ===== Main nav ===== *}
        <div class="navbar navbar-expand-xl main-navbar-wrapper">
            <div class="container">
                <div class="collapse navbar-collapse" id="mainNavbar">

                    {* Mobile search *}
                    <form method="post" action="{routePath('knowledgebase-search')}" class="d-xl-none">
                        <div class="input-group search w-100 mb-2">
                            <div class="input-group-prepend">
                                <button class="btn btn-default" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                            <input class="form-control prepended-form-control" type="text" name="search" placeholder="{lang key="searchOurKnowledgebase"}...">
                        </div>
                    </form>

                    {* Primary navbar — addon decides icons + colors per item via $kf_nav1_items *}
                    {if isset($kf_nav1_items) && $kf_nav1_items && isset($primaryNavbar)}
                        {foreach $kf_nav1_items as $kf_n1}
                            {if $kf_n1.icon && $kf_n1.label}
                                {assign var=kf_navItem value=$primaryNavbar->getChild($kf_n1.label)}
                                {if $kf_navItem}{assign var=kf_tmp value=$kf_navItem->setIcon($kf_n1.icon)}{/if}
                            {/if}
                        {/foreach}
                    {/if}

                    <ul id="nav" class="navbar-nav mr-auto">
                        {include file="$template/includes/navbar.tpl" navbar=$primaryNavbar}
                    </ul>

                    {* ===== SECOND NAVBAR ROW (addon-controlled) =====
                       Renders only when the addon enables it AND items exist.
                       Items come from the addon as $kf_nav2_items: array of
                       { title, url, icon, icon_color, glow_color, target }
                       Per-item icon_color and glow_color are applied via the
                       addon's dynamic CSS (Renderer::dynamicCss) using
                       nth-child selectors — keeps markup clean and lets the
                       inline styles win the cascade against static rules. *}
                    {if isset($kf_nav2_enabled) && $kf_nav2_enabled && isset($kf_nav2_items) && $kf_nav2_items}
                        <ul class="navbar-nav kf-nav-row2">
                            {foreach $kf_nav2_items as $kf_item}
                                <li class="d-block no-collapse">
                                    <a class="pr-4" href="{$kf_item.url}"{if $kf_item.target} target="{$kf_item.target}" rel="noopener"{/if}>
                                        {if $kf_item.icon}<i class="{$kf_item.icon}"></i>&nbsp;&nbsp;{/if}{$kf_item.title}
                                    </a>
                                </li>
                            {/foreach}
                        </ul>
                    {/if}

                    <ul class="navbar-nav ml-auto">
                        {* Notifications pill (desktop) — only renders when a
                           client is logged in AND the addon has the notif
                           button enabled (defaults ON). Same #accountNotifications
                           ID + #accountNotificationsContent sibling as the
                           original topbar version so WHMCS's popover JS
                           initializer wires up automatically. *}
                        {if $loggedin && (!isset($kf_notif_enabled) || $kf_notif_enabled)}
                            <li class="nav-item d-none d-xl-block">
                                <a class="nav-link notif-btn" href="#" id="accountNotifications" data-toggle="popover" data-placement="bottom" role="button">
                                    <i class="far fa-flag fa-fw"></i>
                                    {if count($clientAlerts) > 0}
                                        <span class="badge badge-info">{count($clientAlerts)}</span>
                                    {/if}
                                    <span class="sr-only">{lang key='notifications'}</span>
                                </a>
                                <div id="accountNotificationsContent" class="w-hidden">
                                    <ul class="client-alerts">
                                    {foreach $clientAlerts as $alert}
                                        <li>
                                            <a href="{$alert->getLink()}">
                                                <i class="fas fa-fw fa-{if $alert->getSeverity() == 'danger'}exclamation-circle{elseif $alert->getSeverity() == 'warning'}exclamation-triangle{elseif $alert->getSeverity() == 'info'}info-circle{else}check-circle{/if}"></i>
                                                <div class="message">{$alert->getMessage()}</div>
                                            </a>
                                        </li>
                                    {foreachelse}
                                        <li class="none">{lang key='notificationsnone'}</li>
                                    {/foreach}
                                    </ul>
                                </div>
                            </li>
                        {/if}
                        {* Cart (desktop) *}
                        <li class="nav-item d-none d-xl-block">
                            <a class="nav-link cart-btn" href="{$WEB_ROOT}/cart.php?a=view">
                                <i class="far fa-shopping-cart fa-fw"></i>
                                <span id="cartItemCountDesktop" class="badge badge-info">{$cartitemcount}</span>
                                <span class="sr-only">{lang key="carttitle"}</span>
                            </a>
                        </li>
                        {include file="$template/includes/navbar.tpl" navbar=$secondaryNavbar rightDrop=true}
                    </ul>
                </div>
            </div>
        </div>
    </header>

    {include file="$template/includes/network-issues-notifications.tpl"}

    <nav class="master-breadcrumb" aria-label="breadcrumb">
        <div class="container">
            {include file="$template/includes/breadcrumb.tpl"}
        </div>
    </nav>

    {include file="$template/includes/validateuser.tpl"}
    {include file="$template/includes/verifyemail.tpl"}

    {if $templatefile == 'homepage'}
        {if $registerdomainenabled || $transferdomainenabled}
            {include file="$template/includes/domain-search.tpl"}
        {/if}
    {/if}

    <section id="main-body">
        <div class="{if !$skipMainBodyContainer}container{/if}">
            <div class="row">

            {if !$inShoppingCart && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}
                <div class="col-lg-4 col-xl-3">
                    <div class="sidebar">
                        {include file="$template/includes/sidebar.tpl" sidebar=$primarySidebar}
                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-none d-lg-block sidebar">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                </div>
            {/if}
            <div class="{if !$inShoppingCart && ($primarySidebar->hasChildren() || $secondarySidebar->hasChildren())}col-lg-8 col-xl-9{else}col-12{/if} primary-content">
