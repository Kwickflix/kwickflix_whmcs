HERO MARQUEE LOGO IMAGES
========================

Upload logo images for the homepage marquee here, then reference them in
the addon at Addons → KwickFlix Style → Homepage → Logo Marquee →
(per logo) → Image URL as:

    /templates/kwickflix/img/marquee/yourfile.svg

Recommended: SVG with transparent background (scales perfectly to any
height), or PNG ~200×80px with transparent background. Greyscale or
single-color logos work best because the marquee greyscale toggle in
the addon will normalize coloring across mixed sources.
