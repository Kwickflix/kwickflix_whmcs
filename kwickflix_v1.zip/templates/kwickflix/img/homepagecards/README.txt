HOMEPAGE CARD IMAGES
====================

Upload card images here, then reference them in the addon at
Addons → KwickFlix Style → Homepage → (per card) → Image URL as:

    /templates/kwickflix/img/homepagecards/yourfile.jpg

Recommended specs: ~600×400px, PNG or JPG, under 200KB for fast page loads.
