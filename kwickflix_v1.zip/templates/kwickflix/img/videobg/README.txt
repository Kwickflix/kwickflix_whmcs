WHOLE-SITE BACKGROUND VIDEOS
============================

Upload background video files here (MP4 only), then reference them in the
addon at Addons → KwickFlix Style → General → Whole-Site Background →
Background Video URL as:

    /templates/kwickflix/img/videobg/yourfile.mp4

Recommended: short looping clip, 10-30 seconds, H.264 MP4, 1920×1080 or
720p, under 5MB for fast load. Auto-plays muted, looped.
