NAVBAR + HERO LOGOS
===================

Upload your brand logos here, then reference them in the addon at
Addons → KwickFlix Style → Header → Logos:

  Header Logo URL — inside the navbar:
      /templates/kwickflix/img/logo/navbar-logo.png

  Top Centered Logo URL — big hero logo above the navbar:
      /templates/kwickflix/img/logo/hero-logo.png

Recommended specs:
  Navbar logo: transparent PNG or SVG, ~58px tall (will fit the navbar
               bar height with breathing room).
  Hero logo:   transparent PNG or SVG, up to 120px tall (sits above the
               navbar as a centered banner).

SVG is preferred for both — scales crisply on retina/4K displays without
needing @2x variants. Transparent background is required so the logo
sits cleanly over any whole-site background.
