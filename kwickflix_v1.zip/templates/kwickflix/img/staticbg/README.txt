WHOLE-SITE BACKGROUND IMAGES
============================

Upload background image files here, then reference them in the addon at
Addons → KwickFlix Style → General → Whole-Site Background →
Background Image URL as:

    /templates/kwickflix/img/staticbg/yourfile.jpg

Recommended: 1920×1080 or higher, PNG/JPG/WebP. JPG/WebP for photos,
PNG for graphics with transparency. Compress before upload.
