{include file="$template/includes/flashmessage.tpl"}

{literal}
<style>
/* ════════════════════════════════════════════════════════════
   KwickFlix — Client Area Home
   Stat tiles, custom info cards, and WHMCS built-in panels
   all share the design system tokens defined in header.tpl.
   This file only adds the layout/spacing rules — the colors,
   borders, and shadows reference --ca-* CSS variables.
   ════════════════════════════════════════════════════════════ */

/* Strip WHMCS's default panel chrome so our cards aren't double-bordered */
.panel,.panel-default,.panel-body,
.portlet,.portlet-body{
  background:transparent !important;
  border:none !important;
  box-shadow:none !important;
}

/* ────────────────────────────────────────────────────────────
   STAT TILES (top row — driven by $kf_stat_tiles from the addon)
   ──────────────────────────────────────────────────────────── */
.tiles{margin-bottom:28px !important;}
.tiles .row{gap:0;}

.tile{
  display:flex !important;
  flex-direction:column !important;
  align-items:flex-start !important;
  justify-content:flex-end !important;
  padding:22px 20px 18px !important;
  margin:6px !important;
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  text-decoration:none !important;
  color:var(--ca-text) !important;
  transition:.2s ease !important;
  position:relative !important;
  overflow:hidden !important;
  min-height:120px !important;
}
.tile:hover{
  transform:translateY(-3px) !important;
  box-shadow:var(--ca-shadow-md) !important;
  border-color:var(--ca-border2,var(--ca-border)) !important;
  color:var(--ca-text) !important;
  text-decoration:none !important;
}
.tile > i{
  position:absolute !important;
  top:16px !important;
  right:16px !important;
  font-size:28px !important;
  opacity:.12 !important;
  color:var(--ca-text) !important;
  transition:.2s ease !important;
}
.tile:hover > i{opacity:.22 !important;}
.tile .stat{
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:38px !important;
  font-weight:900 !important;
  line-height:1 !important;
  letter-spacing:-.02em !important;
  color:var(--ca-text) !important;
  margin-bottom:4px !important;
}
.tile .title{
  font-family:'Outfit',sans-serif !important;
  font-size:12px !important;
  font-weight:700 !important;
  text-transform:uppercase !important;
  letter-spacing:.1em !important;
  color:var(--ca-muted) !important;
}
/* Optional one-line note shown directly under the title. Kept smaller
   and lighter so the title remains the dominant element; admins use
   this for short context like "Click to manage" or "Open chat support". */
.tile .subtitle{
  font-family:'Outfit',sans-serif !important;
  font-size:10px !important;
  font-weight:500 !important;
  color:var(--ca-muted) !important;
  opacity:.78 !important;
  margin-top:3px !important;
  line-height:1.35 !important;
  text-transform:none !important;
  letter-spacing:0 !important;
}
.tile .highlight{
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  position:absolute !important;
  bottom:0 !important;
  left:0 !important;
  right:0 !important;
  top:auto !important;
  height:5px !important;
  border-radius:0 !important;
  width:100% !important;
  /* color comes from per-tile .kf-tilebar-N class emitted by Renderer
     in $kf_dynamic_css — matches the bg-color-X pattern WHMCS Six expects */
}

/* "no stat" — Live Chat etc. shows -- instead of a number */
.tile .stat-dashes{color:var(--ca-muted) !important;font-weight:700 !important;}

/* ────────────────────────────────────────────────────────────
   CUSTOM INFO CARDS (driven by $kf_info_cards from the addon)
   ──────────────────────────────────────────────────────────── */
.kf-info-card-wrap{margin-bottom:16px;}
.kf-info-card{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  box-shadow:var(--ca-shadow-sm);
  border-top:3px solid var(--ca-accent);
  overflow:hidden;
  font-family:'Outfit',sans-serif;
}
.kf-info-card-head{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:14px 20px;
  font-family:'Barlow Condensed',sans-serif;
  font-size:18px;
  font-weight:800;
  letter-spacing:.02em;
  color:var(--ca-text);
}
.kf-info-card-head i{margin-right:6px;}
.kf-info-card-body{
  padding:16px 20px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:16px;
  font-size:14px;
  color:var(--ca-muted);
}
.kf-info-card-body .kf-info-card-btn{
  display:inline-flex !important;
  align-items:center;
  justify-content:center;
  padding:8px 16px !important;
  font-size:13px !important;
  font-weight:600 !important;
  font-family:'Outfit',sans-serif !important;
  background:var(--ca-surface2) !important;
  color:var(--ca-text) !important;
  border:1.5px solid var(--ca-border) !important;
  border-radius:6px !important;
  text-decoration:none !important;
  transition:.15s ease;
  white-space:nowrap;
}
.kf-info-card-body .kf-info-card-btn:hover{
  background:var(--ca-surface3,var(--ca-surface2)) !important;
  border-color:var(--ca-border2,var(--ca-border)) !important;
}

@media(max-width:680px){
  .kf-info-card-body{flex-direction:column;align-items:stretch;}
  .kf-info-card-body .kf-info-card-btn{align-self:flex-end;}
}

/* ────────────────────────────────────────────────────────────
   WHMCS BUILT-IN PANELS (Active Products, Recent News, etc.)
   Card-accent-{color} classes still apply; Renderer's addon CSS
   overrides border-top-color per panel via [menuItemName] selector.
   ──────────────────────────────────────────────────────────── */
.client-home-cards .card{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  margin-bottom:16px !important;
  overflow:hidden !important;
  font-family:'Outfit',sans-serif;
}
.client-home-cards .card-header{
  background:var(--ca-surface2) !important;
  border-bottom:1px solid var(--ca-border) !important;
  padding:14px 20px !important;
}
.client-home-cards .card-title{
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:18px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--ca-text) !important;
  margin:0 !important;
}
/* Built-in WHMCS card-accent classes — kept for fallback when admin
   hasn't set a custom panel accent. Addon overrides via menuItemName. */
.client-home-cards .card-accent-blue {border-top:3px solid #1a6fff !important;}
.client-home-cards .card-accent-green{border-top:3px solid #22a04a !important;}
.client-home-cards .card-accent-red  {border-top:3px solid #cc2828 !important;}
.client-home-cards .card-accent-gold {border-top:3px solid #d97706 !important;}
.client-home-cards .card-accent-teal {border-top:3px solid #0d9488 !important;}

.client-home-cards .card-body{
  padding:16px 20px !important;
  font-size:14px !important;
  color:var(--ca-muted) !important;
}
.client-home-cards .list-group-item{
  background:var(--ca-surface) !important;
  border:none !important;
  border-bottom:1px solid var(--ca-border) !important;
  padding:12px 20px !important;
  font-size:14px !important;
  color:var(--ca-text) !important;
  font-family:'Outfit',sans-serif;
  transition:.15s ease !important;
}
.client-home-cards .list-group-item:last-child{border-bottom:none !important;}
.client-home-cards .list-group-item:hover,
.client-home-cards .list-group-item-action:hover{
  background:var(--ca-surface2) !important;
  color:var(--ca-text) !important;
  text-decoration:none !important;
}
</style>
{/literal}

{* ════════════════════════════════════════════════════════════
   STAT TILES — driven by $kf_stat_tiles from the addon
   Stat number comes from $clientsstats; sources are validated
   against a fixed whitelist on save (see kwickflixstyle.php).
   ════════════════════════════════════════════════════════════ *}
{if $kf_stat_tiles_enabled && $kf_stat_tiles}
    <div class="tiles mb-4">
        {* justify-content-center is a no-op when the row is full (4 tiles),
           but when there are 1/2/3 visible tiles it centers them in the row
           instead of leaving them stuck to the left. *}
        <div class="row no-gutters justify-content-center">
            {foreach from=$kf_stat_tiles item=kf_tile key=kf_tile_idx}
                <div class="col-6 col-xl-3">
                    <a href="{$kf_tile.url}" class="tile">
                        {if $kf_tile.icon}<i class="{$kf_tile.icon}"></i>{/if}
                        <div class="stat">
                            {if $kf_tile.stat eq 'services'}{$clientsstats.productsnumactive}
                            {elseif $kf_tile.stat eq 'domains'}{$clientsstats.numactivedomains}
                            {elseif $kf_tile.stat eq 'invoices'}{$clientsstats.numunpaidinvoices}
                            {elseif $kf_tile.stat eq 'tickets'}{$clientsstats.numactivetickets}
                            {elseif $kf_tile.stat eq 'affiliates'}{$clientsstats.numaffiliatesignups}
                            {elseif $kf_tile.stat eq 'quotes'}{$clientsstats.numquotes}
                            {elseif $kf_tile.stat eq 'credit'}{*
                                Credit balance — value computed by the
                                kwickflixstyle ClientAreaPage hook from
                                tblclients.credit (WHMCS doesn't expose
                                credit as a Smarty var in stock client-area
                                templates). Pre-formatted with the client's
                                currency via formatCurrency(). Smaller font
                                because currency strings are wider than the
                                single-integer counts the other branches
                                produce; without shrinking, "$1,234.56 USD"
                                blows out the tile.
                            *}<span style="font-size:.55em;letter-spacing:0;display:inline-block;line-height:1;">{if !empty($kf_client_credit)}{$kf_client_credit}{else}--{/if}</span>
                            {else}<span class="stat-dashes">--</span>
                            {/if}
                        </div>
                        <div class="title">{$kf_tile.title}</div>
                        {if !empty($kf_tile.subtext)}<div class="subtitle">{$kf_tile.subtext}</div>{/if}
                        {* ULTRA-DEFENSIVE accent bar — every single property inline
                           with !important. Nothing — not WHMCS Six's bundled CSS,
                           not Bootstrap, not theme overrides, NOTHING — can defeat
                           this short of disabling inline styles browser-wide. *}
                        <div class="highlight kf-tilebar-{$kf_tile_idx}" style="display:block !important;visibility:visible !important;opacity:1 !important;position:absolute !important;bottom:0 !important;left:0 !important;right:0 !important;top:auto !important;height:3px !important;width:100% !important;border-radius:0 !important;pointer-events:none !important;z-index:2 !important;background:{if $kf_tile.color}{$kf_tile.color}{else}#22a04a{/if} !important;background-color:{if $kf_tile.color}{$kf_tile.color}{else}#22a04a{/if} !important;"></div>
                    </a>
                </div>
            {/foreach}
        </div>
    </div>
{/if}

{foreach $addons_html as $addon_html}
    <div>{$addon_html}</div>
{/foreach}

{if $captchaError}
    <div class="alert alert-danger">{$captchaError}</div>
{/if}

{* ════════════════════════════════════════════════════════════
   CUSTOM INFO CARDS — driven by $kf_info_cards from the addon
   Renders only when section is enabled AND there are visible cards.
   ════════════════════════════════════════════════════════════ *}
{if $kf_info_cards_enabled && $kf_info_cards}
    {foreach $kf_info_cards as $kf_card name=infoCardsLoop}
        <div class="kf-info-card-wrap">
            <div class="kf-info-card" data-kf-info-idx="{$smarty.foreach.infoCardsLoop.iteration}"{if $kf_card.color} style="border-top-color:{$kf_card.color};"{/if}>
                <div class="kf-info-card-head">
                    {if $kf_card.icon}<i class="{$kf_card.icon}"></i>{/if}{$kf_card.title}
                </div>
                <div class="kf-info-card-body">
                    <div>{$kf_card.description}</div>
                    {if $kf_card.btn_text && $kf_card.btn_url}
                        <a href="{$kf_card.btn_url}" class="kf-info-card-btn">{$kf_card.btn_text}</a>
                    {/if}
                </div>
            </div>
        </div>
    {/foreach}
{/if}

{* ════════════════════════════════════════════════════════════
   BUILT-IN WHMCS PANELS — Active Products, Recent News,
   Affiliate Program, Recent Support Tickets. Accent colors set
   per-panel by the addon via [menuItemName="..."] CSS rules.
   ════════════════════════════════════════════════════════════ *}
<div class="client-home-cards">
    <div class="row">
        <div class="col-12">
            {function name=outputHomePanels}
                <div menuItemName="{$item->getName()}" class="card card-accent-{$item->getExtra('color')}{if $item->getClass()} {$item->getClass()}{/if}"{if $item->getAttribute('id')} id="{$item->getAttribute('id')}"{/if}>
                    <div class="card-header">
                        <h3 class="card-title m-0">
                            {if $item->getExtra('btn-link') && $item->getExtra('btn-text')}
                                <div class="float-right">
                                    <a href="{$item->getExtra('btn-link')}" class="btn btn-default bg-color-{$item->getExtra('color')} btn-xs">
                                        {if $item->getExtra('btn-icon')}<i class="{$item->getExtra('btn-icon')}"></i>{/if}
                                        {$item->getExtra('btn-text')}
                                    </a>
                                </div>
                            {/if}
                            {if $item->hasIcon()}<i class="{$item->getIcon()}"></i>&nbsp;{/if}
                            {$item->getLabel()}
                            {if $item->hasBadge()}&nbsp;<span class="badge">{$item->getBadge()}</span>{/if}
                        </h3>
                    </div>
                    {if $item->hasBodyHtml()}
                        <div class="card-body">{$item->getBodyHtml()}</div>
                    {/if}
                    {if $item->hasChildren()}
                        <div class="list-group{if $item->getChildrenAttribute('class')} {$item->getChildrenAttribute('class')}{/if}">
                            {foreach $item->getChildren() as $childItem}
                                {if $childItem->getUri()}
                                    <a menuItemName="{$childItem->getName()}" href="{$childItem->getUri()}" class="list-group-item list-group-item-action{if $childItem->getClass()} {$childItem->getClass()}{/if}{if $childItem->isCurrent()} active{/if}"{if $childItem->getAttribute('dataToggleTab')} data-toggle="tab"{/if}{if $childItem->getAttribute('target')} target="{$childItem->getAttribute('target')}"{/if} id="{$childItem->getId()}">
                                        {if $childItem->hasIcon()}<i class="{$childItem->getIcon()}"></i>&nbsp;{/if}
                                        {$childItem->getLabel()}
                                        {if $childItem->hasBadge()}&nbsp;<span class="badge">{$childItem->getBadge()}</span>{/if}
                                    </a>
                                {else}
                                    <div menuItemName="{$childItem->getName()}" class="list-group-item list-group-item-action{if $childItem->getClass()} {$childItem->getClass()}{/if}" id="{$childItem->getId()}">
                                        {if $childItem->hasIcon()}<i class="{$childItem->getIcon()}"></i>&nbsp;{/if}
                                        {$childItem->getLabel()}
                                        {if $childItem->hasBadge()}&nbsp;<span class="badge">{$childItem->getBadge()}</span>{/if}
                                    </div>
                                {/if}
                            {/foreach}
                        </div>
                    {/if}
                    <div class="card-footer">
                        {if $item->hasFooterHtml()}{$item->getFooterHtml()}{/if}
                    </div>
                </div>
            {/function}

            {foreach $panels as $item}
                {if $item->getExtra('colspan')}
                    {outputHomePanels}
                    {assign "panels" $panels->removeChild($item->getName())}
                {/if}
            {/foreach}
        </div>

        <div class="col-md-6 col-lg-12 col-xl-6">
            {foreach $panels as $item}
                {if $item@iteration is odd}{outputHomePanels}{/if}
            {/foreach}
        </div>

        <div class="col-md-6 col-lg-12 col-xl-6">
            {foreach $panels as $item}
                {if $item@iteration is even}{outputHomePanels}{/if}
            {/foreach}
        </div>
    </div>
</div>
