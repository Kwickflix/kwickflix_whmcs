{literal}
<style>
/* ============================================================
   KWICKFLIX FOOTER
   Layout matches the reference exactly: brand block on the left,
   3 configurable link columns on the right.
   All column titles, links, the description and logo come from
   the kwickflixstyle addon (defaults shown if addon is inactive).
   ============================================================ */

#footer.footer{
  background:linear-gradient(180deg,#161a20 0%,#101318 100%);
  color:rgba(255,255,255,0.78);
  padding:44px 0 30px;
  margin-top:34px;
  position:relative;
}

#footer .kf-footer-wrap{
  display:grid;
  /* Brand block on the left, link columns in a flex container on the right.
     The flex container can auto-center its children when there are fewer
     than 3 columns to display, instead of leaving empty grid tracks. */
  grid-template-columns:1.35fr 3fr;
  gap:34px;
  align-items:start;
}
#footer .kf-footer-cols-wrap{
  display:flex;
  justify-content:center;
  gap:34px;
  flex-wrap:wrap;
}
#footer .kf-footer-cols-wrap > .kf-footer-col{
  flex:1 1 0;
  min-width:0;
  max-width:240px;
}
/* When the cols wrap is empty (no columns enabled), hide it so the brand
   block can claim the full width naturally. */
#footer .kf-footer-cols-wrap:empty{display:none;}
#footer .kf-footer-wrap:has(.kf-footer-cols-wrap:empty){
  grid-template-columns:1fr;
}

/* Left brand column */
#footer .kf-footer-brand{display:flex;flex-direction:column;gap:14px;}
#footer .kf-footer-logo{display:flex;align-items:center;gap:12px;}
#footer .kf-footer-logo img{height:34px;width:auto;display:block;}
#footer .kf-footer-brand p{
  margin:0;
  font-size:13px;
  line-height:1.55;
  color:rgba(255,255,255,0.70);
  max-width:360px;
  font-family:'Outfit',sans-serif;
}

/* Menu columns */
#footer .kf-footer-col h6{
  margin:0 0 14px 0;
  font-size:14px;
  font-weight:900;
  color:#ffffff;
  font-family:'Barlow Condensed',sans-serif;
  letter-spacing:.04em;
  text-transform:uppercase;
}
#footer .kf-footer-links{
  list-style:none;
  padding:0;
  margin:0;
  display:flex;
  flex-direction:column;
  gap:10px;
}
#footer .kf-footer-links a{
  color:rgba(255,255,255,0.72);
  text-decoration:none;
  font-weight:600;
  font-size:13px;
  font-family:'Outfit',sans-serif;
  transition:color .15s ease;
}
#footer .kf-footer-links a:hover{color:#ffffff;text-decoration:none;}

/* Bottom bar */
#footer .kf-footer-bottom{
  margin-top:34px;
  padding-top:18px;
  border-top:1px solid rgba(255,255,255,0.08);
  display:flex;
  flex-direction:column;
  justify-content:center;
  align-items:center;
  text-align:center;
  gap:8px;
}
#footer .kf-footer-bottom .copyright{
  margin:0;
  font-size:12px;
  color:rgba(255,255,255,0.60);
  font-family:'Outfit',sans-serif;
}

/* Hide default WHMCS footer lists (social + nav) */
#footer .list-inline,
#footer .nav.justify-content-center{display:none !important;}

@media(max-width:992px){
  #footer .kf-footer-wrap{grid-template-columns:1fr 1fr;}
}
@media(max-width:576px){
  #footer .kf-footer-wrap{grid-template-columns:1fr;}
}
</style>
{/literal}

                    </div>

                    </div>
                    {if !$inShoppingCart && $secondarySidebar->hasChildren()}
                        <div class="d-lg-none sidebar sidebar-secondary">
                            {include file="$template/includes/sidebar.tpl" sidebar=$secondarySidebar}
                        </div>
                    {/if}
                <div class="clearfix"></div>
            </div>
        </div>
    </section>

    <footer id="footer" class="footer">
        <div class="container">

            <div class="kf-footer-wrap">

                {* ===== LEFT: Logo + short description ===== *}
                <div class="kf-footer-brand">
                    {if !isset($kf_footer_logo_show) || $kf_footer_logo_show}
                        <div class="kf-footer-logo">
                            {if isset($kf_footer_logo) && $kf_footer_logo}
                                <img src="{$kf_footer_logo}" alt="{$companyname}">
                            {elseif $assetLogoPath}
                                <img src="{$assetLogoPath}" alt="{$companyname}">
                            {else}
                                <strong style="color:#fff;font-family:'Barlow Condensed',sans-serif;font-size:22px;letter-spacing:.04em;">{$companyname}</strong>
                            {/if}
                        </div>
                    {else}
                        <div class="kf-footer-logo">
                            <strong style="color:#fff;font-family:'Barlow Condensed',sans-serif;font-size:22px;letter-spacing:.04em;">{$companyname}</strong>
                        </div>
                    {/if}

                    <p>
                        {if isset($kf_footer_description) && $kf_footer_description}
                            {$kf_footer_description}
                        {else}
                            <em style="color:rgba(255,255,255,0.45);">Set this short description in <strong>Addons → KwickFlix Style → Footer</strong>.</em>
                        {/if}
                    </p>
                </div>

                {* ===== Link columns wrapper =====
                   Wrapped in a single flex container so:
                   - Columns with no enabled links are skipped via {if}
                   - Remaining columns center themselves (justify-content:center)
                   - Brand block stays in its own grid track on the left      *}
                <div class="kf-footer-cols-wrap">
                    {if isset($kf_footer_col1_links) && $kf_footer_col1_links}
                    <div class="kf-footer-col">
                        <h6>{if isset($kf_footer_col1_icon) && $kf_footer_col1_icon}<i class="{$kf_footer_col1_icon}" style="margin-right:8px;"></i>{/if}{if isset($kf_footer_col1_title) && $kf_footer_col1_title}{$kf_footer_col1_title}{else}Column 1{/if}</h6>
                        <ul class="kf-footer-links">
                            {foreach $kf_footer_col1_links as $kf_link}
                                <li><a href="{$kf_link.url}"{if $kf_link.target} target="{$kf_link.target}" rel="noopener"{/if}>{$kf_link.label}</a></li>
                            {/foreach}
                        </ul>
                    </div>
                    {/if}

                    {if isset($kf_footer_col2_links) && $kf_footer_col2_links}
                    <div class="kf-footer-col">
                        <h6>{if isset($kf_footer_col2_icon) && $kf_footer_col2_icon}<i class="{$kf_footer_col2_icon}" style="margin-right:8px;"></i>{/if}{if isset($kf_footer_col2_title) && $kf_footer_col2_title}{$kf_footer_col2_title}{else}Column 2{/if}</h6>
                        <ul class="kf-footer-links">
                            {foreach $kf_footer_col2_links as $kf_link}
                                <li><a href="{$kf_link.url}"{if $kf_link.target} target="{$kf_link.target}" rel="noopener"{/if}>{$kf_link.label}</a></li>
                            {/foreach}
                        </ul>
                    </div>
                    {/if}

                    {if isset($kf_footer_col3_links) && $kf_footer_col3_links}
                    <div class="kf-footer-col">
                        <h6>{if isset($kf_footer_col3_icon) && $kf_footer_col3_icon}<i class="{$kf_footer_col3_icon}" style="margin-right:8px;"></i>{/if}{if isset($kf_footer_col3_title) && $kf_footer_col3_title}{$kf_footer_col3_title}{else}Column 3{/if}</h6>
                        <ul class="kf-footer-links">
                            {foreach $kf_footer_col3_links as $kf_link}
                                <li><a href="{$kf_link.url}"{if $kf_link.target} target="{$kf_link.target}" rel="noopener"{/if}>{$kf_link.label}</a></li>
                            {/foreach}
                        </ul>
                    </div>
                    {/if}
                </div>

            </div>

            <div class="kf-footer-bottom">
                <p class="copyright">{lang key="copyrightFooterNotice" year=$date_year company=$companyname}</p>
            </div>

        </div>
    </footer>

    <div id="fullpage-overlay" class="w-hidden">
        <div class="outer-wrapper">
            <div class="inner-wrapper">
                <img src="{$WEB_ROOT}/assets/img/overlay-spinner.svg" alt="">
                <br>
                <span class="msg"></span>
            </div>
        </div>
    </div>

    <div class="modal system-modal fade" id="modalAjax" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                        <span class="sr-only">{lang key='close'}</span>
                    </button>
                </div>
                <div class="modal-body">{lang key='loading'}</div>
                <div class="modal-footer">
                    <div class="float-left loader">
                        <i class="fas fa-circle-notch fa-spin"></i> {lang key='loading'}
                    </div>
                    <button type="button" class="btn btn-default" data-dismiss="modal">{lang key='close'}</button>
                    <button type="button" class="btn btn-primary modal-submit">{lang key='submit'}</button>
                </div>
            </div>
        </div>
    </div>

    <form method="get" action="{$currentpagelinkback}">
        <div class="modal modal-localisation" id="modalChooseLanguage" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <button type="button" class="close text-light" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>

                        {if $languagechangeenabled && count($locales) > 1}
                            <h5 class="h5 pt-5 pb-3">{lang key='chooselanguage'}</h5>
                            <div class="row item-selector">
                                <input type="hidden" name="language" data-current="{$language}" value="{$language}" />
                                {foreach $locales as $locale}
                                    <div class="col-4">
                                        <a href="#" class="item{if $language == $locale.language} active{/if}" data-value="{$locale.language}">
                                            {$locale.localisedName}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                        {if !$loggedin && $currencies}
                            <p class="h5 pt-5 pb-3">{lang key='choosecurrency'}</p>
                            <div class="row item-selector">
                                <input type="hidden" name="currency" data-current="{$activeCurrency.id}" value="">
                                {foreach $currencies as $selectCurrency}
                                    <div class="col-4">
                                        <a href="#" class="item{if $activeCurrency.id == $selectCurrency.id} active{/if}" data-value="{$selectCurrency.id}">
                                            {$selectCurrency.prefix} {$selectCurrency.code}
                                        </a>
                                    </div>
                                {/foreach}
                            </div>
                        {/if}
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-default">{lang key='apply'}</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    {if !$loggedin && $adminLoggedIn}
        <a href="{$WEB_ROOT}/logout.php?returntoadmin=1" class="btn btn-return-to-admin" data-toggle="tooltip" data-placement="bottom" title="{if $adminMasqueradingAsClient}{lang key='adminmasqueradingasclient'} {lang key='logoutandreturntoadminarea'}{else}{lang key='adminloggedin'} {lang key='returntoadminarea'}{/if}">
            <i class="fas fa-redo-alt"></i>
            <span class="d-none d-md-inline-block">{lang key="admin.returnToAdmin"}</span>
        </a>
    {/if}

    {include file="$template/includes/generate-password.tpl"}

    {$footeroutput}

    {* KwickFlix Style addon — dynamic overrides rendered AFTER all page-specific
       <style> blocks. Page templates redefine :root tokens (--ca-accent etc.)
       in their own scope, which would otherwise win against my header-loaded
       dynamic CSS. By rendering here at the end of <body>, mine comes last in
       source order and wins the :root cascade across every page. *}
    {if isset($kf_dynamic_css)}{$kf_dynamic_css}{/if}

    {* Admin's custom FOOTER HTML — chat widgets, deferred analytics,
       etc. Rendered as-is with nofilter because the admin is trusted. *}
    {if isset($kf_custom_footer_html) && $kf_custom_footer_html}{$kf_custom_footer_html nofilter}{/if}

</body>
</html>
