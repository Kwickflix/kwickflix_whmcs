{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --ca-surface:#fefdfb;
  --ca-surface2:#f7f5f0;
  --ca-surface3:#ede9e2;
  --ca-border:#d8d3cc;
  --ca-border2:#bfb8ae;
  --ca-text:#13110e;
  --ca-muted:#7a7268;
  --ca-muted2:#5a5249;
  --ca-accent:#22a04a;
  --ca-accent-dark:#167a36;
  --ca-accent-bg:rgba(34,160,74,.07);
  --ca-accent-border:rgba(34,160,74,.18);
  --ca-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --ca-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
}

/* ── ARTICLE CARD ── */
.kb-article-card{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  overflow:hidden !important;
  margin-bottom:20px;
}

/* ── ARTICLE HEADER ── */
.kb-article-header{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:24px 28px 20px;
}

.kb-article-title-row{
  display:flex;
  align-items:flex-start;
  justify-content:space-between;
  gap:20px;
  flex-wrap:wrap;
}

.kb-article-title{
  font-family:'Barlow Condensed',sans-serif;
  font-size:clamp(24px,4vw,36px);
  font-weight:900;
  letter-spacing:-.02em;
  color:var(--ca-text);
  line-height:1.05;
  margin:0;
  flex:1;
}

/* ── VOTE WIDGET ── */
.kb-vote-wrap{
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:6px;
  flex-shrink:0;
}

.kb-vote-label{
  font-family:'Outfit',sans-serif;
  font-size:11px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--ca-muted);
  white-space:nowrap;
}

.kb-vote-buttons{
  display:flex;
  gap:6px;
}

.kb-vote-buttons button[value="yes"],
.kb-vote-buttons button[value="no"]{
  border-radius:8px;
  padding:8px 14px;
  font-weight:600;
  font-family:'Outfit',sans-serif;
  font-size:13px;
  transition:.18s ease;
  cursor:pointer;
  border:1.5px solid;
}

.kb-vote-buttons button[value="yes"]{
  background:var(--ca-accent-bg);
  color:var(--ca-accent-dark);
  border-color:var(--ca-accent-border);
}

.kb-vote-buttons button[value="no"]{
  background:rgba(204,40,40,.06);
  color:#cc2828;
  border-color:rgba(204,40,40,.2);
}

.kb-vote-buttons button[value="yes"]:hover{
  background:var(--ca-accent) !important;
  color:#fff !important;
  border-color:var(--ca-accent) !important;
  transform:translateY(-1px);
  box-shadow:0 4px 12px rgba(34,160,74,.25);
}

.kb-vote-buttons button[value="no"]:hover{
  background:#cc2828 !important;
  color:#fff !important;
  border-color:#cc2828 !important;
  transform:translateY(-1px);
  box-shadow:0 4px 12px rgba(204,40,40,.2);
}

/* ── META ROW (tags + rating) ── */
.kb-article-meta{
  display:flex;
  align-items:center;
  flex-wrap:wrap;
  gap:12px;
  margin-top:14px;
}

/* tags */
.kb-tags{
  display:flex;
  flex-wrap:wrap;
  gap:5px;
}

.kb-tag{
  font-family:'Outfit',sans-serif;
  font-size:11px;
  font-weight:600;
  padding:3px 10px;
  border-radius:100px;
  letter-spacing:.03em;
  white-space:nowrap;
}

.kb-tag:nth-child(4n+1){background:rgba(26,111,255,.08);color:#1a4fff;border:1px solid rgba(26,111,255,.2);}
.kb-tag:nth-child(4n+2){background:var(--ca-accent-bg);color:var(--ca-accent-dark);border:1px solid var(--ca-accent-border);}
.kb-tag:nth-child(4n+3){background:rgba(212,96,10,.08);color:#a84d08;border:1px solid rgba(212,96,10,.2);}
.kb-tag:nth-child(4n+4){background:rgba(124,58,237,.08);color:#5b21b6;border:1px solid rgba(124,58,237,.2);}

/* rating + thank you */
.kb-rating{
  display:flex;
  align-items:center;
  gap:8px;
  font-family:'Outfit',sans-serif;
  font-size:13px;
  color:var(--ca-muted);
}

.kb-rating i{font-size:13px;}

.kb-thankyou{
  display:inline-flex;
  align-items:center;
  gap:6px;
  font-size:13px;
  font-weight:600;
  color:var(--ca-accent-dark);
  font-family:'Outfit',sans-serif;
  opacity:0;
  transform:translateY(-5px);
  animation:kfFadeIn .35s ease forwards;
}

@keyframes kfFadeIn{
  to{opacity:1;transform:translateY(0);}
}

/* ── ARTICLE BODY ── */
.kb-article-body{
  padding:28px 28px 32px;
}

/* article prose styles */
.kb-article-body article{
  font-family:'Outfit',sans-serif;
  font-size:15px;
  line-height:1.75;
  color:var(--ca-text);
}

.kb-article-body article h1,
.kb-article-body article h2,
.kb-article-body article h3{
  font-family:'Barlow Condensed',sans-serif;
  font-weight:800;
  letter-spacing:-.01em;
  color:var(--ca-text);
  margin:24px 0 10px;
}

.kb-article-body article h2{font-size:26px;}
.kb-article-body article h3{font-size:20px;}

.kb-article-body article p{margin-bottom:14px;}

.kb-article-body article a{
  color:var(--ca-accent);
  text-decoration:underline;
  text-underline-offset:2px;
}

.kb-article-body article ul,
.kb-article-body article ol{
  padding-left:22px;
  margin-bottom:14px;
}

.kb-article-body article li{margin-bottom:6px;}

.kb-article-body article code{
  background:var(--ca-surface2);
  border:1px solid var(--ca-border);
  border-radius:4px;
  padding:1px 6px;
  font-size:13px;
}

.kb-article-body article pre{
  background:var(--ca-surface2);
  border:1px solid var(--ca-border);
  border-radius:10px;
  padding:16px 18px;
  overflow-x:auto;
  font-size:13px;
  margin-bottom:14px;
}

.kb-article-body article img{
  max-width:100%;
  border-radius:8px;
  border:1px solid var(--ca-border);
}

.kb-article-body article blockquote{
  border-left:3px solid var(--ca-accent);
  padding:10px 18px;
  background:var(--ca-accent-bg);
  border-radius:0 8px 8px 0;
  margin:14px 0;
  font-style:italic;
  color:var(--ca-muted2);
}

/* divider */
.kb-article-body hr{
  border:none;
  border-top:1px solid var(--ca-border);
  margin:24px 0;
}

/* ── RELATED ARTICLES CARD ── */
.kb-related-card{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  overflow:hidden !important;
  margin-bottom:20px;
}

.kb-related-card .card-body{
  background:var(--ca-surface2) !important;
  border-bottom:1px solid var(--ca-border) !important;
  padding:16px 20px !important;
}

.kb-related-card .card-title{
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:20px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--ca-text) !important;
  margin:0 !important;
  display:flex;
  align-items:center;
  gap:8px;
}

.kb-related-card .fal.fa-folder-open{color:var(--ca-accent);}

.kb-article-item{
  display:block !important;
  padding:14px 20px !important;
  border:none !important;
  border-bottom:1px solid var(--ca-border) !important;
  background:var(--ca-surface) !important;
  color:var(--ca-text) !important;
  text-decoration:none !important;
  transition:.15s ease !important;
  font-family:'Outfit',sans-serif;
}

.kb-article-item:last-child{border-bottom:none !important;}
.kb-article-item:hover{background:var(--ca-surface2) !important;color:var(--ca-text) !important;text-decoration:none !important;padding-left:24px !important;}
.kb-article-item .fal.fa-file-alt{color:var(--ca-accent);margin-right:8px;}
.kb-article-item small{display:block !important;font-size:12px !important;color:var(--ca-muted) !important;margin-top:4px !important;padding-left:22px !important;line-height:1.5 !important;}
.kb-article-item .show-on-card-hover{font-size:11px !important;padding:2px 8px !important;border-radius:4px !important;font-family:'Outfit',sans-serif !important;font-weight:600 !important;background:var(--ca-surface2) !important;border:1px solid var(--ca-border) !important;color:var(--ca-muted) !important;margin-left:8px;}

.kb-related-card .list-group-item{
  background:var(--ca-surface) !important;
  border:none !important;
  padding:20px !important;
  font-size:14px !important;
  color:var(--ca-muted) !important;
  font-family:'Outfit',sans-serif;
  text-align:center;
}

/* ── FOOTER ACTIONS ── */
.kb-footer-actions{
  display:flex;
  align-items:center;
  justify-content:space-between;
  flex-wrap:wrap;
  gap:10px;
  margin-top:4px;
}

.kb-back-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 22px;
  background:var(--ca-surface);
  border:1.5px solid var(--ca-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  color:var(--ca-text) !important;
  text-decoration:none !important;
  transition:.18s ease;
  box-shadow:var(--ca-shadow-sm);
}
.kb-back-btn:hover{background:var(--ca-surface2);border-color:var(--ca-border2);transform:translateY(-1px);}

.kb-edit-btn{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:10px 18px;
  background:var(--ca-surface);
  border:1.5px solid var(--ca-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  color:var(--ca-muted) !important;
  text-decoration:none !important;
  transition:.18s ease;
}
.kb-edit-btn:hover{background:var(--ca-surface2);color:var(--ca-text) !important;}

@media(max-width:580px){
  .kb-article-header{padding:18px 18px 16px;}
  .kb-article-body{padding:20px 18px 24px;}
  .kb-article-title-row{flex-direction:column;gap:14px;}
  .kb-vote-wrap{align-items:flex-start;}
}
</style>
{/literal}

<div class="card kb-article-card">
    <div class="kb-article-header">
        <div class="kb-article-title-row">
            <h1 class="kb-article-title">{$kbarticle.title}</h1>

            {if !$kbarticle.voted}
            <div class="kb-vote-wrap">
                <div class="kb-vote-label">Was this helpful?</div>
                <form action="{routePath('knowledgebase-article-view', {$kbarticle.id}, {$kbarticle.urlfriendlytitle})}" method="post" class="kb-vote-buttons">
                    <input type="hidden" name="useful" value="vote">
                    <button class="btn btn-sm" type="submit" name="vote" value="yes">
                        <i class="fas fa-thumbs-up"></i>
                    </button>
                    <button class="btn btn-sm" type="submit" name="vote" value="no">
                        <i class="fas fa-thumbs-down"></i>
                    </button>
                </form>
            </div>
            {/if}
        </div>

        <div class="kb-article-meta">
            {if $kbarticle.tags}
                <div class="kb-tags">
                    {assign var=tags value=","|explode:$kbarticle.tags}
                    {foreach from=$tags item=tag}
                        <span class="kb-tag">{$tag|trim}</span>
                    {/foreach}
                </div>
            {/if}

            <div class="kb-rating">
                <i class="fas fa-thumbs-up"></i>
                {$kbarticle.useful}
                {if $kbarticle.voted}
                    <span class="kb-thankyou">
                        <i class="fas fa-check-circle"></i> Thanks for the rating!
                    </span>
                {/if}
            </div>
        </div>
    </div>

    <div class="kb-article-body">
        <article>
            {$kbarticle.text}
        </article>
    </div>
</div>

{if $kbarticles}
    <div class="card kb-related-card">
        <div class="card-body">
            <h3 class="card-title">
                <i class="fal fa-folder-open fa-fw"></i>
                {lang key='knowledgebaserelated'}
            </h3>
        </div>
        <div class="list-group list-group-flush">
            {foreach $kbarticles as $kbarticle}
                <a href="{routePath('knowledgebase-article-view', {$kbarticle.id}, {$kbarticle.urlfriendlytitle})}" class="list-group-item kb-article-item" data-id="{$kbarticle.id}">
                    <i class="fal fa-file-alt fa-fw"></i>
                    {$kbarticle.title}
                    {if $kbarticle.editLink}
                        <button class="btn btn-sm btn-default show-on-card-hover" id="btnEditArticle-{$kbarticle.id}" data-url="{$kbarticle.editLink}" type="button">
                            {lang key="edit"}
                        </button>
                    {/if}
                    <small>{$kbarticle.article|truncate:100:"..."}</small>
                </a>
            {foreachelse}
                <div class="list-group-item">
                    {lang key='knowledgebasenoarticles'}
                </div>
            {/foreach}
        </div>
    </div>
{/if}

<div class="kb-footer-actions">
    <a href="javascript:history.go(-1)" class="kb-back-btn">
        <i class="fas fa-arrow-left"></i> {lang key='clientareabacklink'}
    </a>
    {if $kbarticle.editLink}
        <a href="{$kbarticle.editLink}" class="kb-edit-btn">
            <i class="fas fa-pencil-alt"></i> {lang key='edit'}
        </a>
    {/if}
</div>
