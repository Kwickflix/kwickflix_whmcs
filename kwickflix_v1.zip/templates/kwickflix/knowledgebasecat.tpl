{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --ca-surface:#fefdfb;
  --ca-surface2:#f7f5f0;
  --ca-surface3:#ede9e2;
  --ca-border:#d8d3cc;
  --ca-border2:#bfb8ae;
  --ca-text:#13110e;
  --ca-muted:#7a7268;
  --ca-muted2:#5a5249;
  --ca-accent:#22a04a;
  --ca-accent-dark:#167a36;
  --ca-accent-bg:rgba(34,160,74,.07);
  --ca-accent-border:rgba(34,160,74,.18);
  --ca-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --ca-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
  --ca-shadow-green:0 6px 24px rgba(34,160,74,.22),0 2px 8px rgba(34,160,74,.1);
}

/* ── SEARCH BAR ── */
.kb-search-wrap{margin-bottom:36px;}
.kb-search-wrap .input-group{box-shadow:var(--ca-shadow-md);border-radius:10px;overflow:hidden;}
.kb-search-wrap .form-control{
  border:1.5px solid var(--ca-border) !important;
  border-right:none !important;
  border-radius:10px 0 0 10px !important;
  font-family:'Outfit',sans-serif !important;
  font-size:15px !important;
  font-weight:400 !important;
  padding:14px 18px !important;
  background:var(--ca-surface) !important;
  color:var(--ca-text) !important;
  height:auto !important;
  transition:.15s ease !important;
}
.kb-search-wrap .form-control:focus{border-color:var(--ca-accent) !important;box-shadow:none !important;outline:none !important;}
.kb-search-wrap .btn-primary{
  background:var(--ca-accent) !important;
  border:1.5px solid var(--ca-accent) !important;
  border-radius:0 10px 10px 0 !important;
  font-family:'Outfit',sans-serif !important;
  font-size:14px !important;
  font-weight:700 !important;
  padding:14px 24px !important;
  color:#fff !important;
  transition:.18s ease !important;
  white-space:nowrap;
}
.kb-search-wrap .btn-primary:hover{background:var(--ca-accent-dark) !important;border-color:var(--ca-accent-dark) !important;}

/* ── SECTION LABEL ── */
.kb-section-label{display:flex;align-items:center;gap:12px;margin-bottom:20px;}
.kb-section-label-text{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.2em;color:var(--ca-muted);white-space:nowrap;font-family:'Outfit',sans-serif;}
.kb-section-label-line{flex:1;height:1px;background:var(--ca-border);}

/* ── CATEGORY CARDS ── */
.kb-category{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  overflow:hidden !important;
  transition:.2s ease !important;
  margin-bottom:16px !important;
}
.kb-category:hover{border-color:var(--ca-accent-border) !important;box-shadow:var(--ca-shadow-md) !important;transform:translateY(-3px) !important;}
.kb-category .card-body{display:block !important;padding:20px 20px 18px !important;text-decoration:none !important;color:var(--ca-text) !important;background:transparent !important;border:none !important;}
.kb-category .card-body:hover{text-decoration:none !important;color:var(--ca-text) !important;}
.kb-category .card-body .h5{display:flex !important;align-items:center !important;gap:10px !important;font-family:'Barlow Condensed',sans-serif !important;font-size:18px !important;font-weight:800 !important;letter-spacing:.02em !important;color:var(--ca-text) !important;margin:0 0 8px !important;line-height:1.2 !important;}
.kb-category .fal.fa-folder{color:var(--ca-accent);}
.kb-category .badge{background:var(--ca-accent-bg) !important;color:var(--ca-accent-dark) !important;border:1px solid var(--ca-accent-border) !important;border-radius:100px !important;font-family:'Outfit',sans-serif !important;font-size:11px !important;font-weight:700 !important;padding:3px 10px !important;float:none !important;margin-left:auto !important;}
.kb-category p{font-size:13px !important;color:var(--ca-muted) !important;margin:0 !important;line-height:1.6 !important;font-family:'Outfit',sans-serif;}
.kb-category .show-on-card-hover,.kb-article-item .show-on-card-hover{font-size:11px !important;padding:2px 8px !important;border-radius:4px !important;font-family:'Outfit',sans-serif !important;font-weight:600 !important;background:var(--ca-surface2) !important;border:1px solid var(--ca-border) !important;color:var(--ca-muted) !important;margin-left:8px;}

/* ── ARTICLES CARD ── */
.kb-articles-card{
  background:var(--ca-surface) !important;
  border:1px solid var(--ca-border) !important;
  border-radius:14px !important;
  box-shadow:var(--ca-shadow-sm) !important;
  overflow:hidden !important;
  margin-bottom:20px;
}
.kb-articles-card .card-body{
  background:var(--ca-surface2) !important;
  border-bottom:1px solid var(--ca-border) !important;
  padding:16px 20px !important;
}
.kb-articles-card .card-title{
  font-family:'Barlow Condensed',sans-serif !important;
  font-size:20px !important;
  font-weight:800 !important;
  letter-spacing:.02em !important;
  color:var(--ca-text) !important;
  margin:0 !important;
  display:flex;
  align-items:center;
  gap:8px;
}
.kb-articles-card .fal.fa-folder-open{color:var(--ca-accent);}

/* ── ARTICLE LIST ITEMS ── */
.kb-article-item{
  display:block !important;
  padding:14px 20px !important;
  border:none !important;
  border-bottom:1px solid var(--ca-border) !important;
  background:var(--ca-surface) !important;
  color:var(--ca-text) !important;
  text-decoration:none !important;
  transition:.15s ease !important;
  font-family:'Outfit',sans-serif;
}
.kb-article-item:last-child{border-bottom:none !important;}
.kb-article-item:hover{background:var(--ca-surface2) !important;color:var(--ca-text) !important;text-decoration:none !important;padding-left:24px !important;}
.kb-article-item .fal.fa-file-alt{color:var(--ca-accent);margin-right:8px;flex-shrink:0;}
.kb-article-item small{display:block !important;font-size:12px !important;color:var(--ca-muted) !important;margin-top:4px !important;padding-left:22px !important;line-height:1.5 !important;}

/* empty state */
.kb-articles-card .list-group-item{
  background:var(--ca-surface) !important;
  border:none !important;
  padding:24px 20px !important;
  font-size:14px !important;
  color:var(--ca-muted) !important;
  font-family:'Outfit',sans-serif;
  text-align:center;
}

/* ── BACK BUTTON ── */
.kb-back-btn{
  display:inline-flex;
  align-items:center;
  gap:8px;
  padding:10px 22px;
  background:var(--ca-surface);
  border:1.5px solid var(--ca-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  color:var(--ca-text) !important;
  text-decoration:none !important;
  transition:.18s ease;
  box-shadow:var(--ca-shadow-sm);
}
.kb-back-btn:hover{background:var(--ca-surface2);border-color:var(--ca-border2);transform:translateY(-1px);}

.kb-edit-btn{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:10px 18px;
  background:var(--ca-surface);
  border:1.5px solid var(--ca-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  color:var(--ca-muted) !important;
  text-decoration:none !important;
  transition:.18s ease;
}
.kb-edit-btn:hover{background:var(--ca-surface2);color:var(--ca-text) !important;}

.kb-footer-actions{
  display:flex;
  align-items:center;
  justify-content:space-between;
  flex-wrap:wrap;
  gap:10px;
  margin-top:4px;
}

@media(max-width:580px){
  .kb-search-wrap .form-control{font-size:14px !important;padding:12px 14px !important;}
  .kb-search-wrap .btn-primary{padding:12px 16px !important;font-size:13px !important;}
}
</style>
{/literal}

<div class="kb-search-wrap">
    <form role="form" method="post" action="{routePath('knowledgebase-search')}">
        <div class="input-group input-group-lg kb-search">
            <input type="text" id="inputKnowledgebaseSearch" name="search" class="form-control font-weight-light" placeholder="{lang key='clientHomeSearchKb'}" value="{$searchterm}" />
            <div class="input-group-append">
                <button type="submit" id="btnKnowledgebaseSearch" class="btn btn-primary btn-input-padded-responsive">
                    <i class="fas fa-search"></i> {lang key='search'}
                </button>
            </div>
        </div>
    </form>
</div>

{if $kbcats}
    <div class="kb-section-label">
        <div class="kb-section-label-text">Browse Categories</div>
        <div class="kb-section-label-line"></div>
    </div>
    <div class="row">
        {foreach $kbcats as $category}
            <div class="col-xl-6">
                <div class="card kb-category">
                    <a href="{routePath('knowledgebase-category-view', {$category.id}, {$category.urlfriendlyname})}" class="card-body" data-id="{$category.id}">
                        <span class="h5 m-0">
                            <i class="fal fa-folder fa-fw"></i>
                            {$category.name}
                            {if $category.editLink}
                                <button class="btn btn-sm btn-default show-on-card-hover" id="btnEditCategory-{$category.id}" data-url="{$category.editLink}" type="button">
                                    {lang key="edit"}
                                </button>
                            {/if}
                            <span class="badge badge-info">
                                {lang key="knowledgebase.numArticle{if $category.numarticles != 1}s{/if}" num=$category.numarticles}
                            </span>
                        </span>
                        <p class="m-0 text-muted"><small>{$category.description}</small></p>
                    </a>
                </div>
            </div>
        {/foreach}
    </div>
{/if}

{if $kbarticles || !$kbcats}
    <div class="kb-section-label"{if $kbcats} style="margin-top:8px;"{/if}>
        <div class="kb-section-label-text">
            {if $tag}Articles Tagged '{$tag}'{else}Articles{/if}
        </div>
        <div class="kb-section-label-line"></div>
    </div>
    <div class="card kb-articles-card">
        <div class="card-body">
            <h3 class="card-title">
                <i class="fal fa-folder-open fa-fw"></i>
                {if $tag}
                    {lang key='kbviewingarticlestagged'} '{$tag}'
                {else}
                    {lang key='knowledgebasearticles'}
                {/if}
            </h3>
        </div>
        <div class="list-group list-group-flush">
            {foreach $kbarticles as $kbarticle}
                <a href="{routePath('knowledgebase-article-view', {$kbarticle.id}, {$kbarticle.urlfriendlytitle})}" class="list-group-item kb-article-item" data-id="{$kbarticle.id}">
                    <i class="fal fa-file-alt fa-fw"></i>
                    {$kbarticle.title}
                    {if $kbarticle.editLink}
                        <button class="btn btn-sm btn-default show-on-card-hover" id="btnEditArticle-{$kbarticle.id}" data-url="{$kbarticle.editLink}" type="button">
                            {lang key="edit"}
                        </button>
                    {/if}
                    <small>{$kbarticle.article|truncate:100:"..."}</small>
                </a>
            {foreachelse}
                <div class="list-group-item">
                    {lang key='knowledgebasenoarticles'}
                </div>
            {/foreach}
        </div>
    </div>
{/if}

<div class="kb-footer-actions">
    <a href="javascript:history.go(-1)" class="kb-back-btn">
        <i class="fas fa-arrow-left"></i> {lang key='clientareabacklink'}
    </a>
    {if $kbcurrentcat.editLink}
        <a href="{$kbcurrentcat.editLink}" class="kb-edit-btn">
            <i class="fas fa-pencil-alt"></i> {lang key='edit'}
        </a>
    {/if}
</div>
