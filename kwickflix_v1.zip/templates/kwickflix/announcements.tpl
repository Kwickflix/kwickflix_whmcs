{literal}
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800;900&family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>
:root{
  --ca-surface:#fefdfb;
  --ca-surface2:#f7f5f0;
  --ca-surface3:#ede9e2;
  --ca-border:#d8d3cc;
  --ca-border2:#bfb8ae;
  --ca-text:#13110e;
  --ca-muted:#7a7268;
  --ca-muted2:#5a5249;
  --ca-accent:#22a04a;
  --ca-accent-dark:#167a36;
  --ca-accent-bg:rgba(34,160,74,.07);
  --ca-accent-border:rgba(34,160,74,.18);
  --ca-shadow-sm:0 1px 3px rgba(19,17,14,.05),0 2px 8px rgba(19,17,14,.03);
  --ca-shadow-md:0 4px 16px rgba(19,17,14,.08),0 2px 6px rgba(19,17,14,.04);
}

/* ── WRAPPER ── */
.kf-announcements{
  padding:8px 0 40px;
  font-family:'Outfit',sans-serif;
}

/* ── PAGE TITLE ── */
.kf-section-label{
  display:flex;
  align-items:center;
  gap:12px;
  margin-bottom:28px;
}
.kf-section-label-text{
  font-family:'Barlow Condensed',sans-serif;
  font-size:clamp(28px,5vw,42px);
  font-weight:900;
  letter-spacing:-.02em;
  color:var(--ca-text);
  white-space:nowrap;
  line-height:1;
}
.kf-section-label-line{
  flex:1;
  height:1px;
  background:var(--ca-border);
}

/* ── ANNOUNCEMENT CARD ── */
.kf-announcement-card{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  overflow:hidden;
  margin-bottom:16px;
  box-shadow:var(--ca-shadow-sm);
  transition:.2s ease;
}

.kf-announcement-card:hover{
  transform:translateY(-3px);
  box-shadow:var(--ca-shadow-md);
  border-color:var(--ca-border2);
}

/* date strip */
.kf-card-date-strip{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:9px 20px;
  display:flex;
  align-items:center;
  gap:8px;
  font-size:12px;
  font-weight:600;
  color:var(--ca-muted);
  text-transform:uppercase;
  letter-spacing:.1em;
}

.kf-card-date-strip i{
  color:var(--ca-accent);
  font-size:11px;
}

/* card body */
.kf-card-inner{
  padding:20px 24px 22px;
}

.kf-announcement-header h3{
  margin:0 0 10px;
  line-height:1.2;
}

.kf-announcement-header h3 a{
  font-family:'Barlow Condensed',sans-serif;
  font-size:22px;
  font-weight:800;
  letter-spacing:-.01em;
  color:var(--ca-text);
  text-decoration:none;
  transition:.15s ease;
}

.kf-announcement-header h3 a:hover{
  color:var(--ca-accent);
  text-decoration:none;
}

/* body text */
.kf-announcement-body{
  font-size:14px;
  color:var(--ca-muted);
  line-height:1.75;
  margin-bottom:16px;
}

/* read more button */
.kf-btn{
  display:inline-flex;
  align-items:center;
  gap:6px;
  padding:9px 18px;
  background:var(--ca-surface2);
  color:var(--ca-text) !important;
  border:1.5px solid var(--ca-border);
  border-radius:8px;
  font-family:'Outfit',sans-serif;
  font-size:13px;
  font-weight:700;
  text-decoration:none !important;
  transition:.18s ease;
}

.kf-btn:hover{
  background:var(--ca-accent);
  color:#fff !important;
  border-color:var(--ca-accent);
  transform:translateY(-1px);
  box-shadow:0 4px 14px rgba(34,160,74,.25);
}

/* ── EMPTY STATE ── */
.kf-empty{
  text-align:center;
  padding:48px 24px;
  color:var(--ca-muted);
  font-size:15px;
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
}

.kf-empty i{
  font-size:40px;
  opacity:.25;
  display:block;
  margin-bottom:14px;
}

/* ── PAGINATION ── */
.kf-pagination{
  margin-top:28px;
  display:flex;
  justify-content:center;
}

.kf-pagination .pagination{
  gap:4px;
  display:flex;
  flex-wrap:wrap;
  justify-content:center;
}

.kf-pagination .page-item .page-link{
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:600;
  padding:8px 14px;
  border-radius:8px !important;
  border:1.5px solid var(--ca-border);
  background:var(--ca-surface);
  color:var(--ca-muted);
  transition:.15s ease;
  text-decoration:none;
}

.kf-pagination .page-item .page-link:hover{
  background:var(--ca-surface2);
  border-color:var(--ca-border2);
  color:var(--ca-text);
}

.kf-pagination .page-item.active .page-link{
  background:var(--ca-accent);
  border-color:var(--ca-accent);
  color:#fff;
}

.kf-pagination .page-item.disabled .page-link{
  opacity:.4;
  pointer-events:none;
}

@media(max-width:580px){
  .kf-card-inner{padding:16px 16px 18px;}
  .kf-announcement-header h3 a{font-size:20px;}
}
</style>
{/literal}

<div class="kf-announcements">

    <div class="kf-section-label">
        <div class="kf-section-label-text">Announcements</div>
        <div class="kf-section-label-line"></div>
    </div>

    {foreach $announcements as $announcement}
        <div class="kf-announcement-card">
            <div class="kf-card-date-strip">
                <i class="fas fa-calendar-alt"></i>
                {$carbon->createFromTimestamp($announcement.timestamp)->format('M j, Y')}
            </div>
            <div class="kf-card-inner">
                <div class="kf-announcement-header">
                    <h3>
                        <a href="{routePath('announcement-view', $announcement.id, $announcement.urlfriendlytitle)}">
                            {$announcement.title}
                        </a>
                    </h3>
                </div>
                <div class="kf-announcement-body">
                    {if $announcement.text|strip_tags|strlen < 350}
                        {$announcement.text}
                    {else}
                        {$announcement.summary}
                    {/if}
                </div>
                <a href="{routePath('announcement-view', $announcement.id, $announcement.urlfriendlytitle)}" class="kf-btn">
                    Read More <i class="fas fa-arrow-right"></i>
                </a>
            </div>
        </div>
    {foreachelse}
        <div class="kf-empty">
            <i class="fas fa-bullhorn"></i>
            No announcements yet.
        </div>
    {/foreach}

</div>

{if $prevpage || $nextpage}
<div class="kf-pagination">
    <ul class="pagination">
        {foreach $pagination as $item}
            <li class="page-item{if $item.disabled} disabled{/if}{if $item.active} active{/if}">
                <a class="page-link" href="{$item.link}">{$item.text}</a>
            </li>
        {/foreach}
    </ul>
</div>
{/if}
