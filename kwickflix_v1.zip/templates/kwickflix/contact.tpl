{literal}
<style>
.kf-contact-wrap{
  max-width:680px;
  margin:0 auto;
  padding:24px 16px 60px;
  font-family:'Outfit',sans-serif;
}
.kf-contact-card{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  box-shadow:var(--ca-shadow-md);
  overflow:hidden;
}
.kf-contact-header{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:24px 28px 20px;
}
.kf-contact-header h6{
  font-family:'Barlow Condensed',sans-serif;
  font-size:32px;
  font-weight:900;
  letter-spacing:-.02em;
  margin:0 0 4px;
  color:var(--ca-text);
}
.kf-contact-header p{margin:0;color:var(--ca-muted);font-size:14px;}
.kf-contact-body{padding:28px;}
.kf-contact-body label{
  font-size:12px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--ca-muted2);
  margin-bottom:6px;
  display:block;
}
.kf-contact-body .form-group{margin-bottom:18px;}
.kf-contact-actions{display:flex;justify-content:flex-end;gap:10px;}
</style>
{/literal}

<div class="kf-contact-wrap">
    <div class="kf-contact-card">
        <div class="kf-contact-header">
            <h6>{lang key='contactus'}</h6>
            <p>{lang key='readyforquestions'}</p>
        </div>

        <div class="kf-contact-body">
            {if $sent}
                {include file="$template/includes/alert.tpl" type="success" msg="{lang key='contactsent'}" textcenter=true}
            {/if}

            {if $errormessage}
                {include file="$template/includes/alert.tpl" type="error" errorshtml=$errormessage}
            {/if}

            {if !$sent}
                <form method="post" action="contact.php" role="form">
                    <input type="hidden" name="action" value="send" />

                    <div class="form-group">
                        <label for="inputName">{lang key='supportticketsclientname'}</label>
                        <input type="text" name="name" value="{$name}" class="form-control" id="inputName" />
                    </div>

                    <div class="form-group">
                        <label for="inputEmail">{lang key='supportticketsclientemail'}</label>
                        <input type="email" name="email" value="{$email}" class="form-control" id="inputEmail" />
                    </div>

                    <div class="form-group">
                        <label for="inputSubject">{lang key='supportticketsticketsubject'}</label>
                        <input type="text" name="subject" value="{$subject}" class="form-control" id="inputSubject" />
                    </div>

                    <div class="form-group">
                        <label for="inputMessage">{lang key='contactmessage'}</label>
                        <textarea name="message" rows="7" class="form-control" id="inputMessage">{$message}</textarea>
                    </div>

                    {if $captcha}
                        <div class="text-center mb-3">
                            {include file="$template/includes/captcha.tpl"}
                        </div>
                    {/if}

                    <div class="kf-contact-actions">
                        <button type="submit" class="btn btn-primary{$captcha->getButtonClass($captchaForm)}">{lang key='contactsend'}</button>
                    </div>
                </form>
            {/if}
        </div>
    </div>
</div>
