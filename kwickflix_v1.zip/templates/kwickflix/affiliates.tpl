{if $inactive}
    {include file="$template/includes/alert.tpl" type="danger" msg="{lang key='affiliatesdisabled'}" textcenter=true}
{else}

{* ════════════════════════════════════════════════════════════
   KWICKFLIX AFFILIATES PAGE
   All styles scoped to .kf-aff-wrap so nothing leaks. Uses the
   same design tokens as the rest of the template (ca-* vars,
   Barlow Condensed for numbers, Outfit for body). Global rules
   from header.tpl (.btn-primary, .table thead, etc.) carry
   through cleanly for the withdraw button and the referrals
   DataTable, so we only override what needs overriding.
   ════════════════════════════════════════════════════════════ *}
{literal}
<style>
.kf-aff-wrap{
    max-width:1080px;
    margin:0 auto;
    padding:8px 0 40px;
    font-family:'Outfit',sans-serif;
    color:var(--ca-text);
}

/* ── Section label (mirrors homepage section dividers) ─────────── */
.kf-aff-section{
    display:flex;
    align-items:center;
    gap:14px;
    margin:32px 0 16px;
}
.kf-aff-section:first-child{margin-top:8px;}
.kf-aff-section-text{
    font-size:11px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.2em;
    color:var(--ca-muted);
    white-space:nowrap;
}
.kf-aff-section-line{
    flex:1 1 auto;
    height:1px;
    background:var(--ca-border);
}

/* ── Top stats (clicks / signups / conversion) ─────────────────── */
.kf-aff-stats{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}
.kf-aff-stat{
    position:relative;
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:20px 22px;
    box-shadow:var(--ca-shadow-sm);
    overflow:hidden;
    transition:.2s ease;
}
.kf-aff-stat:hover{
    transform:translateY(-2px);
    box-shadow:var(--ca-shadow-md);
}
.kf-aff-stat::after{
    content:'';
    position:absolute;
    bottom:0;left:0;right:0;
    height:3px;
    background:var(--kf-aff-stat-color, var(--ca-accent));
}
.kf-aff-stat-icon{
    font-size:22px;
    color:var(--kf-aff-stat-color, var(--ca-accent));
    opacity:.85;
    margin-bottom:10px;
}
.kf-aff-stat-num{
    font-family:'Barlow Condensed',sans-serif;
    font-size:40px;
    font-weight:900;
    line-height:1;
    letter-spacing:-.02em;
    color:var(--ca-text);
    margin-bottom:6px;
}
.kf-aff-stat-label{
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.12em;
    color:var(--ca-muted);
}

/* ── Referral link card ─────────────────────────────────────────── */
.kf-aff-refcard{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:22px 24px;
    box-shadow:var(--ca-shadow-sm);
}
.kf-aff-refcard-head{
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom:14px;
}
.kf-aff-refcard-head i{
    color:var(--ca-accent);
    font-size:18px;
}
.kf-aff-refcard-head h3{
    font-family:'Barlow Condensed',sans-serif;
    font-size:22px;
    font-weight:800;
    letter-spacing:-.01em;
    color:var(--ca-text);
    margin:0;
}
.kf-aff-link-row{
    display:flex;
    gap:8px;
    align-items:stretch;
}
.kf-aff-link-row input{
    flex:1 1 auto;
    background:var(--ca-surface2) !important;
    border:1.5px solid var(--ca-border) !important;
    border-radius:8px !important;
    padding:10px 14px !important;
    font-family:'JetBrains Mono','Menlo','Consolas',monospace;
    font-size:13px !important;
    color:var(--ca-text) !important;
    height:auto !important;
}
.kf-aff-link-row input:focus{
    border-color:var(--ca-accent) !important;
    box-shadow:0 0 0 3px var(--ca-accent-bg) !important;
    outline:none !important;
}
.kf-aff-copy-btn{
    flex:0 0 auto;
    background:var(--ca-accent);
    color:#fff;
    border:1.5px solid var(--ca-accent);
    border-radius:8px;
    padding:10px 18px;
    font-family:'Outfit',sans-serif;
    font-weight:700;
    font-size:13px;
    cursor:pointer;
    transition:.18s ease;
    display:inline-flex;
    align-items:center;
    gap:8px;
    box-shadow:var(--ca-shadow-green);
}
.kf-aff-copy-btn:hover{
    background:var(--ca-accent-dark);
    border-color:var(--ca-accent-dark);
    transform:translateY(-1px);
}
.kf-aff-copy-btn.is-copied{
    background:#0f8a3a;
    border-color:#0f8a3a;
}
.kf-aff-refcard-hint{
    margin:10px 0 0;
    font-size:12px;
    color:var(--ca-muted);
}

/* ── Earnings summary (pending / available / withdrawn) ────────── */
.kf-aff-earnings{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:14px;
}
.kf-aff-earning{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:20px 22px;
    box-shadow:var(--ca-shadow-sm);
    text-align:center;
    position:relative;
    overflow:hidden;
}
.kf-aff-earning::after{
    content:'';
    position:absolute;
    bottom:0;left:0;right:0;
    height:3px;
    background:var(--kf-aff-earn-color, var(--ca-muted));
}
.kf-aff-earning-label{
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.12em;
    color:var(--ca-muted);
    margin-bottom:8px;
}
.kf-aff-earning-amount{
    font-family:'Barlow Condensed',sans-serif;
    font-size:30px;
    font-weight:900;
    line-height:1;
    letter-spacing:-.01em;
    color:var(--ca-text);
}

/* ── Withdraw CTA ──────────────────────────────────────────────── */
.kf-aff-withdraw{
    text-align:center;
    margin:24px 0 8px;
}
.kf-aff-withdraw .kf-aff-withdraw-btn{
    display:inline-flex;
    align-items:center;
    gap:10px;
    padding:14px 32px;
    background:linear-gradient(135deg,var(--ca-accent),var(--ca-accent-dark));
    color:#fff !important;
    border:0;
    border-radius:10px;
    font-family:'Outfit',sans-serif;
    font-weight:700;
    font-size:15px;
    letter-spacing:.02em;
    cursor:pointer;
    box-shadow:var(--ca-shadow-green);
    transition:.18s ease;
    text-decoration:none !important;
}
.kf-aff-withdraw .kf-aff-withdraw-btn:hover:not(:disabled){
    transform:translateY(-2px);
    box-shadow:0 10px 32px rgba(34,160,74,.32);
}
.kf-aff-withdraw .kf-aff-withdraw-btn:disabled,
.kf-aff-withdraw .kf-aff-withdraw-btn.is-disabled{
    background:var(--ca-surface3);
    color:var(--ca-muted) !important;
    box-shadow:none;
    cursor:not-allowed;
    opacity:.75;
}
.kf-aff-withdraw-note{
    margin:12px 0 0;
    font-size:12px;
    color:var(--ca-muted);
}

/* ── Withdraw success banner ───────────────────────────────────── */
.kf-aff-withdraw-success{
    display:flex;
    align-items:center;
    gap:12px;
    background:var(--ca-accent-bg);
    border:1px solid var(--ca-accent-border);
    color:var(--ca-accent-dark);
    border-radius:12px;
    padding:14px 18px;
    font-weight:600;
    font-size:14px;
    margin-bottom:18px;
}
.kf-aff-withdraw-success i{font-size:18px;}

/* ── Referrals table wrapper ───────────────────────────────────── */
.kf-aff-table-wrap{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:8px 14px;
    box-shadow:var(--ca-shadow-sm);
    overflow:hidden;
}
.kf-aff-table-wrap .table{
    margin:0;
    border:0;
    background:transparent !important;
}
.kf-aff-table-wrap .table th{
    border-top:0 !important;
}
.kf-aff-table-wrap .dataTables_wrapper{padding:6px 4px;}
.kf-aff-table-wrap .dataTables_filter input{
    border:1.5px solid var(--ca-border) !important;
    border-radius:8px !important;
    padding:6px 12px !important;
    margin-left:8px;
}
.kf-aff-table-wrap .dataTables_length select{
    border:1.5px solid var(--ca-border) !important;
    border-radius:8px !important;
    padding:4px 10px !important;
}
.kf-aff-table-wrap #tableLoading{padding:24px 0;}
.kf-aff-table-wrap .label.status{
    display:inline-block;
    padding:3px 10px;
    border-radius:100px;
    font-size:11px;
    font-weight:700;
    letter-spacing:.04em;
}
.kf-aff-table-wrap .status-pending{background:rgba(243,156,18,.12);color:#9a6303;}
.kf-aff-table-wrap .status-confirmed{background:var(--ca-accent-bg);color:var(--ca-accent-dark);}
.kf-aff-table-wrap .status-cancelled{background:rgba(204,40,40,.10);color:#cc2828;}

/* ── Linkscode block ───────────────────────────────────────────── */
.kf-aff-linkscode{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:22px 24px;
    box-shadow:var(--ca-shadow-sm);
    text-align:center;
}

/* ── Responsive ────────────────────────────────────────────────── */
@media (max-width:768px){
    .kf-aff-stats,
    .kf-aff-earnings{grid-template-columns:1fr;}
    .kf-aff-link-row{flex-direction:column;}
    .kf-aff-stat-num{font-size:34px;}
    .kf-aff-earning-amount{font-size:26px;}
}
</style>
{/literal}

<div class="kf-aff-wrap">

    {include file="$template/includes/flashmessage.tpl"}

    {if $withdrawrequestsent}
        <div class="kf-aff-withdraw-success">
            <i class="fas fa-check-circle"></i>
            <span>{lang key='affiliateswithdrawalrequestsuccessful'}</span>
        </div>
    {/if}

    {* ── Top stats row ─────────────────────────────────────────── *}
    <div class="kf-aff-section">
        <div class="kf-aff-section-text">Performance</div>
        <div class="kf-aff-section-line"></div>
    </div>

    <div class="kf-aff-stats">
        <div class="kf-aff-stat" style="--kf-aff-stat-color:#1a8ee6;">
            <div class="kf-aff-stat-icon"><i class="fas fa-mouse-pointer"></i></div>
            <div class="kf-aff-stat-num">{$visitors}</div>
            <div class="kf-aff-stat-label">{lang key='affiliatesclicks'}</div>
        </div>

        <div class="kf-aff-stat" style="--kf-aff-stat-color:#e96a0b;">
            <div class="kf-aff-stat-icon"><i class="fas fa-user-plus"></i></div>
            <div class="kf-aff-stat-num">{$signups}</div>
            <div class="kf-aff-stat-label">{lang key='affiliatessignups'}</div>
        </div>

        <div class="kf-aff-stat" style="--kf-aff-stat-color:#22a04a;">
            <div class="kf-aff-stat-icon"><i class="fas fa-percentage"></i></div>
            <div class="kf-aff-stat-num">{$conversionrate}%</div>
            <div class="kf-aff-stat-label">{lang key='affiliatesconversionrate'}</div>
        </div>
    </div>

    {* ── Referral link card with copy-to-clipboard ─────────────── *}
    <div class="kf-aff-section">
        <div class="kf-aff-section-text">Your Referral Link</div>
        <div class="kf-aff-section-line"></div>
    </div>

    <div class="kf-aff-refcard">
        <div class="kf-aff-refcard-head">
            <i class="fas fa-link"></i>
            <h3>{lang key='affiliatesreferallink'}</h3>
        </div>
        <div class="kf-aff-link-row">
            <input type="text" id="kfAffRefLink" readonly value="{$referrallink}">
            <button type="button" class="kf-aff-copy-btn" id="kfAffCopyBtn" data-clipboard-target="#kfAffRefLink">
                <i class="far fa-clone"></i>
                <span>Copy</span>
            </button>
        </div>
        <p class="kf-aff-refcard-hint">Share this link anywhere. You earn commission on every signup that comes through it.</p>
    </div>

    {* ── Earnings summary ──────────────────────────────────────── *}
    <div class="kf-aff-section">
        <div class="kf-aff-section-text">Commissions</div>
        <div class="kf-aff-section-line"></div>
    </div>

    <div class="kf-aff-earnings">
        <div class="kf-aff-earning" style="--kf-aff-earn-color:#d97706;">
            <div class="kf-aff-earning-label">{lang key='affiliatescommissionspending'}</div>
            <div class="kf-aff-earning-amount">{$pendingcommissions}</div>
        </div>
        <div class="kf-aff-earning" style="--kf-aff-earn-color:#22a04a;">
            <div class="kf-aff-earning-label">{lang key='affiliatescommissionsavailable'}</div>
            <div class="kf-aff-earning-amount">{$balance}</div>
        </div>
        <div class="kf-aff-earning" style="--kf-aff-earn-color:#7a7268;">
            <div class="kf-aff-earning-label">{lang key='affiliateswithdrawn'}</div>
            <div class="kf-aff-earning-amount">{$withdrawn}</div>
        </div>
    </div>

    {* ── Withdraw button ───────────────────────────────────────── *}
    {if !$withdrawrequestsent}
        <div class="kf-aff-withdraw">
            <form method="POST" action="{$smarty.server.PHP_SELF}" style="margin:0;">
                <input type="hidden" name="action" value="withdrawrequest" />
                <button type="submit"
                        class="kf-aff-withdraw-btn{if !$withdrawlevel} is-disabled{/if}"
                        {if !$withdrawlevel}disabled="disabled"{/if}>
                    <i class="fas fa-university"></i>
                    {lang key='affiliatesrequestwithdrawal'}
                </button>
            </form>
            {if !$withdrawlevel}
                <p class="kf-aff-withdraw-note">{lang key="affiliateWithdrawalSummary" amountForWithdrawal=$affiliatePayoutMinimum}</p>
            {/if}
        </div>
    {/if}

    {* ── Referrals table ───────────────────────────────────────── *}
    <div class="kf-aff-section">
        <div class="kf-aff-section-text">{lang key='affiliatesreferals'}</div>
        <div class="kf-aff-section-line"></div>
    </div>

    {include file="$template/includes/tablelist.tpl" tableName="AffiliatesList"}
    <script>
        jQuery(document).ready(function() {
            var table = jQuery('#tableAffiliatesList').show().DataTable();

            {if $orderby == 'regdate'}
                table.order(0, '{$sort}');
            {elseif $orderby == 'product'}
                table.order(1, '{$sort}');
            {elseif $orderby == 'amount'}
                table.order(2, '{$sort}');
            {elseif $orderby == 'status'}
                table.order(4, '{$sort}');
            {/if}
            table.draw();
            jQuery('#tableLoading').hide();
        });

        /* Copy-to-clipboard for the referral link. Falls back to the
           legacy execCommand path on browsers without navigator.clipboard
           (older Safari / non-HTTPS dev installs). */
        {literal}
        (function(){
            var btn = document.getElementById('kfAffCopyBtn');
            var inp = document.getElementById('kfAffRefLink');
            if (!btn || !inp) return;
            btn.addEventListener('click', function(){
                var val = inp.value;
                var done = function(){
                    btn.classList.add('is-copied');
                    var span = btn.querySelector('span');
                    var orig = span ? span.textContent : 'Copy';
                    if (span) span.textContent = 'Copied!';
                    setTimeout(function(){
                        btn.classList.remove('is-copied');
                        if (span) span.textContent = orig;
                    }, 1600);
                };
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(val).then(done).catch(function(){
                        inp.select(); document.execCommand('copy'); done();
                    });
                } else {
                    inp.select(); document.execCommand('copy'); done();
                }
            });
        })();
        {/literal}
    </script>

    <div class="kf-aff-table-wrap">
        <table id="tableAffiliatesList" class="table table-list w-hidden">
            <thead>
                <tr>
                    <th>{lang key='affiliatessignupdate'}</th>
                    <th>{lang key='orderproduct'}</th>
                    <th>{lang key='affiliatesamount'}</th>
                    <th>{lang key='affiliatescommission'}</th>
                    <th>{lang key='affiliatesstatus'}</th>
                </tr>
            </thead>
            <tbody>
            {foreach $referrals as $referral}
                <tr>
                    <td><span class="w-hidden">{$referral.datets}</span>{$referral.date}</td>
                    <td>{$referral.service}</td>
                    <td data-order="{$referral.amountnum}">{$referral.amountdesc}</td>
                    <td data-order="{$referral.commissionnum}">{$referral.commission}</td>
                    <td><span class="label status status-{$referral.rawstatus|strtolower}">{$referral.status}</span></td>
                </tr>
            {/foreach}
            </tbody>
        </table>
        <div class="text-center" id="tableLoading">
            <p><i class="fas fa-spinner fa-spin"></i> {lang key='loading'}</p>
        </div>
    </div>

    {* ── Promotional link codes ────────────────────────────────── *}
    {if $affiliatelinkscode}
        <div class="kf-aff-section">
            <div class="kf-aff-section-text">{lang key='affiliateslinktous'}</div>
            <div class="kf-aff-section-line"></div>
        </div>
        <div class="kf-aff-linkscode">
            {$affiliatelinkscode}
        </div>
    {/if}

</div>

{/if}
