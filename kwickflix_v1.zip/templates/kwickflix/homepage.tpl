{* /templates/kwickflix/homepage.tpl
   Stripped of all default WHMCS panels. Renders up to 6 fully
   customizable cards driven by the kwickflixstyle addon.
   See $kf_homepage_cards (array) populated by hooks.php. *}

{literal}
<style>
/* ════════════════════════════════════════════════════════════
   KWICKFLIX HOMEPAGE — CARD GRID
   Each card has its own accent color via inline --card-accent
   ════════════════════════════════════════════════════════════ */

.kf-hp-wrap{
  max-width:1120px;
  margin:0 auto;
  padding:0 20px 80px;
  font-family:'Outfit',sans-serif;
}

/* section label */
.kf-hp-section-label{
  display:flex !important;
  align-items:center !important;
  gap:14px !important;
  margin:0 0 22px !important;
  width:100%;
}
.kf-hp-section-label-text{
  font-family:'Outfit', 'Helvetica Neue', sans-serif;
  font-size:11px;
  font-weight:800;
  text-transform:uppercase;
  letter-spacing:.2em;
  color:var(--ca-muted, #7a7268);
  white-space:nowrap;
  flex:0 0 auto !important;
}
.kf-hp-section-label-line{
  flex:1 1 auto !important;
  height:1px !important;
  min-width:60px !important;
  background:var(--ca-border, #d8d3cc) !important;
  display:block !important;
}

/* grid — flex so partial rows center themselves
   1 card → centered. 2 cards → centered as a pair.
   3 cards → fills the row. 4 cards → row 1 fills, 4th card centers on row 2.
   5 cards → row 1 fills, row 2 has 2 centered cards. Etc. */
.kf-hp-cards-grid{
  display:flex;
  flex-wrap:wrap;
  justify-content:center;
  gap:14px;
}

/* the card */
.kf-hp-card{
  flex:0 0 calc(33.333% - 10px);
  max-width:calc(33.333% - 10px);
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  overflow:hidden;
  cursor:pointer;
  transition:.22s ease;
  box-shadow:var(--ca-shadow-sm);
  display:flex;
  flex-direction:column;
  text-decoration:none !important;
  color:inherit;
  position:relative;
}
.kf-hp-card:hover{
  box-shadow:var(--ca-shadow-lg);
  transform:translateY(-4px);
  color:inherit;
  border-color:var(--card-accent,var(--ca-border2));
}

/* image header */
.kf-hp-card-top{
  height:130px;
  position:relative;
  overflow:hidden;
  background:var(--ca-surface2);
}
.kf-hp-card-top img{
  width:100%;height:100%;
  object-fit:cover;
  object-position:center;
  transition:.4s ease;
  display:block;
}
.kf-hp-card:hover .kf-hp-card-top img{transform:scale(1.04);}

/* gradient overlay on image */
.kf-hp-card-top::after{
  content:'';
  position:absolute;
  inset:0;
  background:linear-gradient(to bottom,transparent 30%,rgba(15,14,11,.55) 100%);
  pointer-events:none;
}

/* accent bar at top of image */
.kf-hp-card-top::before{
  content:'';
  position:absolute;
  top:0;left:0;right:0;
  height:3px;
  background:var(--card-accent,#888);
  z-index:2;
}

/* image fallback (no URL set) */
.kf-hp-card-top.kf-hp-no-image{
  background:linear-gradient(135deg,var(--ca-surface2) 0%,var(--ca-surface3) 100%);
}
.kf-hp-card-top.kf-hp-no-image::after{display:none;}

/* card name overlay on image */
.kf-hp-card-overlay{
  position:absolute;
  bottom:0;left:0;right:0;
  padding:12px 16px;
  z-index:3;
}
.kf-hp-card-name{
  font-family:'Barlow Condensed',sans-serif;
  font-size:22px;
  font-weight:900;
  letter-spacing:.02em;
  color:#fff;
  line-height:1;
  text-shadow:0 1px 4px rgba(0,0,0,.4);
}
.kf-hp-card-sub{
  font-size:10px;
  font-weight:600;
  color:rgba(255,255,255,.75);
  text-transform:uppercase;
  letter-spacing:.12em;
  margin-top:4px;
}
/* when there's no image, keep the title in the body so it's still readable */
.kf-hp-card-overlay.kf-hp-overlay-dark .kf-hp-card-name{color:var(--ca-text);text-shadow:none;}
.kf-hp-card-overlay.kf-hp-overlay-dark .kf-hp-card-sub{color:var(--ca-muted);}

/* card body */
.kf-hp-card-body{
  padding:16px 16px 18px;
  flex:1;
  display:flex;
  flex-direction:column;
}

/* optional description */
.kf-hp-card-desc{
  font-size:13px;
  color:var(--ca-muted);
  line-height:1.55;
  margin:0 0 12px;
}

/* bullet checks */
.kf-hp-checks{margin:0 0 16px;flex:1;}
.kf-hp-check{
  font-size:13px;
  color:var(--ca-muted);
  display:flex;
  align-items:center;
  gap:8px;
  margin-bottom:6px;
  line-height:1.4;
}
.kf-hp-check svg{
  flex-shrink:0;
  color:var(--card-accent,#888);
}

/* button */
.kf-hp-card-btn{
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:8px;
  padding:10px 18px;
  background:var(--card-accent,#888);
  color:#fff !important;
  border-radius:6px;
  font-weight:700;
  font-size:13px;
  font-family:'Outfit',sans-serif;
  text-decoration:none !important;
  transition:.2s ease;
  margin-top:auto;
  box-shadow:0 2px 8px rgba(0,0,0,.12);
}
.kf-hp-card:hover .kf-hp-card-btn{
  filter:brightness(1.10);
  box-shadow:0 4px 16px rgba(0,0,0,.18);
}

/* empty state when no cards configured */
.kf-hp-empty{
  text-align:center;
  padding:72px 24px;
  border:2px dashed var(--ca-border);
  border-radius:14px;
  background:var(--ca-surface);
  color:var(--ca-muted);
}
.kf-hp-empty i{
  font-size:48px;
  color:var(--ca-border2);
  margin-bottom:14px;
  display:block;
}
.kf-hp-empty h3{
  font-family:'Barlow Condensed',sans-serif;
  font-size:24px;
  font-weight:800;
  color:var(--ca-text);
  margin:0 0 8px;
}
.kf-hp-empty p{font-size:14px;color:var(--ca-muted);margin:0;}

/* ════════════════════════════════════════════════════════════
   HERO SECTION (eyebrow / motto / description / stats / marquee)
   All optional — toggled per piece by the addon
   ════════════════════════════════════════════════════════════ */
.kf-hp-hero{
  padding:24px 0 56px;
  text-align:center;
  position:relative;
}

.kf-hp-hero-eyebrow{
  display:inline-flex;
  align-items:center;
  gap:10px;
  font-size:11px;
  font-weight:700;
  letter-spacing:.2em;
  text-transform:uppercase;
  color:var(--ca-muted);
  margin-bottom:20px;
  font-family:var(--ca-body, 'Outfit'), sans-serif;
}
.kf-hp-hero-eyebrow::before,
.kf-hp-hero-eyebrow::after{
  content:'';
  display:block;
  width:28px;height:1.5px;
  background:var(--ca-border2, var(--ca-border));
  border-radius:2px;
}

.kf-hp-hero h1{
  font-family:'Barlow Condensed', sans-serif;
  font-size:clamp(56px, 9vw, 108px);
  font-weight:900;
  line-height:.88;
  letter-spacing:-.02em;
  color:var(--ca-text);
  margin:0 0 20px;
}
.kf-hp-hero h1 span{display:block;}
.kf-hp-hero h1 .kf-hp-hl{font-style:normal;display:block;}

.kf-hp-hero-sub{
  font-size:16px;
  color:var(--ca-muted);
  font-weight:400;
  max-width:560px;
  margin:0 auto 32px;
  line-height:1.7;
}

/* stats strip */
.kf-hp-hero-stats{
  display:flex;
  align-items:center;
  justify-content:center;
  gap:0;
  margin:48px auto 0;
  border:1px solid var(--ca-border);
  border-radius:12px;
  background:var(--ca-surface);
  box-shadow:var(--ca-shadow-sm);
  overflow:hidden;
  max-width:680px;
}
.kf-hp-stat{
  flex:1;
  padding:18px 16px;
  text-align:center;
  border-right:1px solid var(--ca-border);
}
.kf-hp-stat:last-child{border-right:none;}
.kf-hp-stat-num{
  font-family:'Barlow Condensed', sans-serif;
  font-size:30px;
  font-weight:900;
  color:var(--ca-text);
  line-height:1;
  letter-spacing:-.02em;
}
.kf-hp-stat-num em{
  font-style:normal;
  color:var(--kf-hero-accent, #f87171);
}
.kf-hp-stat-label{
  font-size:10px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.12em;
  color:var(--ca-muted);
  margin-top:3px;
}

/* social bar — same grid look as stats, but each cell is a clickable
   off-site link with an image-or-icon and a label. Renders below the
   stats grid; visually consistent so the two read as a paired unit. */
.kf-hp-hero-social{
  display:flex;
  align-items:stretch;
  justify-content:center;
  gap:0;
  margin:14px auto 0;
  border:1px solid var(--ca-border);
  border-radius:12px;
  background:var(--ca-surface);
  box-shadow:var(--ca-shadow-sm);
  overflow:hidden;
  max-width:680px;
}
.kf-hp-hero-social-item{
  flex:1;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:6px;
  padding:14px 12px;
  border-right:1px solid var(--ca-border);
  text-decoration:none !important;
  color:var(--ca-text) !important;
  transition:.18s ease;
}
.kf-hp-hero-social-item:last-child{border-right:none;}
.kf-hp-hero-social-item:hover{
  background:var(--ca-surface2);
  transform:translateY(-1px);
}
.kf-hp-hero-social-icon{
  height:26px;
  display:flex;
  align-items:center;
  justify-content:center;
  font-size:22px;
  color:var(--kf-hero-accent,var(--ca-accent));
  line-height:1;
}
.kf-hp-hero-social-icon img{
  height:26px;
  width:auto;
  display:block;
}
.kf-hp-hero-social-label{
  font-size:10px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.12em;
  color:var(--ca-muted);
  line-height:1.1;
  text-align:center;
}

/* logo marquee */
.kf-hp-logos-marquee{
  width:100%;
  overflow:hidden;
  padding:20px 0;
  margin:48px 0 32px;
  -webkit-mask-image:linear-gradient(to right, transparent 0%, #000 8%, #000 92%, transparent 100%);
  mask-image:linear-gradient(to right, transparent 0%, #000 8%, #000 92%, transparent 100%);
}
.kf-hp-logos-track{
  display:flex;
  gap:48px;
  align-items:center;
  animation:kfHpLogosScroll calc(60s / var(--kf-hp-mq-speed, 1)) linear infinite;
  width:fit-content;
}
@keyframes kfHpLogosScroll{
  0%  {transform:translateX(0);}
  100%{transform:translateX(-50%);}
}
.kf-hp-logo-item{
  flex-shrink:0;
  height:28px;
  display:flex;
  align-items:center;
  transition:opacity .2s, filter .2s;
}
.kf-hp-logo-item img{
  height:100%;
  width:auto;
  object-fit:contain;
}
.kf-hp-logos-marquee.kf-hp-greyscale .kf-hp-logo-item{
  opacity:.4;
  filter:grayscale(1);
}
.kf-hp-logos-marquee.kf-hp-greyscale .kf-hp-logo-item:hover{
  opacity:.7;
  filter:grayscale(0);
}

@media(max-width:768px){
  .kf-hp-hero{padding:16px 0 36px;}
  .kf-hp-hero h1{font-size:clamp(44px, 13vw, 68px);}
  .kf-hp-hero-sub{font-size:14px;}
  .kf-hp-stat-num{font-size:24px;}
  .kf-hp-stat-label{font-size:9px;}
}

/* ════════════════════════════════════════════════════════════
   REVIEWS BLOCK (announcement + reviews marquee + social CTA)
   ════════════════════════════════════════════════════════════ */
.kf-hp-reviews-box{
  display:grid;
  grid-template-columns:1fr 1px 1fr;
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:16px;
  box-shadow:var(--ca-shadow-md);
  margin:0 0 56px;
  overflow:hidden;
}
.kf-hp-reviews-box-divider{background:var(--ca-border);width:1px;}
.kf-hp-reviews-box-left{padding:28px 28px 24px;display:flex;flex-direction:column;}
.kf-hp-ann-eyebrow{font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.18em;color:var(--ca-muted);margin-bottom:8px;}
.kf-hp-ann-title{font-family:'Barlow Condensed',sans-serif;font-size:22px;font-weight:800;letter-spacing:-.01em;color:var(--ca-text);margin-bottom:10px;line-height:1.1;}
.kf-hp-ann-body{font-size:13.5px;font-weight:400;color:var(--ca-muted);line-height:1.7;flex:1;overflow:hidden;position:relative;max-height:200px;}
.kf-hp-ann-body::after{content:'';position:absolute;left:0;right:0;bottom:0;height:48px;background:linear-gradient(transparent,var(--ca-surface));pointer-events:none;}
.kf-hp-ann-link{display:inline-flex;align-items:center;gap:6px;margin-top:14px;font-size:13px;font-weight:700;color:var(--ca-accent);text-decoration:none;}
.kf-hp-ann-link:hover{text-decoration:underline;}
.kf-hp-ann-placeholder{font-size:13.5px;color:var(--ca-muted);font-style:italic;margin-top:6px;}

.kf-hp-reviews-box-right{display:flex;flex-direction:column;min-width:0;}
.kf-hp-reviews-head{padding:20px 24px 16px;border-bottom:1px solid var(--ca-border);background:var(--ca-surface2);}
.kf-hp-reviews-head-title{font-family:'Barlow Condensed',sans-serif;font-size:20px;font-weight:800;letter-spacing:-.01em;color:var(--ca-text);margin-bottom:2px;}
.kf-hp-reviews-head-sub{font-size:11px;color:var(--ca-muted);font-weight:500;}
.kf-hp-reviews-marquee{flex:1;overflow:hidden;padding:14px 0;background:var(--ca-surface2);-webkit-mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);mask-image:linear-gradient(to right,transparent 0%,#000 8%,#000 92%,transparent 100%);}
.kf-hp-reviews-track{display:flex;gap:12px;animation:kfHpReviewsScroll 220s linear infinite;width:fit-content;}
@keyframes kfHpReviewsScroll{0%{transform:translateX(0);}100%{transform:translateX(-50%);}}
/* Static centered layout for 1-3 reviews — no marquee scroll, cards centered
   in the box so they don't look randomly half-cut by the marquee animation. */
.kf-hp-reviews-static{flex:1;display:flex;gap:14px;align-items:center;justify-content:center;flex-wrap:wrap;padding:18px 16px;background:var(--ca-surface2);}
.kf-hp-review-card{background:var(--ca-surface);border:1px solid var(--ca-border);border-radius:10px;padding:14px 16px;min-width:240px;max-width:240px;box-shadow:var(--ca-shadow-sm);flex-shrink:0;}
.kf-hp-review-stars{color:#f59e0b;font-size:10px;margin-bottom:5px;letter-spacing:1px;}
.kf-hp-review-text{font-size:12px;line-height:1.6;color:var(--ca-muted);font-style:italic;margin:0 0 8px;}
.kf-hp-review-author{font-size:11px;font-weight:700;color:var(--ca-accent);text-align:right;text-decoration:none;}
.kf-hp-review-author:hover{text-decoration:underline;}

.kf-hp-social-cta{grid-column:1/-1;display:flex;justify-content:center;align-items:center;gap:24px;padding:14px 20px 16px;border-top:1px solid var(--ca-border);background:var(--ca-surface2);flex-wrap:wrap;}
.kf-hp-social-cta a{
  --kf-sb-color:var(--ca-text);
  --kf-sb-color-faded:rgba(19,17,14,.20);
  --kf-sb-color-shadow:rgba(19,17,14,.10);
  display:inline-flex;
  align-items:center;
  gap:8px;
  font-family:'Outfit',sans-serif;
  font-size:14px;
  font-weight:700;
  text-decoration:none !important;
  padding:8px 18px;
  border:1.5px solid var(--kf-sb-color-faded);
  border-radius:6px;
  background:var(--ca-surface);
  box-shadow:var(--ca-shadow-sm);
  /* IMPORTANT: color is NOT in the transition list — it must change
     instantly on hover so the global a:hover rule (master accent) can't
     animate-flash before our !important pin takes effect. */
  transition:transform .2s ease, border-color .2s ease, box-shadow .2s ease;
}
/* Pin the brand color across every interactive state — covers any global
   a:link, a:visited, a:hover, a:focus rule from the Renderer's accent
   override that would otherwise leak through during state transitions. */
.kf-hp-social-cta a,
.kf-hp-social-cta a:link,
.kf-hp-social-cta a:visited,
.kf-hp-social-cta a:hover,
.kf-hp-social-cta a:focus,
.kf-hp-social-cta a:focus-visible,
.kf-hp-social-cta a:active{
  color:var(--kf-sb-color) !important;
}
.kf-hp-social-cta a i,
.kf-hp-social-cta a:hover i,
.kf-hp-social-cta a:focus i,
.kf-hp-social-cta a:active i{
  color:var(--kf-sb-color) !important;
}
.kf-hp-social-cta a:hover{
  transform:translateY(-1px);
  border-color:var(--kf-sb-color) !important;
  box-shadow:0 4px 16px var(--kf-sb-color-shadow);
}

/* ── empty/placeholder state for reviews when admin has no items yet ── */
.kf-hp-reviews-empty{padding:32px 24px;color:var(--ca-muted);font-size:13px;font-style:italic;text-align:center;}

@media(max-width:780px){
  .kf-hp-reviews-box{grid-template-columns:1fr;}
  .kf-hp-reviews-box-divider{display:none;}
  .kf-hp-reviews-box-right{border-top:1px solid var(--ca-border);}
}

/* ── RESPONSIVE ───────────────────────────────────────── */
@media(max-width:860px){
  .kf-hp-card{flex:0 0 calc(50% - 7px); max-width:calc(50% - 7px);}
}
@media(max-width:560px){
  .kf-hp-card{flex:0 0 100%; max-width:100%;}
}
</style>
{/literal}

<div class="kf-hp-wrap">

    {* ════════ HERO SECTION ════════
       Each piece renders only when its addon toggle is ON. *}
    {assign var=kf_show_hero value=false}
    {if (isset($kf_hero_eyebrow_enabled)     && $kf_hero_eyebrow_enabled     && $kf_hero_eyebrow_text)
     || (isset($kf_hero_motto_enabled)       && $kf_hero_motto_enabled       && ($kf_hero_motto_lines || $kf_hero_motto_accent))
     || (isset($kf_hero_description_enabled) && $kf_hero_description_enabled && $kf_hero_description_text)
     || (isset($kf_hero_stats_enabled)       && $kf_hero_stats_enabled       && $kf_hero_stats)
     || (isset($kf_hero_social_enabled)      && $kf_hero_social_enabled      && $kf_hero_social)}
        {assign var=kf_show_hero value=true}
    {/if}

    {if $kf_show_hero}
        <div class="kf-hp-hero">
            {if $kf_hero_eyebrow_enabled && $kf_hero_eyebrow_text}
                <div class="kf-hp-hero-eyebrow">{$kf_hero_eyebrow_text}</div>
            {/if}

            {if $kf_hero_motto_enabled && ($kf_hero_motto_lines || $kf_hero_motto_accent)}
                <h1>
                    {foreach $kf_hero_motto_lines as $kf_ml}
                        <span>{$kf_ml}</span>
                    {/foreach}
                    {if $kf_hero_motto_accent}
                        <em class="kf-hp-hl" style="color:{$kf_hero_motto_accent_color};">{$kf_hero_motto_accent}</em>
                    {/if}
                </h1>
            {/if}

            {if $kf_hero_description_enabled && $kf_hero_description_text}
                <p class="kf-hp-hero-sub">{$kf_hero_description_text}</p>
            {/if}

            {if $kf_hero_stats_enabled && $kf_hero_stats}
                <div class="kf-hp-hero-stats" style="--kf-hero-accent:{$kf_hero_motto_accent_color};">
                    {foreach $kf_hero_stats as $kf_st}
                        {if $kf_st.number || $kf_st.label}
                            <div class="kf-hp-stat">
                                <div class="kf-hp-stat-num">{$kf_st.number}{if $kf_st.highlight}<em>{$kf_st.highlight}</em>{/if}</div>
                                {if $kf_st.label}<div class="kf-hp-stat-label">{$kf_st.label}</div>{/if}
                            </div>
                        {/if}
                    {/foreach}
                </div>
            {/if}

            {if $kf_hero_social_enabled && $kf_hero_social}
                <div class="kf-hp-hero-social" style="--kf-hero-accent:{$kf_hero_motto_accent_color};">
                    {foreach $kf_hero_social as $kf_soc}
                        {if $kf_soc.url || $kf_soc.label}
                            <a class="kf-hp-hero-social-item" href="{$kf_soc.url}"{if $kf_soc._external} target="_blank" rel="noopener noreferrer"{/if}>
                                <span class="kf-hp-hero-social-icon"{if !$kf_soc.image && $kf_soc.icon_color} style="color:{$kf_soc.icon_color};"{/if}>
                                    {if $kf_soc.image}<img src="{$kf_soc.image}" alt="{$kf_soc.label}">{elseif $kf_soc.icon}<i class="{$kf_soc.icon}"></i>{/if}
                                </span>
                                {if $kf_soc.label}<span class="kf-hp-hero-social-label">{$kf_soc.label}</span>{/if}
                            </a>
                        {/if}
                    {/foreach}
                </div>
            {/if}
        </div>
    {/if}

    {* ════════ LOGO MARQUEE ════════ *}
    {if isset($kf_hero_marquee_enabled) && $kf_hero_marquee_enabled && $kf_hero_marquee_items}
        <div class="kf-hp-logos-marquee {if $kf_hero_marquee_greyscale}kf-hp-greyscale{/if}"
             style="--kf-hp-mq-speed:{$kf_hero_marquee_speed};">
            <div class="kf-hp-logos-track" id="kfHpLogosTrack">
                {foreach $kf_hero_marquee_items as $kf_mq}
                    <div class="kf-hp-logo-item"><img src="{$kf_mq.url}" alt="{if $kf_mq.alt}{$kf_mq.alt}{/if}"></div>
                {/foreach}
            </div>
        </div>
        {literal}
        <script>
        (function(){
            var track = document.getElementById('kfHpLogosTrack');
            if (!track) return;
            // Duplicate the items so the -50% scroll loops seamlessly
            var items = Array.from(track.children);
            // shuffle to randomize per-pageload
            for (var i = items.length - 1; i > 0; i--){
                var j = Math.floor(Math.random() * (i + 1));
                var tmp = items[i]; items[i] = items[j]; items[j] = tmp;
            }
            track.innerHTML = '';
            items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
            items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
        })();
        </script>
        {/literal}
    {/if}

    {* ════════ LATEST & MEMBER REVIEWS BLOCK ════════ *}
    {if isset($kf_reviews_enabled) && $kf_reviews_enabled}
        <div class="kf-hp-section-label">
            <div class="kf-hp-section-label-text">Latest &amp; Member Reviews</div>
            <div class="kf-hp-section-label-line"></div>
        </div>

        <div class="kf-hp-reviews-box">

            {* LEFT: announcement (auto-pulled from WHMCS) *}
            {if $kf_reviews_announcement_enabled}
                <div class="kf-hp-reviews-box-left">
                    {if isset($announcements) && $announcements}
                        {foreach $announcements as $kf_anno}
                            {if $kf_anno@first}
                                <div class="kf-hp-ann-eyebrow">📢 Announcement</div>
                                <div class="kf-hp-ann-title">{$kf_anno.title|escape:'html'}</div>
                                <div class="kf-hp-ann-body">{$kf_anno.text|strip_tags:'<p><br><b><strong><em><ul><ol><li><a>'}</div>
                                <a href="{$WEB_ROOT}/index.php?rp=/announcements/{$kf_anno.id}" class="kf-hp-ann-link">Read full announcement →</a>
                            {/if}
                        {/foreach}
                    {else}
                        <div class="kf-hp-ann-eyebrow">📢 Announcement</div>
                        <div class="kf-hp-ann-title">No Current Announcements</div>
                        <p class="kf-hp-ann-placeholder">Check back soon for updates.</p>
                    {/if}
                </div>

                <div class="kf-hp-reviews-box-divider"></div>
            {/if}

            {* RIGHT: reviews marquee *}
            <div class="kf-hp-reviews-box-right" {if !$kf_reviews_announcement_enabled}style="grid-column:1/-1;"{/if}>
                <div class="kf-hp-reviews-head">
                    <div class="kf-hp-reviews-head-title">{$kf_reviews_title}</div>
                    <div class="kf-hp-reviews-head-sub">{$kf_reviews_subtitle}</div>
                </div>
                {if $kf_reviews_items}
                    {* When there are only 1–3 reviews, the marquee animation
                       leaves the cards visually off-center (translate-X eats
                       half the track). Render them as a static centered row
                       instead. The marquee only kicks in at 4+ when there's
                       actually enough content to make scrolling look natural. *}
                    {if $kf_reviews_items|@count < 4}
                        <div class="kf-hp-reviews-static">
                            {foreach $kf_reviews_items as $kf_rv}
                                <div class="kf-hp-review-card">
                                    <div class="kf-hp-review-stars">{section name=star start=0 loop=$kf_rv.stars step=1}★{/section}{section name=blank start=$kf_rv.stars loop=5 step=1}☆{/section}</div>
                                    <p class="kf-hp-review-text">"{$kf_rv.text}"</p>
                                    {if $kf_rv.link}
                                        <a class="kf-hp-review-author" href="{$kf_rv.link}" target="_blank" rel="noopener">— {$kf_rv.author}</a>
                                    {else}
                                        <div class="kf-hp-review-author">— {$kf_rv.author}</div>
                                    {/if}
                                </div>
                            {/foreach}
                        </div>
                    {else}
                        <div class="kf-hp-reviews-marquee">
                            <div class="kf-hp-reviews-track" id="kfHpReviewsTrack">
                                {foreach $kf_reviews_items as $kf_rv}
                                    <div class="kf-hp-review-card">
                                        <div class="kf-hp-review-stars">{section name=star start=0 loop=$kf_rv.stars step=1}★{/section}{section name=blank start=$kf_rv.stars loop=5 step=1}☆{/section}</div>
                                        <p class="kf-hp-review-text">"{$kf_rv.text}"</p>
                                        {if $kf_rv.link}
                                            <a class="kf-hp-review-author" href="{$kf_rv.link}" target="_blank" rel="noopener">— {$kf_rv.author}</a>
                                        {else}
                                            <div class="kf-hp-review-author">— {$kf_rv.author}</div>
                                        {/if}
                                    </div>
                                {/foreach}
                            </div>
                        </div>
                    {/if}
                {else}
                    <div class="kf-hp-reviews-empty">No reviews added yet. Add some in the addon settings.</div>
                {/if}
            </div>

            {* BOTTOM: social CTA row *}
            {if $kf_social_buttons_enabled && $kf_social_buttons}
                <div class="kf-hp-social-cta">
                    {foreach $kf_social_buttons as $kf_btn}
                        <a href="{$kf_btn.url}"{if $kf_btn.target} target="{$kf_btn.target}" rel="noopener"{/if}{if $kf_btn.color} style="--kf-sb-color:{$kf_btn.color};--kf-sb-color-faded:{$kf_btn.color}33;--kf-sb-color-shadow:{$kf_btn.color}26;"{/if}>
                            {if $kf_btn.icon}<i class="{$kf_btn.icon}"></i>{/if} {$kf_btn.label}
                        </a>
                    {/foreach}
                </div>
            {/if}
        </div>

        {if $kf_reviews_items}
            {literal}
            <script>
            (function(){
                var track = document.getElementById('kfHpReviewsTrack');
                if (!track) return;
                var items = Array.from(track.children);
                for (var i = items.length - 1; i > 0; i--){
                    var j = Math.floor(Math.random() * (i + 1));
                    var tmp = items[i]; items[i] = items[j]; items[j] = tmp;
                }
                track.innerHTML = '';
                items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
                items.forEach(function(el){ track.appendChild(el.cloneNode(true)); });
            })();
            </script>
            {/literal}
        {/if}
    {/if}

    <div class="kf-hp-section-label">
        <div class="kf-hp-section-label-text">Our Services</div>
        <div class="kf-hp-section-label-line"></div>
    </div>

    {* Count visible cards (enabled AND has a title) *}
    {assign var=kf_visible_count value=0}
    {if isset($kf_homepage_cards) && $kf_homepage_cards}
        {foreach $kf_homepage_cards as $kf_c}
            {if $kf_c.enabled && $kf_c.title}{assign var=kf_visible_count value=$kf_visible_count+1}{/if}
        {/foreach}
    {/if}

    {if $kf_visible_count > 0}
        <div class="kf-hp-cards-grid">
            {foreach $kf_homepage_cards as $kf_c}
                {if $kf_c.enabled && $kf_c.title}
                    <a href="{if $kf_c.link}{$kf_c.link}{else}#{/if}" class="kf-hp-card" style="--card-accent:{if $kf_c.accent}{$kf_c.accent}{else}#22a04a{/if};">

                        <div class="kf-hp-card-top {if !$kf_c.image}kf-hp-no-image{/if}">
                            {if $kf_c.image}
                                <img src="{$kf_c.image}" alt="{$kf_c.title}">
                            {/if}
                            <div class="kf-hp-card-overlay {if !$kf_c.image}kf-hp-overlay-dark{/if}">
                                <div class="kf-hp-card-name">{$kf_c.title}</div>
                                {if $kf_c.subtitle}<div class="kf-hp-card-sub">{$kf_c.subtitle}</div>{/if}
                            </div>
                        </div>

                        <div class="kf-hp-card-body">
                            {if $kf_c.description}
                                <p class="kf-hp-card-desc">{$kf_c.description}</p>
                            {/if}

                            {if $kf_c.bullet1 || $kf_c.bullet2 || $kf_c.bullet3}
                                <div class="kf-hp-checks">
                                    {if $kf_c.bullet1}<div class="kf-hp-check"><svg width="13" height="13" viewBox="0 0 13 13" fill="none"><polyline points="2,7 5,10 11,3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{$kf_c.bullet1}</div>{/if}
                                    {if $kf_c.bullet2}<div class="kf-hp-check"><svg width="13" height="13" viewBox="0 0 13 13" fill="none"><polyline points="2,7 5,10 11,3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{$kf_c.bullet2}</div>{/if}
                                    {if $kf_c.bullet3}<div class="kf-hp-check"><svg width="13" height="13" viewBox="0 0 13 13" fill="none"><polyline points="2,7 5,10 11,3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>{$kf_c.bullet3}</div>{/if}
                                </div>
                            {/if}

                            <span class="kf-hp-card-btn">View Plans →</span>
                        </div>
                    </a>
                {/if}
            {/foreach}
        </div>
    {else}
        <div class="kf-hp-empty">
            <i class="fal fa-th-large"></i>
            <h3>No homepage cards configured</h3>
            <p>Set up your service cards in <strong>Addons → KwickFlix Style → Homepage</strong>.</p>
        </div>
    {/if}

</div>
