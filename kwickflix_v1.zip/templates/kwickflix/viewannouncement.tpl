{literal}
<style>
.kf-announce-wrap{padding:8px 0 40px;font-family:'Outfit',sans-serif;}
.kf-announce-article{
  background:var(--ca-surface);
  border:1px solid var(--ca-border);
  border-radius:14px;
  box-shadow:var(--ca-shadow-sm);
  overflow:hidden;
  margin-bottom:18px;
}
.kf-announce-article-header{
  background:var(--ca-surface2);
  border-bottom:1px solid var(--ca-border);
  padding:24px 28px 20px;
}
.kf-announce-article-header h1{
  font-family:'Barlow Condensed',sans-serif;
  font-size:clamp(26px,4vw,40px);
  font-weight:900;
  letter-spacing:-.02em;
  color:var(--ca-text);
  margin:0 0 10px;
  line-height:1.1;
}
.kf-announce-meta{
  display:flex;
  flex-wrap:wrap;
  gap:18px;
  font-size:12px;
  font-weight:600;
  color:var(--ca-muted);
  text-transform:uppercase;
  letter-spacing:.1em;
}
.kf-announce-meta i{color:var(--ca-accent);margin-right:4px;}
.kf-announce-body{padding:28px;font-size:15px;line-height:1.8;color:var(--ca-text);}
.kf-announce-body p{margin:0 0 14px;}
.kf-announce-actions{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-top:18px;}
</style>
{/literal}

<div class="kf-announce-wrap">
    <div class="kf-announce-article">
        <div class="kf-announce-article-header">
            <h1>{$title}</h1>
            <div class="kf-announce-meta">
                <span><i class="far fa-calendar-alt"></i>{$carbon->createFromTimestamp($timestamp)->format('l, jS F, Y')}</span>
                <span><i class="far fa-clock"></i>{$carbon->createFromTimestamp($timestamp)->format('H:ia')}</span>
            </div>
        </div>
        <div class="kf-announce-body">
            {$text}
        </div>
    </div>

    <div class="kf-announce-actions">
        <a href="{routePath('announcement-index')}" class="btn btn-default">
            <i class="fas fa-arrow-left"></i>&nbsp;{lang key='clientareabacklink'}
        </a>
        {if $editLink}
            <a href="{$editLink}" class="btn btn-default">
                <i class="fas fa-pencil-alt"></i>&nbsp;{lang key='edit'}
            </a>
        {/if}
    </div>
</div>
