{if $addfundsdisabled}
    {include file="$template/includes/alert.tpl" type="error" msg="{lang key='clientareaaddfundsdisabled'}" textcenter=true}
{elseif $notallowed}
    {include file="$template/includes/alert.tpl" type="error" msg="{lang key='clientareaaddfundsnotallowed'}" textcenter=true}
{elseif $errormessage}
    {include file="$template/includes/alert.tpl" type="error" errorshtml=$errormessage textcenter=true}
{/if}

{if !$addfundsdisabled && !$notallowed}

{* ════════════════════════════════════════════════════════════
   KWICKFLIX ADD FUNDS PAGE
   All CSS scoped to .kf-af-wrap. Same design tokens and patterns
   as the affiliates rewrite — bordered cards on ca-surface, Barlow
   Condensed for numbers, Outfit body, accent bars, green CTA.
   ════════════════════════════════════════════════════════════ *}
{literal}
<style>
.kf-af-wrap{
    max-width:720px;
    margin:0 auto;
    padding:8px 0 40px;
    font-family:'Outfit',sans-serif;
    color:var(--ca-text);
}

/* ── Header / current balance ──────────────────────────────────── */
.kf-af-head{
    display:flex;
    align-items:center;
    gap:18px;
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:20px 24px;
    box-shadow:var(--ca-shadow-sm);
    margin-bottom:14px;
    position:relative;
    overflow:hidden;
}
.kf-af-head::after{
    content:'';
    position:absolute;
    bottom:0;left:0;right:0;
    height:3px;
    background:linear-gradient(90deg,var(--ca-accent),var(--ca-accent-dark));
}
.kf-af-head-icon{
    flex:0 0 56px;
    height:56px;
    border-radius:14px;
    background:var(--ca-accent-bg);
    border:1.5px solid var(--ca-accent-border);
    display:flex;
    align-items:center;
    justify-content:center;
    color:var(--ca-accent);
    font-size:24px;
}
.kf-af-head-meta{flex:1 1 auto;min-width:0;}
.kf-af-head-eyebrow{
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.16em;
    color:var(--ca-muted);
    margin-bottom:4px;
}
.kf-af-head-title{
    font-family:'Barlow Condensed',sans-serif;
    font-size:28px;
    font-weight:900;
    line-height:1;
    letter-spacing:-.01em;
    color:var(--ca-text);
}
.kf-af-head-balance{
    flex:0 0 auto;
    text-align:right;
    padding-left:18px;
    border-left:1px solid var(--ca-border);
}
.kf-af-head-balance-label{
    font-size:10px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.12em;
    color:var(--ca-muted);
    margin-bottom:2px;
}
.kf-af-head-balance-value{
    font-family:'Barlow Condensed',sans-serif;
    font-size:22px;
    font-weight:900;
    line-height:1;
    color:var(--ca-text);
}

/* ── Limits row (min / max / max balance) ──────────────────────── */
.kf-af-limits{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:10px;
    margin-bottom:18px;
}
.kf-af-limit{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:12px;
    padding:12px 14px;
    box-shadow:var(--ca-shadow-sm);
    text-align:center;
}
.kf-af-limit-label{
    font-size:10px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.1em;
    color:var(--ca-muted);
    margin-bottom:4px;
}
.kf-af-limit-value{
    font-family:'Barlow Condensed',sans-serif;
    font-size:20px;
    font-weight:800;
    color:var(--ca-text);
    line-height:1;
    letter-spacing:-.01em;
}

/* ── Main form card ─────────────────────────────────────────────── */
.kf-af-card{
    background:var(--ca-surface);
    border:1px solid var(--ca-border);
    border-radius:14px;
    padding:24px 26px;
    box-shadow:var(--ca-shadow-sm);
}
.kf-af-card h3{
    font-family:'Barlow Condensed',sans-serif;
    font-size:22px;
    font-weight:800;
    letter-spacing:-.01em;
    color:var(--ca-text);
    margin:0 0 14px;
    display:flex;
    align-items:center;
    gap:10px;
}
.kf-af-card h3 i{color:var(--ca-accent);font-size:18px;}

.kf-af-field{margin-bottom:14px;}
.kf-af-field label{
    display:block;
    font-size:11px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:.1em;
    color:var(--ca-muted);
    margin-bottom:6px;
}

/* Amount input with the currency prefix decoration */
.kf-af-amount{
    position:relative;
    display:flex;
    align-items:stretch;
}
.kf-af-amount-input{
    flex:1 1 auto;
    background:var(--ca-surface2) !important;
    border:1.5px solid var(--ca-border) !important;
    border-radius:10px !important;
    padding:14px 18px !important;
    font-family:'Barlow Condensed',sans-serif !important;
    font-size:32px !important;
    font-weight:800 !important;
    color:var(--ca-text) !important;
    letter-spacing:-.01em;
    height:auto !important;
    transition:.15s ease;
}
.kf-af-amount-input:focus{
    border-color:var(--ca-accent) !important;
    box-shadow:0 0 0 3px var(--ca-accent-bg) !important;
    outline:none !important;
    background:var(--ca-surface) !important;
}
.kf-af-amount-input::placeholder{
    color:var(--ca-muted);
    opacity:.5;
}

.kf-af-select{
    width:100%;
    background:var(--ca-surface2) !important;
    border:1.5px solid var(--ca-border) !important;
    border-radius:10px !important;
    padding:12px 16px !important;
    font-family:'Outfit',sans-serif !important;
    font-size:14px !important;
    font-weight:600 !important;
    color:var(--ca-text) !important;
    height:auto !important;
    transition:.15s ease;
    appearance:none;
    -webkit-appearance:none;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 8' fill='none' stroke='%237a7268' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><polyline points='1,1 6,6 11,1'/></svg>") !important;
    background-repeat:no-repeat !important;
    background-position:right 16px center !important;
    background-size:12px 8px !important;
    padding-right:40px !important;
}
.kf-af-select:focus{
    border-color:var(--ca-accent) !important;
    box-shadow:0 0 0 3px var(--ca-accent-bg) !important;
    outline:none !important;
    background-color:var(--ca-surface) !important;
}

/* CTA */
.kf-af-submit{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    width:100%;
    padding:14px 24px;
    background:linear-gradient(135deg,var(--ca-accent),var(--ca-accent-dark));
    color:#fff !important;
    border:0;
    border-radius:10px;
    font-family:'Outfit',sans-serif;
    font-weight:700;
    font-size:15px;
    letter-spacing:.02em;
    cursor:pointer;
    box-shadow:var(--ca-shadow-green);
    transition:.18s ease;
    text-decoration:none !important;
    margin-top:6px;
}
.kf-af-submit:hover{
    transform:translateY(-2px);
    box-shadow:0 10px 32px rgba(34,160,74,.32);
}
.kf-af-submit:active{transform:translateY(0);}

.kf-af-disclaimer{
    margin:14px 0 0;
    padding:10px 14px;
    background:var(--ca-surface2);
    border:1px solid var(--ca-border);
    border-radius:8px;
    font-size:12px;
    color:var(--ca-muted);
    display:flex;
    align-items:flex-start;
    gap:8px;
    line-height:1.55;
}
.kf-af-disclaimer i{color:var(--ca-muted);margin-top:2px;font-size:13px;flex:0 0 auto;}

@media (max-width:560px){
    .kf-af-head{flex-direction:column;align-items:flex-start;gap:12px;text-align:left;}
    .kf-af-head-balance{padding-left:0;border-left:0;border-top:1px solid var(--ca-border);padding-top:12px;text-align:left;width:100%;}
    .kf-af-limits{grid-template-columns:1fr;}
    .kf-af-amount-input{font-size:26px !important;}
}
</style>
{/literal}

<div class="kf-af-wrap">

    {* ── Header card with current balance ──────────────────────── *}
    <div class="kf-af-head">
        <div class="kf-af-head-icon"><i class="fas fa-piggy-bank"></i></div>
        <div class="kf-af-head-meta">
            <div class="kf-af-head-eyebrow">{lang key='nav.billing'}</div>
            <div class="kf-af-head-title">{lang key='addfunds'}</div>
        </div>
        {if isset($kf_client_credit) && $kf_client_credit}
            <div class="kf-af-head-balance">
                <div class="kf-af-head-balance-label">{lang key='creditbalance'}</div>
                <div class="kf-af-head-balance-value">{$kf_client_credit}</div>
            </div>
        {/if}
    </div>

    {* ── Limits row ────────────────────────────────────────────── *}
    <div class="kf-af-limits">
        <div class="kf-af-limit">
            <div class="kf-af-limit-label">{lang key='addfundsminimum'}</div>
            <div class="kf-af-limit-value">{$minimumamount}</div>
        </div>
        <div class="kf-af-limit">
            <div class="kf-af-limit-label">{lang key='addfundsmaximum'}</div>
            <div class="kf-af-limit-value">{$maximumamount}</div>
        </div>
        <div class="kf-af-limit">
            <div class="kf-af-limit-label">{lang key='addfundsmaximumbalance'}</div>
            <div class="kf-af-limit-value">{$maximumbalance}</div>
        </div>
    </div>

    {* ── Main form card ────────────────────────────────────────── *}
    <div class="kf-af-card">
        <h3><i class="fas fa-credit-card"></i> {lang key='addfunds'}</h3>

        <form method="post" action="{$smarty.server.PHP_SELF}?action=addfunds">

            <div class="kf-af-field">
                <label for="amount">{lang key='addfundsamount'}</label>
                <div class="kf-af-amount">
                    <input type="text" name="amount" id="amount"
                           class="kf-af-amount-input"
                           value="{$amount}"
                           placeholder="0.00"
                           inputmode="decimal"
                           required>
                </div>
            </div>

            <div class="kf-af-field">
                <label for="paymentmethod">{lang key='orderpaymentmethod'}</label>
                <select name="paymentmethod" id="paymentmethod" class="kf-af-select">
                    {foreach $gateways as $gateway}
                        <option value="{$gateway.sysname}">{$gateway.name}</option>
                    {/foreach}
                </select>
            </div>

            <button type="submit" class="kf-af-submit">
                <i class="fas fa-arrow-right"></i>
                {lang key='addfunds'}
            </button>

            <div class="kf-af-disclaimer">
                <i class="fas fa-info-circle"></i>
                <span>{lang key='addfundsnonrefundable'}</span>
            </div>

        </form>
    </div>

</div>

{/if}
